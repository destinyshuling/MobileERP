//
//  ShowAlert.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/6/15.
//  Copyright © 2016年 onto. All rights reserved.
//

import Foundation
import UIKit

class ShowAlert: UIViewController
{
    func ShowAlert(titleString:String, ContentString:String, ActionString:String) -> UIAlertController
    {
        let alertController = UIAlertController(title: titleString, message:
            ContentString, preferredStyle: UIAlertControllerStyle.Alert)
        alertController.addAction(UIAlertAction(title: ActionString, style: UIAlertActionStyle.Default,handler: nil))
        return alertController
        //self.presentViewController(alertController, animated: true, completion: nil)
    }
}
