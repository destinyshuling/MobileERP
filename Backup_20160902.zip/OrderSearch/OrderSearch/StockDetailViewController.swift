//
//  StockDetailViewController.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/8/18.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit

class StockDetailViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet var stockDetailView:UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "庫存明細"

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 2
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if section == 0
        {
            return 5
        }
        else
        {
            return 10
        }
    }
    
    func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String?
    {
        if section == 0
        {
            return "1"
        }
        else
        {
            return "單身"
        }
    }
    
    func tableView(tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int)
    {
        var headerTitle:String = ""
        if section == 0
        {
            headerTitle = "1"
        }
        else
        {
            headerTitle = "單身"
        }
        
        let title = UILabel()
        title.font = UIFont(name: headerTitle, size: 30)
        title.textColor = UIColor.blackColor()
        
        let header = view as! UITableViewHeaderFooterView
        header.textLabel?.font=title.font
        header.textLabel?.textColor=title.textColor
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50.0
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        if indexPath.section == 0
        {
            let cell = tableView.dequeueReusableCellWithIdentifier("OrderDetailHeaderCell", forIndexPath: indexPath) as! OrderDetailHeaderTableViewCell
            /*switch indexPath.row {
            case 0:
                cell.title.text = "訂單日期"
                cell.content.text = ""
            case 1:
                cell.title.text = "客戶代號"
                cell.content.text = ""
            case 2:
                cell.title.text = "客戶簡稱"
                cell.content.text = ""
            case 3:
                cell.title.text = "訂單幣別"
                cell.content.text = ""
            case 4:
                cell.title.text = "訂單金額"
                cell.content.text = ""
            default:
                cell.title.text = ""
                cell.content.text = ""
            }*/
            return cell
        }
        else
        {
            let cell = tableView.dequeueReusableCellWithIdentifier("StockDetailCell", forIndexPath: indexPath) as! StockDetailTableViewCell
            
            // Configure the cell...
//            cell.item.text = orderDetails[indexPath.row].item
//            cell.partnumber.text = orderDetails[indexPath.row].partnumber
//            cell.desc.text = orderDetails[indexPath.row].description
//            cell.salesunit.text = orderDetails[indexPath.row].salesunit
//            cell.qty.text = orderDetails[indexPath.row].qty
//            cell.unitprice.text = String.stringSeparsted(unitprice!)
//            cell.paidqty.text = orderDetails[indexPath.row].paidqty
//            cell.unpaidqty.text = orderDetails[indexPath.row].unpaidqty
            
            return cell
        }
    }
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
     if editingStyle == .Delete {
     // Delete the row from the data source
     tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
     } else if editingStyle == .Insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat
    {
        if indexPath.section == 0
        {
            return 40
        }
        else
        {
            return 80
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
