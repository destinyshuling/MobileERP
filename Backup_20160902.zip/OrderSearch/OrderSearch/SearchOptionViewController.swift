//
//  SearchOptionViewController.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/5/24.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit
import CoreActionSheetPicker

class SearchOptionViewController: UIViewController, ContainerToMaster{
    //查詢按鈕
    @IBOutlet var searchBtn: UIButton!
    //顯示登入者帳號
    @IBOutlet var AccountLabel: UILabel!
    //月度或季度查詢識別
    @IBOutlet var dateSwitch: UISwitch!
    
    //var alertObject:ShowAlert!
    var alertObject = ShowAlert()
    
    //前一頁傳遞過來的資料
    var loginAccount:String!
    var loginName:String!
    var loginDepartment:String!
    var loginAuthorization: String!
    var loginAuthorizationArr: [String] = []
    var serviceToken:String!
    //var errorObject = [ErrorMsg]()
    var errorObject: Dictionary<String, AnyObject> = [:]
    var internetReachability:Reachability!; //網路狀態監控
    
    private var embeddedViewController: SearchOptionTableViewController!
    
    var conViewController: SearchOptionTableViewController?
    func getSwitchValue() -> Bool
    {
        return dateSwitch.on
    }
    
    @IBAction func switch_change(sender: AnyObject)
    {
        if dateSwitch.on
        {
            embeddedViewController?.changeDateName("月度")
            print("月度")
        }
        else
        {
            embeddedViewController?.changeDateName("季度")
            print("季度")
        }
    }
    //ref2:http://stackoverflow.com/questions/34348275/pass-data-between-viewcontroller-and-containerviewcontroller
    //ref1:http://stackoverflow.com/questions/29294005/dispatch-event-to-parent-viewcontroller-in-swift
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        AccountLabel.text = "\(loginAccount) (\(loginName))"
        
        let btnName = UIButton()
        btnName.setImage(UIImage(named: "logout-2"), forState: .Normal)
        btnName.frame = CGRectMake(0, 0, 30, 30)
        btnName.addTarget(self, action: #selector(SearchOptionViewController.LogoutBtnClick(_:)), forControlEvents: .TouchUpInside)
        
        //.... Set Right/Left Bar Button item
        let rightBarButton = UIBarButtonItem()
        rightBarButton.customView = btnName
        self.navigationItem.rightBarButtonItem = rightBarButton
    }
    
    //  Now in other methods you can reference `embeddedViewController`.
    //  For example:
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        navigationController?.hidesBarsOnSwipe = false
        navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if let vc = segue.destinationViewController as? SearchOptionTableViewController
            where segue.identifier == "EmbedSegue"
        {
            self.embeddedViewController = vc
            self.embeddedViewController.loginDepartment = self.loginDepartment
            self.embeddedViewController.loginAuthorizationArr = self.loginAuthorizationArr
            /*if dateSwitch.on
            {
                self.embeddedViewController.switchValue = true
            }
            else
            {
                self.embeddedViewController.switchValue = false
            }*/
            vc.conToMaster = self
        }
        if segue.identifier == "OrderSegue"
        {
            let destinationController = segue.destinationViewController as! OrderTableViewController
            //將pickerview資料傳遞至OrderTableView做search
            destinationController.dataDepart = self.embeddedViewController.departPicker.titleLabel?.text
            destinationController.dataQuarter = self.embeddedViewController.quarterPicker.titleLabel?.text
            destinationController.dataSort = self.embeddedViewController.sortPicker.titleLabel?.text
            destinationController.serviceToken = self.serviceToken
            destinationController.errorObject = self.errorObject
            destinationController.internetReachability = self.internetReachability
        }
    }
    
    //設定頁面是否可以旋轉
    override func shouldAutorotate() -> Bool {
        return false
    }
    
    override func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.Portrait
    }
        
    @IBAction func SearchBtnClick(sender: UIButton)
    {
        //先檢核必填欄位
        //print(self.embeddedViewController.departPicker.titleLabel?.text)
        if (self.embeddedViewController.departPicker.titleLabel?.text == "點一下選擇部門")
        {
            let alertController = alertObject.ShowAlert("Alert", ContentString:"部門尚未選取，請重新輸入！", ActionString:"OK")
            self.presentViewController(alertController, animated: true, completion: nil)
        }
        else if (self.embeddedViewController.quarterPicker.titleLabel?.text == "點一下選擇季度")
        {
            let alertController = alertObject.ShowAlert("Alert", ContentString:"季度尚未選取，請重新輸入！", ActionString:"OK")
            self.presentViewController(alertController, animated: true, completion: nil)
        }
        else if (self.embeddedViewController.sortPicker.titleLabel?.text == "點一下選擇排序方式")
        {
            let alertController = alertObject.ShowAlert("Alert", ContentString:"排序方式尚未選取，請重新輸入！", ActionString:"OK")
            self.presentViewController(alertController, animated: true, completion: nil)
        }
        else
        {
            //檢核成功再跳轉至下一頁
            self.performSegueWithIdentifier("OrderSegue", sender: self)
        }
        //self.performSegueWithIdentifier("OrderSegue", sender: self)
    }
    
    @IBAction func LogoutBtnClick(sender: UIBarButtonItem)
    {
        self.performSegueWithIdentifier("LogoutSegue", sender: self)
    }
}
