//
//  GroupedStock.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/8/18.
//  Copyright © 2016年 onto. All rights reserved.
//

import Foundation

class GroupedStock {
    //法人
    var stockSrc:String = ""
    //料號
    var stockImg01:String = ""
    //總數量
    var stockTotalCount:Int
    //庫存陣列
    var stockList = [ListInStockAll]()
    
    init(stockSrc:String, stockImg01:String, stockTotalCount:Int, stockList:[ListInStockAll])
    {
        self.stockSrc = stockSrc
        self.stockImg01 = stockImg01
        self.stockTotalCount = stockTotalCount
        self.stockList = stockList
    }
}