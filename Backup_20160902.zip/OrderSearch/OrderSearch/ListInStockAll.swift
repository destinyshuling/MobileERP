//
//  ListInStockAll.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/8/16.
//  Copyright © 2016年 onto. All rights reserved.
//

import Foundation
import CoreData

//庫存資料
class ListInStockAll:NSManagedObject
{
    //法人
    @NSManaged var src:String
    //料號
    @NSManaged var img01:String
    //品名
    @NSManaged var ima02:String
    //分群碼
    @NSManaged var ima06:String
    //來源碼
    @NSManaged var ima08:String
    //分群碼四
    @NSManaged var ima12:String
    //倉庫
    @NSManaged var img02:String
    //庫存單位
    @NSManaged var img09:String
    //數量
    @NSManaged var img10:String
    //可用否
    @NSManaged var img23:String
}