//
//  StockTableViewCell.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/8/17.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit

class StockTableViewCell: UITableViewCell {
    //法人
    @IBOutlet var src:UILabel!
    //品名
    @IBOutlet var ima02:UILabel!
    //分群碼
    @IBOutlet var ima06:UILabel!
    //料號
    @IBOutlet var img01:UILabel!
    //倉庫
    @IBOutlet var img02:UILabel!
    //庫存單位
    @IBOutlet var img09:UILabel!
    //數量
    @IBOutlet var img10:UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
