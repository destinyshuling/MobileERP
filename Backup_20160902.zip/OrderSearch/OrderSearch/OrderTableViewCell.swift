//
//  OrderTableViewCell.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/6/2.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit

class OrderTableViewCell: UITableViewCell {
    @IBOutlet var orderDate:UILabel!
    @IBOutlet var orderId:UILabel!
    @IBOutlet var orderCustomerId:UILabel!
    @IBOutlet var orderCustomer:UILabel!
    @IBOutlet var orderCurrency:UILabel!
    @IBOutlet var orderAmount:UILabel!
    @IBOutlet var orderStatus:UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
}
