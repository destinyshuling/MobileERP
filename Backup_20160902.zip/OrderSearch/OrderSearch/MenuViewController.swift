//
//  MenuViewController.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/8/9.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit

class MenuViewController: UIViewController {
    //前一頁傳遞過來的資料
    var loginAccount:String!
    var loginName:String!
    var loginDepartment:String!
    var loginAuthorization: String!
    var loginAuthorizationArr: [String] = []
    var serviceToken:String!
    //var errorObject = [ErrorMsg]()
    var errorObject: Dictionary<String, AnyObject> = [:]
    var internetReachability:Reachability!; //網路狀態監控
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        title = "行動ERP"
        let btnName = UIButton()
        btnName.setImage(UIImage(named: "logout-2"), forState: .Normal)
        btnName.frame = CGRectMake(0, 0, 30, 30)
        btnName.addTarget(self, action: #selector(SearchOptionViewController.LogoutBtnClick(_:)), forControlEvents: .TouchUpInside)
        
        //.... Set Right/Left Bar Button item
        let rightBarButton = UIBarButtonItem()
        rightBarButton.customView = btnName
        self.navigationItem.rightBarButtonItem = rightBarButton
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        //直接連結到訂單查詢
        //self.performSegueWithIdentifier("SearchOrderSeque", sender: self)
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        navigationController?.hidesBarsOnSwipe = false
        navigationController?.setNavigationBarHidden(false, animated: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //設定頁面是否可以旋轉
    override func shouldAutorotate() -> Bool {
        return false
    }
    
    override func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.Portrait
    }
    
    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if segue.identifier == "SearchOrderSeque"
        {
            let destinationController = segue.destinationViewController as! SearchOptionViewController
            //將資料傳遞到下一個頁面
            destinationController.loginAccount = self.loginAccount
            destinationController.serviceToken = self.serviceToken
            destinationController.loginName = self.loginName
            destinationController.loginDepartment = self.loginDepartment
            destinationController.errorObject = self.errorObject
            destinationController.loginAuthorizationArr = self.loginAuthorizationArr
            destinationController.internetReachability = self.internetReachability
        }
        else if segue.identifier == "SearchStockSeque"
        {
            let destinationController = segue.destinationViewController as! StockOptionTableViewController
            //將資料傳遞到下一個頁面
            destinationController.loginAccount = self.loginAccount
            destinationController.serviceToken = self.serviceToken
            destinationController.loginName = self.loginName
            destinationController.loginDepartment = self.loginDepartment
            destinationController.errorObject = self.errorObject
            destinationController.loginAuthorizationArr = self.loginAuthorizationArr
            destinationController.internetReachability = self.internetReachability
        }
    }

    @IBAction func OrderBtnClick(sender:AnyObject)
    {
        self.performSegueWithIdentifier("SearchOrderSeque", sender: self)
    }
    
    @IBAction func StockBtnClick(sender:AnyObject)
    {
        //self.performSegueWithIdentifier("SearchStockSeque", sender: self)
        let alertController = UIAlertController(title: "溫馨提醒", message:
             "敬請期待'庫存查詢'！", preferredStyle: UIAlertControllerStyle.Alert)
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default,handler: nil))
        
        self.presentViewController(alertController, animated: true, completion: nil)
    }
    
    @IBAction func LogoutBtnClick(sender: UIBarButtonItem)
    {
        self.performSegueWithIdentifier("LogoutSegue", sender: self)
    }
}
