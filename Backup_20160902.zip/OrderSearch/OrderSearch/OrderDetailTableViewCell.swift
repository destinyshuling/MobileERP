//
//  OrderDetailTableViewCell.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/6/2.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit

class OrderDetailTableViewCell: UITableViewCell {
    @IBOutlet var item:UILabel!
    @IBOutlet var partnumber:UILabel!
    @IBOutlet var desc:UILabel!
    @IBOutlet var salesunit:UILabel!
    @IBOutlet var qty:UILabel!
    @IBOutlet var unitprice:UILabel!
    @IBOutlet var paidqty:UILabel!
    @IBOutlet var unpaidqty:UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
}