//
//  OrderDetailViewController.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/6/2.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit

class OrderDetailViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UIPopoverPresentationControllerDelegate {

    @IBOutlet var orderId:UILabel!
    @IBOutlet var orderDate:UILabel!
    @IBOutlet var orderAmount:UILabel!
    @IBOutlet var orderDetailView:UITableView!
    
    var jsonResult = JsonParser()
    var alertObject = ShowAlert()
    weak var activityIndicatorView: UIActivityIndicatorView!
    var activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
    
    var order:Order!
    var orderDetails = [OrderDetail]()
    var serviceToken:String!
    //var errorObject = [ErrorMsg]()
    var errorObject: Dictionary<String, AnyObject> = [:]
    //let d2 : [String:String] = [:]
    var internetReachability:Reachability!; //網路狀態監控
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //顯示等候視窗
        view.addSubview(activityIndicator)
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        activityIndicator.color = UIColor.redColor()
        activityIndicator.hidesWhenStopped = true
        let horizontalConstraint = NSLayoutConstraint(item: activityIndicator, attribute: NSLayoutAttribute.CenterX, relatedBy: NSLayoutRelation.Equal, toItem: view, attribute: NSLayoutAttribute.CenterX, multiplier: 1, constant: 0)
        view.addConstraint(horizontalConstraint)
        
        let verticalConstraint = NSLayoutConstraint(item: activityIndicator, attribute: NSLayoutAttribute.CenterY, relatedBy: NSLayoutRelation.Equal, toItem: view, attribute: NSLayoutAttribute.CenterY, multiplier: 1, constant: 0)
        view.addConstraint(verticalConstraint)
        
        activityIndicator.startAnimating()
        activityIndicator.hidden = false
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        title = "訂單明細"
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        //先檢查網路連線
        let networksStatus: NetworkStatus = self.internetReachability.currentReachabilityStatus()
        if networksStatus == NotReachable {
            let alertController = alertObject.ShowAlert("Error", ContentString:"未偵測到網路連線，無法查詢資料！", ActionString:"OK")
            self.presentViewController(alertController, animated: true, completion: nil)
        }
        else
        {
            let service = "http://103.227.33.247/F1SV/json/listOrderDetail.json?orderNumber=" + order.OrderId
            let (succeed, errorMsg) = postJsonUseByOrderQuery(service, atoken: serviceToken)
            if (!succeed)
            {
                let alertController = alertObject.ShowAlert("Json Error", ContentString:errorMsg, ActionString:"OK")
                self.presentViewController(alertController, animated: true, completion: nil)
            }
            self.orderDetailView.reloadData()
        }
        activityIndicator.stopAnimating()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 2
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if section == 0
        {
            return 5
        }
        else
        {
            return orderDetails.count
        }
    }
    
    func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String?
    {
        if section == 0
        {
            return order.OrderId
        }
        else
        {
            return "單身"
        }
    }
    
    func tableView(tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int)
    {
        var headerTitle:String = ""
        if section == 0
        {
            headerTitle = order.OrderId
        }
        else
        {
            headerTitle = "單身"
        }
        
        let title = UILabel()
        title.font = UIFont(name: headerTitle, size: 30)
        title.textColor = UIColor.blackColor()
        
        let header = view as! UITableViewHeaderFooterView
        header.textLabel?.font=title.font
        header.textLabel?.textColor=title.textColor
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50.0
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        if indexPath.section == 0
        {
            let cell = tableView.dequeueReusableCellWithIdentifier("OrderDetailHeaderCell", forIndexPath: indexPath) as! OrderDetailHeaderTableViewCell
            switch indexPath.row {
            case 0:
                cell.title.text = "訂單日期"
                cell.content.text = order.OrderDate
            case 1:
                cell.title.text = "客戶代號"
                cell.content.text = order.OrderCustomerId
            case 2:
                cell.title.text = "客戶簡稱"
                cell.content.text = order.OrderCustomer
            case 3:
                cell.title.text = "訂單幣別"
                cell.content.text = "\(order.OrderCurrency)"
            case 4:
                cell.title.text = "訂單金額"
                cell.content.text = String.stringSeparsted(order.OrderAmount)
            default:
                cell.title.text = ""
                cell.content.text = ""
            }
            return cell
        }
        else
        {
            let cell = tableView.dequeueReusableCellWithIdentifier("OrderDetailCell", forIndexPath: indexPath) as! OrderDetailTableViewCell
            let unitprice = Double(orderDetails[indexPath.row].unitprice)
            
            // Configure the cell...
            cell.item.text = orderDetails[indexPath.row].item
            cell.partnumber.text = orderDetails[indexPath.row].partnumber
            cell.desc.text = orderDetails[indexPath.row].description
            cell.salesunit.text = orderDetails[indexPath.row].salesunit
            cell.qty.text = orderDetails[indexPath.row].qty
            cell.unitprice.text = String.stringSeparsted(unitprice!)
            cell.paidqty.text = orderDetails[indexPath.row].paidqty
            cell.unpaidqty.text = orderDetails[indexPath.row].unpaidqty
            
            return cell
        }
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if indexPath.section == 1
        {
            let cell:UITableViewCell? = tableView.cellForRowAtIndexPath(indexPath)
            let selectedCellSourceView = tableView.cellForRowAtIndexPath(indexPath)
            let selectedCellSourceRect = cell!.bounds
            
            let popover = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("popover") as! OrderDetailPopoverViewController
            
            popover.modalPresentationStyle = UIModalPresentationStyle.Popover
            popover.popoverPresentationController?.backgroundColor = UIColor(red:250.0/255.0, green:220.0/255.0, blue: 220.0/255.0, alpha: 0.7)
            popover.popoverPresentationController?.delegate = self
            popover.popoverPresentationController?.sourceView = selectedCellSourceView
            popover.popoverPresentationController?.sourceRect = selectedCellSourceRect
            popover.preferredContentSize = CGSizeMake(280, 200)
            
            //傳遞data
            let unitprice = Double(orderDetails[indexPath.row].unitprice)
            let item = orderDetails[indexPath.row].item
            
            popover.strItem = item
            popover.strPartnumber = orderDetails[indexPath.row].partnumber
            popover.strDesc = orderDetails[indexPath.row].description
            popover.strQty = orderDetails[indexPath.row].qty
            popover.strUnitprice = String.stringSeparsted(unitprice!)
            popover.strSalesunit = orderDetails[indexPath.row].salesunit
            popover.strPaidqty = orderDetails[indexPath.row].paidqty
            popover.strUnpaidqty = orderDetails[indexPath.row].unpaidqty
            
            self.presentViewController(popover, animated: true, completion: nil)
            
            /*let VC = storyboard?.instantiateViewControllerWithIdentifier("popover") as! OrderDetailPopoverViewController
             VC.preferredContentSize = CGSizeMake(200, 200)
             let navController = UINavigationController(rootViewController: VC)
             navController.modalPresentationStyle = UIModalPresentationStyle.Popover
             let popover = navController.popoverPresentationController
             popover?.delegate = self
             
             popover?.sourceView = self.view
             popover?.sourceRect = CGRectMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds),0,0)
             popover?.permittedArrowDirections = UIPopoverArrowDirection()
             
             self.presentViewController(navController, animated: true, completion: nil)*/
        }
    }
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
     if editingStyle == .Delete {
     // Delete the row from the data source
     tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
     } else if editingStyle == .Insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat
    {
        if indexPath.section == 0
        {
            return 40
        }
        else
        {
            return 80
        }
    }
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        /*if segue.identifier == "showPopover"
        {
            /*if let indexPath = tableView.indexPathForSelectedRow{
                let destinationController = segue.destinationViewController as! OrderDetailViewController
                //將客戶資料傳遞到下一個頁面
                if searchController.active
                {
                    destinationController.order = searchOrders[indexPath.row]
                }
                else
                {
                    destinationController.order = ordersArray[indexPath.section][indexPath.row]
                }
                destinationController.serviceToken = serviceToken
                destinationController.errorObject = errorObject
                destinationController.internetReachability = internetReachability
            }*/
            let vc = segue.destinationViewController
            vc.preferredContentSize = CGSizeMake(200, 200)
            let controller = vc.popoverPresentationController
            if controller != nil
            {
                controller?.delegate = self
            }
        }*/
    }
    
    func adaptivePresentationStyleForPresentationController(controller: UIPresentationController) -> UIModalPresentationStyle {
        return .None
    }
    
    //設定頁面是否可以旋轉
    override func shouldAutorotate() -> Bool {
        return true
    }
    
    override func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.AllButUpsideDown
    }
    
    //查詢訂單單頭ＪＳＯＮ
    func postJsonUseByOrderQuery(serviceLink:String, atoken:String) -> (Bool, String)
    {
        var succeed:Bool = false
        var errorMag:String = ""
        let request = NSMutableURLRequest(URL: NSURL(string: serviceLink)!)
        request.HTTPMethod = "GET"
        //GET要塞入的Header
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue(atoken, forHTTPHeaderField: "atoken")
        
        var response: NSURLResponse?
        do {
            let resData = try NSURLConnection.sendSynchronousRequest(request, returningResponse: &response)
            
            //處理回傳的Body -> Json 格式
            //let myData = NSString(data:resData, encoding: NSUTF8StringEncoding) as! String
            var json: Array<AnyObject>  //不知道為什麼一定要放在這一行，json才不會是nil.....
            do {
                json = try NSJSONSerialization.JSONObjectWithData(resData, options: .MutableLeaves) as! Array
                //解析body
                for jsonpattern in json{
                    let tOrderdetail:OrderDetail = OrderDetail(item: jsonpattern["oeb03"] as! String, partnumber: jsonpattern["oeb04"] as! String, description: jsonpattern["oeb06"] as! String, salesunit: jsonpattern["oeb05"] as! String, qty: jsonpattern["oeb12"] as! String, unitprice: jsonpattern["oeb13"] as! String, paidqty: jsonpattern["oeb24"] as! String, unpaidqty: jsonpattern["oeb23b"] as! String)
                    orderDetails.append(tOrderdetail)
                }
                succeed = true
                
            } catch let dataError {
                // Did the JSONObjectWithData constructor return an error? If so, log the error to the console
                print(dataError)
                let jsonStr = NSString(data: resData, encoding: NSUTF8StringEncoding)
                print("Error could not parse JSON. \r\n '\(jsonStr)'")
                errorMag = "Error could not parse JSON. \r\n '\(jsonStr)'"
                succeed = false
            }
            //處理回傳的Header -> 包含資料總筆數
            if let response = response as? NSHTTPURLResponse {
                if response.statusCode == 200 {
                    let resultCode = response.allHeaderFields["statusCd"] as! String
                    if resultCode != "5000"  //"執行成功"
                    {
                        var errorMsg = ""
                        if resultCode == "5001" //timeout
                        {
                            errorMag = "超過３０分鐘未操作，已自動登出，請重新登入！"
                            let alertController = alertObject.ShowAlert("溫馨提醒", ContentString:errorMag, ActionString:"OK")
                            self.presentViewController(alertController, animated: true, completion: nil)
                        }
                        else
                        {
                            errorMsg = ReadErrorMsg(resultCode)
                            let alertController = alertObject.ShowAlert("Alert", ContentString:"Server回傳資料有誤！[\(resultCode)]\r\n\(errorMsg)", ActionString:"OK")
                            self.presentViewController(alertController, animated: true, completion: nil)
                        }
                    }
                }
            }
        } catch {
            print("Send request error.\r\n '\(error)'")
            errorMag = "Send request error.\r\n '\(error)'"
            succeed = false
        }
        
        return (succeed, errorMag)
    }
    
    func ReadErrorMsg(errorCode:String) -> String
    {
        return errorObject[errorCode] as! String
    }
}
