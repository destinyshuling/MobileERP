//
//  StockTableViewController.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/8/17.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit
import CoreData

class StockTableViewController: UITableViewController {

    //前一頁傳遞過來的資料
    var loginAccount:String!
    var loginName:String!
    var loginDepartment:String!
    var loginAuthorizationArr:[String] = []
    var serviceToken:String!
    var errorObject:Dictionary<String, AnyObject> = [:]
    var internetReachability:Reachability!; //網路狀態監控
    
    //儲存庫存查詢結果
    var stockResultArr:[ListInStockAll] = []
    
    //庫存分群
    var stockClassify = [String]()
    var stocksArray = [[ListInStockAll]]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        title = "庫存總覽"
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        //將庫存資料分群
        classifyStocks()
        
        self.tableView.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 3
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return stockResultArr.count
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("StockCell", forIndexPath: indexPath) as! StockTableViewCell
        
        // Configure the cell...
        /*cell.src.text = stockResultArr[indexPath.row].src
        switch stockResultArr[indexPath.row].src {
        case "ZYTW":
            cell.src.text = "正一台灣"
        case "ZYLH":
            cell.src.text = "正一龍華"
        case "ZYHEN":
            cell.src.text = "正一河南"
        default:
            cell.src.text = "正一"
        }*/
        //料號
        cell.img01.text = stockResultArr[indexPath.row].img01
        //品名
        cell.ima02.text = stockResultArr[indexPath.row].ima02
        //庫存單位
        cell.img09.text = stockResultArr[indexPath.row].img09
        //數量
        cell.img10.text = stockResultArr[indexPath.row].img10
        
        //分群碼
        //let na1 = SearchCoreData("imz01 = '\(stockResultArr[indexPath.row].ima06)'", tableName: "ListImz")
        //cell.ima06.text = "[\(stockResultArr[indexPath.row].ima06)] \(na1)"
        
        //倉庫
        //let na2 = SearchCoreData("imd01 = '\(stockResultArr[indexPath.row].img02)'", tableName: "ListImd")
        //cell.img02.text = "[\(stockResultArr[indexPath.row].img02)] \(na2)"
        
        return cell
    }

    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat
    {
        //Choose your custom row height
        return 70.0
    }
    
    override func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String?
    {
        var headerTitle:String = ""
        switch section {
        case 0:
            headerTitle = "正一台灣"
        case 1:
            headerTitle = "正一龍華"
        case 2:
            headerTitle = "正一河南"
        default:
            headerTitle = ""
        }
        return headerTitle
    }
    
    override func tableView(tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int)
    {
        var headerTitle:String = ""
        
        switch section {
        case 0:
            headerTitle = "正一台灣"
        case 1:
            headerTitle = "正一龍華"
        case 2:
            headerTitle = "正一河南"
        default:
            headerTitle = ""
        }
        
        let title = UILabel()
        title.font = UIFont(name: headerTitle, size: 30)
        title.textColor = UIColor.lightGrayColor()
        
        let header = view as! UITableViewHeaderFooterView
        header.textLabel?.font=title.font
        header.textLabel?.textColor=title.textColor
    }
    
    override func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 45.0
    }
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    //查詢CoreData 倉庫名稱/分群碼說明
    func SearchCoreData(query:String, tableName:String) -> String
    {
        var value:String = ""
        //使用CoreData取得資料
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as? AppDelegate)?.managedObjectContext
        {
            let fetchRequest = NSFetchRequest(entityName: tableName)
            let predicate = NSPredicate(format: query)
            fetchRequest.predicate = predicate
            do{
                if tableName == "ListImd"
                {
                    //查詢倉庫
                    let classArray = try managedObjectContext.executeFetchRequest(fetchRequest) as! [ListImd]
                    if classArray.count > 0
                    {
                        value = classArray[0].imd02
                    }
                }
                else if tableName == "ListImz"
                {
                    //查詢分群碼
                    let classArray = try managedObjectContext.executeFetchRequest(fetchRequest) as! [ListImz]
                    if classArray.count > 0
                    {
                        value = classArray[0].imz02
                    }
                }
                
            } catch{
                print(error)
            }
        }
        return value
    }
    
    //將庫存資料分群 stockResultArr -> stocksArray
    func classifyStocks()
    {
        var currStock:ListInStockAll!

        for i in 0 ..< stockResultArr.count  //for stock in stockResultArr
        {
            let stock:ListInStockAll = stockResultArr[i]
            
            if i != 0 && stock.src == currStock.src && stock.img01 == currStock.img01
            {
                //法人和料號一致時，直接加總
                currStock.img10 = currStock.img10 + stock.img10
            }
            else
            {
                let keyvalue:String = currStock.src
                if stockClassify.contains(keyvalue)
                {
                    let index = stockClassify.indexOf({$0 == keyvalue})! as Int
                    stocksArray[index].append(currStock)
                }
                else
                {
                    // item not found
                    var tstockArray = [ListInStockAll]()
                    tstockArray.append(currStock)
                    stocksArray.append(tstockArray)
                    
                    stockClassify.append(keyvalue)
                }
                currStock = stock
            }
        }
    }
}
