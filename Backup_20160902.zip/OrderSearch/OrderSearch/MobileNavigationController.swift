//
//  MobileNavigationController.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/7/15.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit

class MobileNavigationController: UINavigationController {
    //設定頁面是否可以旋轉 -> 依據Navigation Controller的topView決定是否要轉向
    override func shouldAutorotate() -> Bool {
        return self.topViewController!.shouldAutorotate()
    }
    
    override func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        return self.topViewController!.supportedInterfaceOrientations()
    }
}
