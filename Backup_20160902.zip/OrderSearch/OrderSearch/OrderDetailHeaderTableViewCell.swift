//
//  OrderDetailHeaderTableViewCell.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/6/23.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit

class OrderDetailHeaderTableViewCell: UITableViewCell {
    @IBOutlet var title:UILabel!
    @IBOutlet var content:UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
}
