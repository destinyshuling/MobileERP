//
//  OrderTableViewController.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/5/24.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit
import CoreData
import MessageUI

class OrderTableViewController: UITableViewController, NSFetchedResultsControllerDelegate, UISearchResultsUpdating, MFMailComposeViewControllerDelegate, SectionHeaderViewDelegate
{
    //查詢頁面傳遞過來的資料內容
    var dataDepart:String!
    var dataQuarter:String!
    var dataSort:String!
    var serviceToken:String!
    var dataSortCode:String!
    //var errorObject = [ErrorMsg]()
    var errorObject: Dictionary<String, AnyObject> = [:]
    var internetReachability:Reachability!; //網路狀態監控
    
    var jsonResult = JsonParser()
    var alertObject = ShowAlert()
    
    var orders = [Order]()
    //儲存搜尋完的訂單資料
    var searchOrders = [Order]()
    
    //分群訂單array
    var ordersClassify = [String]()
    var ordersTotalAmount = [Int]()
    var ordersArray = [[Order]]()
    //2016/08/19 整頁訂單總金額
    var ordersAmount:Int = 0
    
    //Custom Class Array -> test failed by 6/22
    //var orderCollection = [GroupedOrder]()
    
    weak var activityIndicatorView: UIActivityIndicatorView!
    var activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
    
    //搜尋欄
    var searchController:UISearchController!
    var fetchResultController:NSFetchedResultsController!
    
    var tableViewHeader:UIView!
    var headerAmount:UILabel!
    
    //表格縮合
    let SectionHeaderViewIdentifier = "SectionHeaderViewIdentifier"
    var plays:NSArray!
    var sectionInfoArray:NSMutableArray!
    var pinchedIndexPath:NSIndexPath!
    var opensectionindex:Int!
    var initialPinchHeight:CGFloat!
    
    var ordersCollection:NSMutableArray! = NSMutableArray()
    var sectionHeaderView:SectionHeaderView!
    
    //当缩放手势同时改变了所有单元格高度时使用uniformRowHeight
    var uniformRowHeight: Int!
    let DefaultRowHeight = 70
    let HeaderHeight = 45
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //顯示等候視窗
        view.addSubview(activityIndicator)
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        activityIndicator.color = UIColor.redColor()
        activityIndicator.hidesWhenStopped = true
        let horizontalConstraint = NSLayoutConstraint(item: activityIndicator, attribute: NSLayoutAttribute.CenterX, relatedBy: NSLayoutRelation.Equal, toItem: view, attribute: NSLayoutAttribute.CenterX, multiplier: 1, constant: 0)
        view.addConstraint(horizontalConstraint)
        
        let verticalConstraint = NSLayoutConstraint(item: activityIndicator, attribute: NSLayoutAttribute.CenterY, relatedBy: NSLayoutRelation.Equal, toItem: view, attribute: NSLayoutAttribute.CenterY, multiplier: 1, constant: 0)
        view.addConstraint(verticalConstraint)
        
        activityIndicator.startAnimating()
        activityIndicator.hidden = false
        
        //顯示搜尋欄
        searchController = UISearchController(searchResultsController: nil)
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "訂單客戶..."
        //self.tableView.tableHeaderView = searchController.searchBar
        
        /*let tableViewHeader = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 80))
        tableViewHeader.backgroundColor = UIColor.lightTextColor()
        tableViewHeader.addSubview(searchController.searchBar)
        
        let headerAmount = UILabel(frame: CGRectMake(8, 40, tableView.frame.width, 40))
        headerAmount.font = headerAmount.font.fontWithSize(18)
        headerAmount.text = "總金額：NTD$ 3,472,972,859"
        headerAmount.textColor = UIColor.blueColor()
        headerAmount.textAlignment = .Center;
        tableViewHeader.addSubview(headerAmount)
        
        self.tableView.tableHeaderView = tableViewHeader*/
        
        //Footer
        /*let tableViewFooter = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 50))
        tableViewFooter.backgroundColor = UIColor.lightGrayColor()
        let version = UILabel(frame: CGRectMake(8, 15, tableView.frame.width, 30))
        version.font = version.font.fontWithSize(14)
        version.text = "Version 1.x"
        version.textColor = UIColor.blueColor()
        version.textAlignment = .Center;
        tableViewFooter.addSubview(version)
        tableView.tableFooterView  = tableViewFooter*/
        
        //設定view標題
        title = "訂單總覽"
        
        // 为表视图添加缩放手势识别
        let pinchRecognizer = UIPinchGestureRecognizer(target: self, action:"handlePinch:")
        self.tableView.addGestureRecognizer(pinchRecognizer)
        
        // 分节信息数组在viewWillUnload方法中将被销毁，因此在这里设置Header的默认高度是可行的。如果您想要保留分节信息等内容，可以在指定初始化器当中设置初始值。
        self.uniformRowHeight = DefaultRowHeight
        self.opensectionindex = NSNotFound
        
        let sectionHeaderNib: UINib = UINib(nibName: "SectionHeaderView", bundle: nil)
        self.tableView.registerNib(sectionHeaderNib, forHeaderFooterViewReuseIdentifier: SectionHeaderViewIdentifier)
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        //先檢查網路連線
        let networksStatus: NetworkStatus = self.internetReachability.currentReachabilityStatus()
        if networksStatus == NotReachable {
            let alertController = alertObject.ShowAlert("Error", ContentString:"未偵測到網路連線，無法查詢資料！", ActionString:"OK")
            self.presentViewController(alertController, animated: true, completion: nil)
        }
        else
        {
            if ordersClassify.count == 0
            {
                var result = false
                var loopCount = 1
                let service = MakeOrderQuery()
                
                repeat {
                    let (succeed, errorMsg) = postJsonUseByOrderQuery(service, atoken: serviceToken)
                    result = succeed
                    if (!succeed)
                    {
                        let alertController = alertObject.ShowAlert("Alert \(loopCount)", ContentString:errorMsg, ActionString:"OK")
                        self.presentViewController(alertController, animated: true, completion: nil)
                    }
                    else
                    {
                        //建立section info
                        createSectionInfo()
                        
                        self.tableView.reloadData()
                        searchController.searchBar.placeholder = "訂單客戶..."
                        
                        //＄\(String.stringSeparsted(amount)) NTD"
                        tableViewHeader = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 80))
                        tableViewHeader.backgroundColor = UIColor(red: 242.0/255.0, green: 220.0/255.0, blue: 219.0/255.0, alpha: 1.0)
                        tableViewHeader.addSubview(searchController.searchBar)
                        
                        headerAmount = UILabel(frame: CGRectMake(0, 43, tableView.frame.width, 40))
                        headerAmount.font = headerAmount.font.fontWithSize(18)
                        headerAmount.text = "訂單總額：NTD $ \(String.stringSeparsted(Double(ordersAmount)))"
                        headerAmount.textColor = UIColor(red: 196.0/255.0, green: 1.0/255.0, blue: 5.0/255.0, alpha: 1.0)
                        headerAmount.textAlignment = .Center;
                        tableViewHeader.addSubview(headerAmount)
                        
                        self.tableView.tableHeaderView = tableViewHeader
                    }
                    
                    loopCount = loopCount + 1
                }while(!result && loopCount <= 3)
                
                activityIndicator.stopAnimating()
            }
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        if searchController.active
        {
            return 1
        }
        else
        {
            return ordersClassify.count
        }
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        //return orders.count
        if searchController.active
        {
            return searchOrders.count
        }
        else
        {
            //return ordersArray[section].count
            //return (ordersCollection![section] as! GroupedOrder).OrderArray.count
            
            let sectioninfo: SectionInfo = self.sectionInfoArray[section] as! SectionInfo
            let numInSection = sectioninfo.grouporders.OrderArray.count
            let sectionOpen = sectioninfo.open
            return (sectionOpen != nil && sectionOpen == true) ? numInSection : 0
        }
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("OrderCell", forIndexPath: indexPath) as! OrderTableViewCell
        // Configure the cell... Section \(indexPath.section)
        if searchController.active
        {
            cell.orderId.text = searchOrders[indexPath.row].OrderId
            cell.orderDate.text = searchOrders[indexPath.row].OrderDate
            cell.orderCustomer.text = searchOrders[indexPath.row].OrderCustomer
            cell.orderCustomerId.text = searchOrders[indexPath.row].OrderCustomerId
            cell.orderAmount.text = String.stringSeparsted(searchOrders[indexPath.row].OrderAmount)
            cell.orderCurrency.text = searchOrders[indexPath.row].OrderCurrency
            if (searchOrders[indexPath.row].OrderStatus == "0" )
            {
                let image : UIImage = UIImage(named: "status_done")!
                cell.orderStatus.image = image
            }
            else
            {
                let image : UIImage = UIImage(named: "status_going")!
                cell.orderStatus.image = image
            }
        }
        else
        {
            /*cell.orderId.text = ordersArray[indexPath.section][indexPath.row].OrderId
            cell.orderDate.text = ordersArray[indexPath.section][indexPath.row].OrderDate
            cell.orderCustomer.text = ordersArray[indexPath.section][indexPath.row].OrderCustomer
            cell.orderCustomerId.text = ordersArray[indexPath.section][indexPath.row].OrderCustomerId
            cell.orderAmount.text = String.stringSeparsted(ordersArray[indexPath.section][indexPath.row].OrderAmount)
            cell.orderCurrency.text = ordersArray[indexPath.section][indexPath.row].OrderCurrency
            if (ordersArray[indexPath.section][indexPath.row].OrderStatus == "0")
            {
                let image : UIImage = UIImage(named: "status_done")!
                cell.orderStatus.image = image
            }
            else
            {
                let image : UIImage = UIImage(named: "status_going")!
                cell.orderStatus.image = image
            }*/
            
            //
            let arr:GroupedOrder = ordersCollection![indexPath.section] as! GroupedOrder
            let torder:Order = arr.OrderArray[indexPath.row] as! Order
            cell.orderId.text = torder.OrderId
            cell.orderDate.text = torder.OrderDate
            cell.orderCustomer.text = torder.OrderCustomer
            cell.orderCustomerId.text = torder.OrderCustomerId
            cell.orderAmount.text = String.stringSeparsted(torder.OrderAmount)
            cell.orderCurrency.text = torder.OrderCurrency
            if (torder.OrderStatus == "0")
            {
                let image : UIImage = UIImage(named: "status_done")!
                cell.orderStatus.image = image
            }
            else
            {
                let image : UIImage = UIImage(named: "status_going")!
                cell.orderStatus.image = image
            }
        }
        return cell
    }
 
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat
    {
        //Choose your custom row height
        return 70.0
    }
    
    override func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        var headerTitle:String = ""
        //let amountNt = Double(round(ordersTotalAmount[section]))  //四捨五入
        let amountNt = Double(ordersTotalAmount[section])  //四捨五入
        if searchController.active
        {
            headerTitle = "搜尋結果 (\(searchOrders.count))"
        }
        else
        {
            /*switch dataSort {
            case "訂單客戶":
                headerTitle = "\(ordersArray[section][0].OrderCustomer)"  //-\(ordersClassify[section])
            case "訂單日期":
                headerTitle = "\(ordersClassify[section])"
            case "訂單狀態":
                if ordersClassify[section] == "0"
                {
                    headerTitle = "已結"
                }else
                {
                    headerTitle = "未結"
                }
            default:
                headerTitle = ""
            }
            //headerTitle = headerTitle + " (\(ordersArray[section].count))"
            headerTitle = headerTitle + " (\((ordersCollection![section] as! GroupedOrder).OrderArray.count))"*/
            
            headerTitle = "\((ordersCollection![section] as! GroupedOrder).GroupedName) (\((ordersCollection![section] as! GroupedOrder).OrderArray.count))"
        }
        
        //section header
        /*let headerView = UIView()
        let title = UILabel(frame: CGRectMake(8, 0, (tableView.frame.width)*0.4 - 8, 45))
        title.font = title.font.fontWithSize(18)
        title.text = headerTitle
        title.textColor = UIColor.lightGrayColor()
        title.textAlignment = .Left;  // 靠左顯示分群名稱
        headerView.addSubview(title)
        
        if searchController.active
        {
            headerAmount.text = ""            
        }
        else
        {
            //section header
            let amount = UILabel(frame: CGRectMake((tableView.frame.width)*0.4, 0, (tableView.frame.width)*0.6 - 8, 45))
            amount.font = title.font.fontWithSize(18)
            amount.text = "NTD＄\(String.stringSeparsted(amountNt))"
            amount.textColor = UIColor(red: 185.0/255.0, green: 122.0/255.0, blue: 87.0/255.0, alpha: 1.0)
            amount.textAlignment = .Right;  // 靠右顯示分群金額
            headerView.addSubview(amount)
            
            headerAmount.text = "訂單總額：NTD $ \(String.stringSeparsted(Double(ordersAmount)))"
        }*/
        
        // 返回指定的 section header 的view，如果没有，这个函数可以不返回view
        let sectionHeaderView: SectionHeaderView = self.tableView.dequeueReusableHeaderFooterViewWithIdentifier(SectionHeaderViewIdentifier) as! SectionHeaderView
        
        let sectionInfo: SectionInfo = self.sectionInfoArray[section] as! SectionInfo
        sectionInfo.headerView = sectionHeaderView
        
        /*let amount = UILabel(frame: CGRectMake((tableView.frame.width)*0.4, 0, (tableView.frame.width)*0.6 - 8, 50))
        amount.text = "NTD＄\(String.stringSeparsted(amountNt))"
        amount.textColor = UIColor(red: 185.0/255.0, green: 122.0/255.0, blue: 87.0/255.0, alpha: 1.0)
        amount.textAlignment = .Right;  // 靠右顯示分群金額
        sectionHeaderView.addSubview(amount)*/
        
        //sectionHeaderView.contentView.backgroundColor = UIColor.lightGrayColor()
        sectionHeaderView.titleLabel.text = headerTitle
        sectionHeaderView.amount.text = "NTD＄\(String.stringSeparsted(amountNt))"
        sectionHeaderView.amount.textColor = UIColor(red: 185.0/255.0, green: 122.0/255.0, blue: 87.0/255.0, alpha: 1.0)
        sectionHeaderView.section = section
        sectionHeaderView.delegate = self
        
        return sectionHeaderView
    }

    /*override func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String?
    {
        var headerTitle:String = ""
        if searchController.active
        {
            return "搜尋結果 (\(searchOrders.count))"
        }
        else
        {
            switch dataSort {
            case "訂單客戶":
                headerTitle = "\(ordersArray[section][0].OrderCustomer)"  //-\(ordersClassify[section])
            case "訂單日期":
                headerTitle = "\(ordersClassify[section])"
            case "訂單狀態":
                if ordersClassify[section] == "0"
                {
                    headerTitle = "已結"
                }else
                {
                    headerTitle = "未結"
                }
            default:
                headerTitle = ""
            }
            
            //四捨五入
            let amount = Double(round(ordersTotalAmount[section]))
            
            return headerTitle + " (\(ordersArray[section].count))  NTD＄\(String.stringSeparsted(amount)) "
        }
    }
    
    override func tableView(tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int)
    {
        var headerTitle:String = ""
        if searchController.active
        {
            headerTitle = "搜尋結果 (\(searchOrders.count))"
        }
        else
        {
            switch dataSort {
            case "訂單客戶":
                headerTitle = "\(ordersArray[section][0].OrderCustomer)-\(ordersClassify[section])"
            case "訂單日期":
                headerTitle = "\(ordersClassify[section])"
            case "訂單狀態":
                if ordersClassify[section] == "0"
                {
                    headerTitle = "已結"
                }else
                {
                    headerTitle = "未結"
                }
            default:
                headerTitle = ""
            }
        }
        
        let title = UILabel()
        title.font = UIFont(name: headerTitle, size: 30)
        title.textColor = UIColor.lightGrayColor()
        title.textAlignment = .Left
        
        let header = view as! UITableViewHeaderFooterView
        header.textLabel?.font = title.font
        header.textLabel?.textColor = title.textColor
    }*/
    
    override func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 45.0
    }
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if segue.identifier == "OrderDetailSegue"
        {
            if let indexPath = tableView.indexPathForSelectedRow{
                let destinationController = segue.destinationViewController as! OrderDetailViewController
                //將客戶資料傳遞到下一個頁面
                if searchController.active
                {
                    destinationController.order = searchOrders[indexPath.row]
                }
                else
                {
                    destinationController.order = ordersArray[indexPath.section][indexPath.row]
                }
                destinationController.serviceToken = serviceToken
                destinationController.errorObject = errorObject
                destinationController.internetReachability = internetReachability
            }
        }
    }
    
    //設定頁面是否可以旋轉
    override func shouldAutorotate() -> Bool {
        return true
    }
    
    override func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.AllButUpsideDown
    }
    
    //***************************************************************************************************************************
    //組web service link
    func MakeOrderQuery() -> String
    {
        var dataDepartCode:String!
        var dataQuarterCode:String!
        var serviceLink:String!
        
        switch dataDepart {
        case "材化一部":
            dataDepartCode = "111"
        case "材化二部":
            dataDepartCode = "112"
        case "材化三部":
            dataDepartCode = "113"
        case "材化四部":
            dataDepartCode = "114"
        case "材化五部":
            dataDepartCode = "115"
        case "材化六部":
            dataDepartCode = "116"
        default:
            dataDepartCode = ""
        }
        
        //去除字串內的空格，2016 Q2 -> 2016Q2
        dataQuarterCode = dataQuarter.stringByReplacingOccurrencesOfString(" ", withString: "")
        
        //組合web service link
        serviceLink = "http://103.227.33.247/F1SV/json/listOrder.json?customerCode=&yearQuarter=" + dataQuarterCode + "&oea15Cd3=" + dataDepartCode + "&pageNo=0"
        
        return serviceLink
    }
    
    //查詢訂單單頭ＪＳＯＮ
    func postJsonUseByOrderQuery(serviceLink:String, atoken:String) -> (Bool, String)
    {
        var succeed:Bool = false
        var errorMag:String = ""
        let request = NSMutableURLRequest(URL: NSURL(string: serviceLink)!)
        request.HTTPMethod = "GET"
        //GET要塞入的Header
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue(atoken, forHTTPHeaderField: "atoken")
        
        ordersAmount = 0
        var response: NSURLResponse?
        do {
            let resData = try NSURLConnection.sendSynchronousRequest(request, returningResponse: &response)
            
            //若是以狀態排序，未結訂單要排序在上方
            if dataSort == "訂單狀態"
            {
                ordersClassify.append("1")
                ordersClassify.append("0")
                //2016/08/19
                ordersTotalAmount.append(0)
                ordersTotalAmount.append(0)
                
                let torderArray = [Order]()
                ordersArray.append(torderArray)
                ordersArray.append(torderArray)
            }
            
            //處理回傳的Body -> Json 格式
            //let myData = NSString(data:resData, encoding: NSUTF8StringEncoding) as! String
            var json: Array<AnyObject>  //不知道為什麼一定要放在這一行，json才不會是nil.....
            do {
                json = try NSJSONSerialization.JSONObjectWithData(resData, options: .MutableLeaves) as! Array
                //解析body
                for jsonpattern in json{
                    //訂單總金額
                    let strVar : String = jsonpattern["oea61"] as! String
                    let amount = NSString(string: strVar)

                    //訂單總金額（台幣）
                    let amount2 : Int = jsonpattern["oea61twd"] as! Int
                    //let amount2 = NSString(string: strVar2)
                    
                    let tOrder:Order = Order(orderDate: jsonpattern["oea02"] as! String, orderId: jsonpattern["oea01"] as! String, orderCustomerId: jsonpattern["oea03"] as! String, orderCustomer: jsonpattern["oea032"] as! String, orderCurrency: jsonpattern["oea23"] as! String, orderAmount: amount.doubleValue, orderDepart: jsonpattern["oea15"] as! String, orderStatus: jsonpattern["oeb23bSum"] as! String, orderTwdAmount: amount2)
                    orders.append(tOrder)
                    
                    ordersAmount = ordersAmount + amount2
                    //將訂單資料分群
                    //classifyOrders(tOrder)
                    
                    //使用NSMutableArray儲存分群資料
                    classifyMutableArrayOrders(tOrder)
                }
                succeed = true
                
            } catch let dataError {
                // Did the JSONObjectWithData constructor return an error? If so, log the error to the console
                //print(dataError)
                let jsonStr = NSString(data: resData, encoding: NSUTF8StringEncoding)
                //print("Error could not parse JSON. \r\n '\(jsonStr)'")
                errorMag = "Error could not parse JSON. \r\n '\(jsonStr)'"
                succeed = false
            }
            
            //這個測試失敗！！！！！
            //處理回傳的Header -> 包含資料總筆數
            if let response = response as? NSHTTPURLResponse {
                if response.statusCode == 200 {
                    let resultCode = response.allHeaderFields["statusCd"] as! String
                    if resultCode == "5000"  //"執行成功"
                    {
                        let resultCount = response.allHeaderFields["totalCount"] as! String
                        let intCount = Int(resultCount)

                        //print("resultCount = '\(intCount)'")
                        if intCount == 0
                        {
                            let alertController = alertObject.ShowAlert("Alert", ContentString:"查詢無訂單資料！", ActionString:"OK")
                            self.presentViewController(alertController, animated: true, completion: nil)
                        }
                        succeed = true
                    }
                    else
                    {
                        if resultCode == "5001" //timeout
                        {
                            errorMag = "超過３０分鐘未操作，已自動登出，請重新登入！"
                            succeed = false
                        }
                        else
                        {
                            let codeMsg = ReadErrorMsg(resultCode)
                            errorMag = "Server回傳資料有誤！[\(resultCode)]\r\n\(codeMsg)"
                            succeed = false
                            //let alertController = alertObject.ShowAlert("Alert", ContentString:"Server回傳資料有誤！[\(resultCode)]\r\n\(errorMsg)", ActionString:"OK")
                            //self.presentViewController(alertController, animated: true, completion: nil)
                        }
                    }
                }
            }
        } catch {
            //print("Send request error.\r\n '\(error)'")
            errorMag = "Send request error.\r\n '\(error)'"
            succeed = false
        }
        return (succeed, errorMag)
    }
    
    func classifyOrders(tOrder:Order)
    {
        var keyvalue:String = ""
        switch dataSort {
        case "訂單客戶":
            keyvalue = tOrder.OrderCustomerId
        case "訂單日期":
            keyvalue = tOrder.OrderDate
        case "訂單狀態":
            if tOrder.OrderStatus == "0"
            {
                keyvalue = "0"
            }
            else
            {
                keyvalue = "1"
            }
        default:
            keyvalue = ""
        }

        /*let index = orderColSet.indexOf({$0.GroupedName == keyvalue})! as Int
        if index >= 0
        {
            // it exists, do something
            orderColSet[index].OrderArray.append(tOrder)
        }
        else
        {
            // item not found
            var torderArray = [Order]()
            torderArray.append(tOrder)
            
            let torderCollection:GroupedOrder = GroupedOrder(groupedName:keyvalue, orderArray:torderArray)
            orderColSet.append(torderCollection)
            //orderColSet[0] = torderCollection
        }*/
        
        if ordersClassify.contains(keyvalue)
        {
            let index = ordersClassify.indexOf({$0 == keyvalue})! as Int
            ordersArray[index].append(tOrder)
            //2016/08/19 新增訂單總金額顯示
            ordersTotalAmount[index] = ordersTotalAmount[index] + tOrder.OrderTwdAmount
        }
        else
        {
            // item not found
            var torderArray = [Order]()
            torderArray.append(tOrder)
            ordersArray.append(torderArray)
            //ordersArray[ordersClassify.count].append(tOrder)
            
            ordersClassify.append(keyvalue)
            ordersTotalAmount.append(tOrder.OrderTwdAmount)
        }
    }
    
    func ReadErrorMsg(errorCode:String) -> String
    {
        if errorObject.count == 0
        {
            return ""
        }
        else
        {
            return errorObject[errorCode] as! String
        }
    }
    
    //Search Bar 過濾資料
    func filterContentForSearchText(searchText: String)
    {
        searchOrders = orders.filter({ (order:Order) -> Bool in
            let nameMatch = order.OrderCustomer.rangeOfString(searchText, options: NSStringCompareOptions.CaseInsensitiveSearch)
            return nameMatch != nil
        })
    }
    
    func updateSearchResultsForSearchController(searchController: UISearchController){
        if let searchText = searchController.searchBar.text {
            filterContentForSearchText(searchText)
            tableView.reloadData()
        }
    }
    
    // SectionHeaderViewDelegate
    func sectionHeaderView(sectionHeaderView: SectionHeaderView, sectionOpened: Int)
    {
        var sectionInfo: SectionInfo = self.sectionInfoArray[sectionOpened] as! SectionInfo
        sectionInfo.open = true
        
        //创建一个包含单元格索引路径的数组来实现插入单元格的操作：这些路径对应当前节的每个单元格
        var countOfRowsToInsert = sectionInfo.grouporders.OrderArray.count
        var indexPathsToInsert = NSMutableArray()
        
        for (var i = 0; i < countOfRowsToInsert; i++) {
            indexPathsToInsert.addObject(NSIndexPath(forRow: i, inSection: sectionOpened))
        }
        
        // 创建一个包含单元格索引路径的数组来实现删除单元格的操作：这些路径对应之前打开的节的单元格
        
        var indexPathsToDelete = NSMutableArray()
        
        var previousOpenSectionIndex = self.opensectionindex
        if previousOpenSectionIndex != NSNotFound {
            
            var previousOpenSection: SectionInfo = self.sectionInfoArray[previousOpenSectionIndex] as! SectionInfo
            previousOpenSection.open = false
            previousOpenSection.headerView.toggleOpenWithUserAction(false)
            var countOfRowsToDelete = previousOpenSection.grouporders.OrderArray.count
            for (var i = 0; i < countOfRowsToDelete; i++) {
                indexPathsToDelete.addObject(NSIndexPath(forRow: i, inSection: previousOpenSectionIndex))
            }
        }
        
        // 设计动画，以便让表格的打开和关闭拥有一个流畅（很屌）的效果
        var insertAnimation: UITableViewRowAnimation
        var deleteAnimation: UITableViewRowAnimation
        if previousOpenSectionIndex == NSNotFound || sectionOpened < previousOpenSectionIndex {
            insertAnimation = UITableViewRowAnimation.Top
            deleteAnimation = UITableViewRowAnimation.Bottom
        }else{
            insertAnimation = UITableViewRowAnimation.Bottom
            deleteAnimation = UITableViewRowAnimation.Top
        }
        
        // 应用单元格的更新
        self.tableView.beginUpdates()
        self.tableView.deleteRowsAtIndexPaths((indexPathsToDelete as? [NSIndexPath])!, withRowAnimation: deleteAnimation)
        self.tableView.insertRowsAtIndexPaths((indexPathsToInsert as? [NSIndexPath])!, withRowAnimation: insertAnimation)
        
        self.opensectionindex = sectionOpened
        
        self.tableView.endUpdates()
    }
    
    func sectionHeaderView(sectionHeaderView: SectionHeaderView, sectionClosed: Int)
    {
        // 在表格关闭的时候，创建一个包含单元格索引路径的数组，接下来从表格中删除这些行
        var sectionInfo: SectionInfo = self.sectionInfoArray[sectionClosed] as! SectionInfo
        
        sectionInfo.open = false
        var countOfRowsToDelete = self.tableView.numberOfRowsInSection(sectionClosed)
        
        if countOfRowsToDelete > 0 {
            var indexPathsToDelete = NSMutableArray()
            for (var i = 0; i < countOfRowsToDelete; i++) {
                indexPathsToDelete.addObject(NSIndexPath(forRow: i, inSection: sectionClosed))
            }
            self.tableView.deleteRowsAtIndexPaths((indexPathsToDelete as? [NSIndexPath])!, withRowAnimation: UITableViewRowAnimation.Top)
        }
        self.opensectionindex = NSNotFound
    }
    
    // ____________________________________________________________________
    // 缩放操作处理
    
    func handlePinch(pinchRecognizer: UIPinchGestureRecognizer) {
        
        // 有手势识别有很多状态来对应不同的动作：
        // * 对于 Began 状态来说，是用缩放点的位置来找寻单元格的索引路径，并将索引路径与缩放操作进行绑定，同时在 pinchedIndexPath 中保留一个引用。接下来方法获取单元格的高度，然后存储其在缩放开始前的高度。最后，为缩放的单元格更新比例。
        // * 对于 Changed 状态来说，是为缩放的单元格更新比例（由 pinchedIndexPath 支持）
        // * 对于 Ended 或者 Canceled状态来说，是将 pinchedIndexPath 属性设置为 nil
        
        NSLog("pinch Gesture")
        if pinchRecognizer.state == UIGestureRecognizerState.Began {
            
            let pinchLocation = pinchRecognizer.locationInView(self.tableView)
            let newPinchedIndexPath = self.tableView.indexPathForRowAtPoint(pinchLocation)
            self.pinchedIndexPath = newPinchedIndexPath
            
            let sectionInfo: SectionInfo = self.sectionInfoArray[newPinchedIndexPath!.section] as! SectionInfo
            self.initialPinchHeight = sectionInfo.objectInRowHeightsAtIndex(newPinchedIndexPath!.row) as! CGFloat
            NSLog("pinch Gesture began")
            // 也可以设置为 initialPinchHeight = uniformRowHeight
            
            self.updateForPinchScale(pinchRecognizer.scale, indexPath: newPinchedIndexPath!)
        }else {
            if pinchRecognizer.state == UIGestureRecognizerState.Changed {
                self.updateForPinchScale(pinchRecognizer.scale, indexPath: self.pinchedIndexPath)
            }else if pinchRecognizer.state == UIGestureRecognizerState.Cancelled || pinchRecognizer.state == UIGestureRecognizerState.Ended {
                self.pinchedIndexPath = nil
            }
        }
    }
    
    func updateForPinchScale(scale: CGFloat, indexPath:NSIndexPath?) {
        
        let section:NSInteger = indexPath!.section
        let row:NSInteger = indexPath!.row
        let found:NSInteger = NSNotFound
        if  (section != found) && (row != found) && indexPath != nil {
            
            var newHeight:CGFloat!
            if self.initialPinchHeight > CGFloat(DefaultRowHeight) {
                newHeight = round(self.initialPinchHeight)
            }else {
                newHeight = round(CGFloat(DefaultRowHeight))
            }
            
            let sectionInfo: SectionInfo = self.sectionInfoArray[indexPath!.section] as! SectionInfo
            sectionInfo.replaceObjectInRowHeightsAtIndex(indexPath!.row, withObject: (newHeight))
            // 也可以设置为 uniformRowHeight = newHeight
            
            // 在单元格高度改变时关闭动画， 不然的话就会有迟滞的现象
            
            let animationsEnabled: Bool = UIView.areAnimationsEnabled()
            UIView.setAnimationsEnabled(false)
            self.tableView.beginUpdates()
            self.tableView.endUpdates()
            UIView.setAnimationsEnabled(animationsEnabled)
        }
    }
    
    // ________________________________________________________________________
    // 处理长按手势
    
    /*func handleLongPress(longPressRecognizer: UILongPressGestureRecognizer) {
        
        // 对于长按手势来说，唯一的状态是Began
        // 当长按手势被识别后，将会找寻按压点的单元格的索引路径
        // 如果按压位置存在一个单元格，那么就会创建一个菜单并展示它
        
        if longPressRecognizer.state == UIGestureRecognizerState.Began {
            
            let pressedIndexPath = self.tableView.indexPathForRowAtPoint(longPressRecognizer.locationInView(self.tableView))
            
            if pressedIndexPath != nil && pressedIndexPath?.row != NSNotFound && pressedIndexPath?.section != NSNotFound {
                
                self.becomeFirstResponder()
                let title = NSBundle.mainBundle().localizedStringForKey("邮件", value: "", table: nil)
                let menuItem: EmailMenuItem = EmailMenuItem(title: title, action: "emailMenuButtonPressed:")
                menuItem.indexPath = pressedIndexPath
                
                let menuController = UIMenuController.sharedMenuController()
                menuController.menuItems = [menuItem]
                
                var cellRect = self.tableView.rectForRowAtIndexPath(pressedIndexPath!)
                // 略微减少对象的长宽高（不要让其在单元格上方显示得太高）
                cellRect.origin.y = cellRect.origin.y + 40.0
                menuController.setTargetRect(cellRect, inView: self.tableView)
                menuController.setMenuVisible(true, animated: true)
            }
        }
    }*/
    
    /*func emailMenuButtonPressed(menuController: UIMenuController) {
        
        let menuItem: EmailMenuItem = UIMenuController.sharedMenuController().menuItems![0] as! EmailMenuItem
        if menuItem.indexPath != nil {
            self.resignFirstResponder()
            //self.sendEmailForEntryAtIndexPath(menuItem.indexPath)
        }
    }*/
    
    /*func sendEmailForEntryAtIndexPath(indexPath: NSIndexPath) {
        
        let play: Play = self.plays[indexPath.section] as! Play
        let quotation: Quotation = play.quotations[indexPath.row] as! Quotation
        
        // 在实际使用中，可以调用邮件的API来实现真正的发送邮件
        print("用以下语录发送邮件: \(quotation.quotation)")
    }*/
    
    func mailComposeController(controller: MFMailComposeViewController, didFinishWithResult result: MFMailComposeResult, error: NSError?) {
        
        self.dismissViewControllerAnimated(true, completion: nil)
        if result.rawValue == MFMailComposeResultFailed.rawValue {
            // 在实际使用中，显示一个合适的警告框来提示用户
            print("邮件发送失败,错误信息: \(error)")
        }
    }

    func classifyMutableArrayOrders(tOrder:Order)
    {
        var keyvalue:String = ""
        var groupna:String = ""
        switch dataSort {
        case "訂單客戶":
            keyvalue = tOrder.OrderCustomerId
            groupna = tOrder.OrderCustomer
        case "訂單日期":
            keyvalue = tOrder.OrderDate
            groupna = tOrder.OrderDate
        case "訂單狀態":
            if tOrder.OrderStatus == "0"
            {
                keyvalue = "0"
                groupna = "已結"
            }
            else
            {
                keyvalue = "1"
                groupna = "未結"
            }
        default:
            keyvalue = ""
        }
        
        if ordersClassify.contains(keyvalue)
        {
            let index = ordersClassify.indexOf({$0 == keyvalue})! as Int
            ordersArray[index].append(tOrder)
            
            //((playe![index] as! GroupedOrder).OrderArray as! NSMutableArray).addObject(tOrder)
            //let go : GroupedOrder = playe![index] as! GroupedOrder
            //go.OrderArray.addObject(tOrder)
            
            (ordersCollection![index] as! GroupedOrder).OrderArray.addObject(tOrder)
            (ordersCollection![index] as! GroupedOrder).OrderAmount = (ordersCollection![index] as! GroupedOrder).OrderAmount + tOrder.OrderTwdAmount
            
            //2016/08/19 新增訂單總金額顯示
            ordersTotalAmount[index] = ordersTotalAmount[index] + tOrder.OrderTwdAmount
        }
        else
        {
            let grouporders: GroupedOrder! = GroupedOrder()
            grouporders.GroupedName = groupna      //分群名稱
            grouporders.OrderAmount = tOrder.OrderTwdAmount
            
            let orders = NSMutableArray()
            orders.addObject(tOrder)
            
            grouporders.OrderArray = orders
            ordersCollection!.addObject(grouporders)
            
            // item not found
            var torderArray = [Order]()
            torderArray.append(tOrder)
            ordersArray.append(torderArray)
            
            ordersClassify.append(keyvalue)
            
            //2016/08/19 新增訂單總金額顯示
            ordersTotalAmount.append(tOrder.OrderTwdAmount)
        }
    }

    func createSectionInfo()
    {
        //对于每个场次来说，需要为每个单元格设立一个一致的、包含默认高度的SectionInfo对象。
        let infoArray = NSMutableArray()
        
        for play in self.ordersCollection {
            var dic = (play as! GroupedOrder).OrderArray
            let sectionInfo = SectionInfo()
            sectionInfo.grouporders = play as! GroupedOrder
            sectionInfo.open = false
            
            let defaultRowHeight = DefaultRowHeight
            let countOfQuotations = sectionInfo.grouporders.OrderArray.count
            for (var i = 0; i < countOfQuotations; i++) {
                sectionInfo.insertObject(defaultRowHeight, inRowHeightsAtIndex: i)
            }
            
            infoArray.addObject(sectionInfo)
        }
        
        self.sectionInfoArray  = infoArray

    }
}

//Activity Indicator
//http://stackoverflow.com/questions/28785715/how-to-display-an-activity-indicator-with-text-on-ios-8-with-swift
