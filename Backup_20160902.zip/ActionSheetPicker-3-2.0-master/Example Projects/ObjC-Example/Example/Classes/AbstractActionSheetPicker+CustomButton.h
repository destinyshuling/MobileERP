//
// Created by Vladislava Kirichenko on 10/29/14.
//

#import <Foundation/Foundation.h>
#import <CoreActionSheetPicker/CoreActionSheetPicker.h>

@interface AbstractActionSheetPicker (CustomButton)

- (void)pressFirstCustomButton;

- (void)pressDoneButton;
@end