ActionSheetPicker Contributors
================

Original author
-------------------------
[Tim Cinel](http://github.com/TimCinel)     email@timcinel.com      @TimCinel

------------
## Contributors ##

[Petr Korolev](http://github.com/skywinder) (maintainer and community support, bugfixing, update to iOS 7 and iOS 8, implementing new pickers)

[Filote Stefan](http://github.com/sfilo)

[Brett Gibson](http://github.com/brettg)

[John Garland](http://github.com/johnnyg) (iPad!)

[Mark van den Broek](http://github.com/heyhoo)

[Evan Cordell](http://github.com/ecordell)

[Greg Combs](http://github.com/grgcombs) (Refactor!)

[Hari Karam Singh](http://github.com/Club15CC) (ARC, CustomPicker)

ActionSheetPicker exists because of these contributors, remember to thank them :)

## Credits ##

And most of all, thanks to ActionSheetPicker-3.0's [growing list of contributors](https://github.com/skywinder/ActionSheetPicker-3.0/graphs/contributors).
