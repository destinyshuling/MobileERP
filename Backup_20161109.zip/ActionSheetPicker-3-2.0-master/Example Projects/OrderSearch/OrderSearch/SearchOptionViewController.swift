//
//  SearchOptionViewController.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/5/24.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit
//import CoreActionSheetPicker

class SearchOptionViewController: UIViewController{
    @IBOutlet var searchButton: UIButton?
    @IBOutlet var pickerDepart: UIPickerView?
    @IBOutlet var pickerTextField: UITextField?
    
    var pickerData = ["White", "Red", "Green", "Blue"];

    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String! {
        return pickerData[row]
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //self.pickerDepart.delegate = self
        //self.pickerDepart.dataSource = self
        pickerTextField?.inputView = pickerDepart
    }
}
