//
//  OrderTableViewCell.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/6/2.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit

class OrderTableViewCell: UITableViewCell {
    @IBOutlet var orderDate:UILabel!
    @IBOutlet var orderId:UILabel!
    @IBOutlet var orderCustomerId:UILabel!
    @IBOutlet var orderCustomer:UILabel!
    @IBOutlet var orderCurrency:UILabel!
    @IBOutlet var orderAmount:UILabel!
    @IBOutlet var orderStatus:UIImageView!
    //2016/10/01 訂單總金額（台幣）
    @IBOutlet var orderTwdAmount:UILabel!
    //2016/10/01 立帳總金額（台幣）
    @IBOutlet var orderTwdArAmount:UILabel!
    //2016/10/01 該AR是否逾期 -> 以顏色顯示
    //@IBOutlet var orderOverDue
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
}
