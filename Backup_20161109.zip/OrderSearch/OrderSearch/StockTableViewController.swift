//
//  StockTableViewController.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/8/17.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit
import CoreData

class StockTableViewController: UITableViewController, SectionHeaderViewDelegate {

    //前一頁傳遞過來的資料
    var loginAccount:String!
    var loginName:String!
    var loginDepartment:String!
    var loginAuthorizationArr:[String] = []
    var serviceToken:String!
    var errorObject:Dictionary<String, AnyObject> = [:]
    var internetReachability:Reachability!; //網路狀態監控
    
    //儲存庫存查詢結果
    var stockResultArr:[ListInStockAll] = []
    
    //庫存分群
    var stockClassify = [[String]]()
    //var stocksArray = [[ListInStockAll]]()
    
    //庫存分群:ZYTW, ZYLH, ZYHEN
    var stocksTWCollection:NSMutableArray! = NSMutableArray()
    var stocksLHCollection:NSMutableArray! = NSMutableArray()
    var stocksHENCollection:NSMutableArray! = NSMutableArray()
    
    //表格縮合
    let SectionHeaderViewIdentifier = "SectionHeaderViewIdentifier"
    var plays:NSArray!
    var sectionInfoArray:NSMutableArray!
    var pinchedIndexPath:IndexPath!
    var opensectionindex:Int!
    var initialPinchHeight:CGFloat!
    //儲存每一個section內的庫存資料
    var stocksCollection:NSMutableArray! = NSMutableArray()
    var sectionHeaderView:SectionHeaderView!
    
    //当缩放手势同时改变了所有单元格高度时使用uniformRowHeight
    var uniformRowHeight: Int!
    let DefaultRowHeight = 70
    let HeaderHeight = 45
    
    override func viewDidLoad() {
        super.viewDidLoad()

        title = "庫存總覽"
        
        // 为表视图添加缩放手势识别
        let pinchRecognizer = UIPinchGestureRecognizer(target: self, action:#selector(OrderTableViewController.handlePinch(_:)))
        self.tableView.addGestureRecognizer(pinchRecognizer)
        
        // 分节信息数组在viewWillUnload方法中将被销毁，因此在这里设置Header的默认高度是可行的。如果您想要保留分节信息等内容，可以在指定初始化器当中设置初始值。
        self.uniformRowHeight = DefaultRowHeight
        self.opensectionindex = NSNotFound
        
        let sectionHeaderNib: UINib = UINib(nibName: "SectionHeaderView", bundle: nil)
        self.tableView.register(sectionHeaderNib, forHeaderFooterViewReuseIdentifier: SectionHeaderViewIdentifier)
        
        //將庫存資料分群
        classifyStocks()
        
        //建立section
        createSectionInfo()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        //self.tableView.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 3
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        /*switch section {
        case 0:
            return stocksTWCollection.count
        case 1:
            return stocksLHCollection.count
        case 2:
            return stocksHENCollection.count
        default:
            return 0
        }*/
        
        let sectioninfo: SectionInfo = self.sectionInfoArray[section] as! SectionInfo
        //let numInSection = sectioninfo.grouporders.OrderArray.count
        let numInSection:Int = sectioninfo.rowCount
        let sectionOpen = sectioninfo.open
        return (sectionOpen != nil && sectionOpen == true) ? numInSection : 0
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "StockCell", for: indexPath) as! StockTableViewCell
        
        // Configure the cell...
        /*cell.src.text = stockResultArr[indexPath.row].src
        switch stockResultArr[indexPath.row].src {
        case "ZYTW":
            cell.src.text = "正一台灣"
        case "ZYLH":
            cell.src.text = "正一龍華"
        case "ZYHEN":
            cell.src.text = "正一河南"
        default:
            cell.src.text = "正一"
        }*/
        //料號
        //cell.img01.text = stockResultArr[indexPath.row].img01
        //品名
        //cell.ima02.text = stockResultArr[indexPath.row].ima02
        //庫存單位
        //cell.img09.text = stockResultArr[indexPath.row].img09
        //數量
        //cell.img10.text = stockResultArr[indexPath.row].img10
        //分群碼
        //let na1 = SearchCoreData("imz01 = '\(stockResultArr[indexPath.row].ima06)'", tableName: "ListImz")
        //cell.ima06.text = "[\(stockResultArr[indexPath.row].ima06)] \(na1)"
        //倉庫
        //let na2 = SearchCoreData("imd01 = '\(stockResultArr[indexPath.row].img02)'", tableName: "ListImd")
        //cell.img02.text = "[\(stockResultArr[indexPath.row].img02)] \(na2)"
        
        switch (indexPath as NSIndexPath).section {
        case 0:
            let image : UIImage = UIImage(named: "Location-zytw")!
            cell.srcImage.image = image
            //料號
            cell.img01.text = (stocksTWCollection[(indexPath as NSIndexPath).row] as! GroupedStock).stockImg01
            //品名
            cell.ima02.text = ((stocksTWCollection[(indexPath as NSIndexPath).row] as! GroupedStock).stockList[0] as! ListInStockAll).ima02
            //單位
            cell.img09.text = ((stocksTWCollection[(indexPath as NSIndexPath).row] as! GroupedStock).stockList[0] as! ListInStockAll).img09
            //庫存總數
            cell.img10.text = "\((stocksTWCollection[(indexPath as NSIndexPath).row] as! GroupedStock).stockTotalCount)"
        case 1:
            let image : UIImage = UIImage(named: "Location-zylh")!
            cell.srcImage.image = image
            //料號
            cell.img01.text = (stocksLHCollection[(indexPath as NSIndexPath).row] as! GroupedStock).stockImg01
            //品名
            cell.ima02.text = ((stocksLHCollection[(indexPath as NSIndexPath).row] as! GroupedStock).stockList[0] as! ListInStockAll).ima02
            //單位
            cell.img09.text = ((stocksLHCollection[(indexPath as NSIndexPath).row] as! GroupedStock).stockList[0] as! ListInStockAll).img09
            //庫存總數
            cell.img10.text = "\((stocksLHCollection[(indexPath as NSIndexPath).row] as! GroupedStock).stockTotalCount)"
        case 2:
            let image : UIImage = UIImage(named: "Location-zyhen")!
            cell.srcImage.image = image
            //料號
            cell.img01.text = (stocksHENCollection[(indexPath as NSIndexPath).row] as! GroupedStock).stockImg01
            //品名
            cell.ima02.text = ((stocksHENCollection[(indexPath as NSIndexPath).row] as! GroupedStock).stockList[0] as! ListInStockAll).ima02
            //單位
            cell.img09.text = ((stocksHENCollection[(indexPath as NSIndexPath).row] as! GroupedStock).stockList[0] as! ListInStockAll).img09
            //庫存總數
            cell.img10.text = "\((stocksHENCollection[(indexPath as NSIndexPath).row] as! GroupedStock).stockTotalCount)"
        default:
            //料號
            cell.img01.text = (stocksTWCollection[(indexPath as NSIndexPath).row] as! GroupedStock).stockImg01
            //品名
            cell.ima02.text = ((stocksTWCollection[(indexPath as NSIndexPath).row] as! GroupedStock).stockList[0] as! ListInStockAll).ima02
            //單位
            cell.img09.text = ((stocksTWCollection[(indexPath as NSIndexPath).row] as! GroupedStock).stockList[0] as! ListInStockAll).img09
            //庫存總數
            cell.img10.text = "\((stocksTWCollection[(indexPath as NSIndexPath).row] as! GroupedStock).stockTotalCount)"
        }
        
        return cell
    }

    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        //Choose your custom row height
        return 70.0
    }
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        var headerTitle:String = ""
        switch section {
        case 0:
            headerTitle = "正一台灣"
        case 1:
            headerTitle = "正一龍華"
        case 2:
            headerTitle = "正一河南"
        default:
            headerTitle = ""
        }
        
        // 返回指定的 section header 的view，如果没有，这个函数可以不返回view
        let sectionHeaderView: SectionHeaderView = self.tableView.dequeueReusableHeaderFooterView(withIdentifier: SectionHeaderViewIdentifier) as! SectionHeaderView
        
        let sectionInfo: SectionInfo = self.sectionInfoArray[section] as! SectionInfo
        sectionInfo.headerView = sectionHeaderView
        
        //sectionHeaderView.contentView.backgroundColor = UIColor.lightGrayColor()
        sectionHeaderView.titleLabel.text = "\(headerTitle) (\(Int(sectionInfo.rowCount)))"
        sectionHeaderView.amount.text = ""
        sectionHeaderView.section = section
        sectionHeaderView.delegate = self
        
        return sectionHeaderView
    }

    /*override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String?
    {
        var headerTitle:String = ""
        switch section {
        case 0:
            headerTitle = "正一台灣"
        case 1:
            headerTitle = "正一龍華"
        case 2:
            headerTitle = "正一河南"
        default:
            headerTitle = ""
        }
        return headerTitle
    }*/
    
    /*override func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int)
    {
        var headerTitle:String = ""
        
        switch section {
        case 0:
            headerTitle = "正一台灣"
        case 1:
            headerTitle = "正一龍華"
        case 2:
            headerTitle = "正一河南"
        default:
            headerTitle = ""
        }
        
        let title = UILabel()
        title.font = UIFont(name: headerTitle, size: 30)
        title.textColor = UIColor.lightGray
        
        let header = view as! UITableViewHeaderFooterView
        header.textLabel?.font=title.font
        header.textLabel?.textColor=title.textColor
    }*/
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 45.0
    }
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if segue.identifier == "StockDetailSegue"
        {
            if let indexPath = tableView.indexPathForSelectedRow{
                let destinationController = segue.destination as! StockDetailViewController
                
                switch (indexPath as NSIndexPath).section {
                case 0:
                    destinationController.groupStock = (stocksTWCollection[(indexPath as NSIndexPath).row] as! GroupedStock)
                case 1:
                    destinationController.groupStock = (stocksLHCollection[(indexPath as NSIndexPath).row] as! GroupedStock)
                case 2:
                    destinationController.groupStock = (stocksHENCollection[(indexPath as NSIndexPath).row] as! GroupedStock)
                default:
                    destinationController.groupStock = (stocksTWCollection[(indexPath as NSIndexPath).row] as! GroupedStock)
                }
                destinationController.serviceToken = serviceToken
                destinationController.errorObject = errorObject
                destinationController.internetReachability = internetReachability
            }
        }
    }
    
    // SectionHeaderViewDelegate
    func sectionHeaderView(_ sectionHeaderView: SectionHeaderView, sectionOpened: Int)
    {
        let sectionInfo: SectionInfo = self.sectionInfoArray[sectionOpened] as! SectionInfo
        sectionInfo.open = true
        
        //创建一个包含单元格索引路径的数组来实现插入单元格的操作：这些路径对应当前节的每个单元格
        let countOfRowsToInsert:Int = sectionInfo.rowCount
        let indexPathsToInsert = NSMutableArray()
        for i in (0 ..< countOfRowsToInsert) {
            indexPathsToInsert.add(IndexPath(row: i, section: sectionOpened))
        }
        
        // 创建一个包含单元格索引路径的数组来实现删除单元格的操作：这些路径对应之前打开的节的单元格
        let indexPathsToDelete = NSMutableArray()
        let previousOpenSectionIndex = self.opensectionindex
        if previousOpenSectionIndex != NSNotFound {
            
            let previousOpenSection: SectionInfo = self.sectionInfoArray[previousOpenSectionIndex!] as! SectionInfo
            previousOpenSection.open = false
            previousOpenSection.headerView.toggleOpenWithUserAction(false)
            let countOfRowsToDelete:Int = previousOpenSection.rowCount
            for i in (0 ..< countOfRowsToDelete) {
                indexPathsToDelete.add(IndexPath(row: i, section: previousOpenSectionIndex!))
            }
        }
        
        // 设计动画，以便让表格的打开和关闭拥有一个流畅（很屌）的效果
        var insertAnimation: UITableViewRowAnimation
        var deleteAnimation: UITableViewRowAnimation
        if previousOpenSectionIndex! == NSNotFound || sectionOpened < previousOpenSectionIndex! {
            insertAnimation = UITableViewRowAnimation.top
            deleteAnimation = UITableViewRowAnimation.bottom
        }else{
            insertAnimation = UITableViewRowAnimation.bottom
            deleteAnimation = UITableViewRowAnimation.top
        }
        
        // 应用单元格的更新
        self.tableView.beginUpdates()
        self.tableView.deleteRows(at: (indexPathsToDelete as? [IndexPath])!, with: deleteAnimation)
        self.tableView.insertRows(at: (indexPathsToInsert as? [IndexPath])!, with: insertAnimation)
        
        self.opensectionindex = sectionOpened
        
        self.tableView.endUpdates()
    }
    
    func sectionHeaderView(_ sectionHeaderView: SectionHeaderView, sectionClosed: Int)
    {
        // 在表格关闭的时候，创建一个包含单元格索引路径的数组，接下来从表格中删除这些行
        let sectionInfo: SectionInfo = self.sectionInfoArray[sectionClosed] as! SectionInfo
        
        sectionInfo.open = false
        let countOfRowsToDelete = self.tableView.numberOfRows(inSection: sectionClosed)
        
        if countOfRowsToDelete > 0 {
            let indexPathsToDelete = NSMutableArray()
            for i in (0 ..< countOfRowsToDelete) {
                indexPathsToDelete.add(IndexPath(row: i, section: sectionClosed))
            }
            self.tableView.deleteRows(at: (indexPathsToDelete as? [IndexPath])!, with: UITableViewRowAnimation.top)
        }
        self.opensectionindex = NSNotFound
    }
    
    // ____________________________________________________________________
    // 缩放操作处理
    
    func handlePinch(_ pinchRecognizer: UIPinchGestureRecognizer) {
        
        // 有手势识别有很多状态来对应不同的动作：
        // * 对于 Began 状态来说，是用缩放点的位置来找寻单元格的索引路径，并将索引路径与缩放操作进行绑定，同时在 pinchedIndexPath 中保留一个引用。接下来方法获取单元格的高度，然后存储其在缩放开始前的高度。最后，为缩放的单元格更新比例。
        // * 对于 Changed 状态来说，是为缩放的单元格更新比例（由 pinchedIndexPath 支持）
        // * 对于 Ended 或者 Canceled状态来说，是将 pinchedIndexPath 属性设置为 nil
        
        NSLog("pinch Gesture")
        if pinchRecognizer.state == UIGestureRecognizerState.began {
            
            let pinchLocation = pinchRecognizer.location(in: self.tableView)
            let newPinchedIndexPath = self.tableView.indexPathForRow(at: pinchLocation)
            self.pinchedIndexPath = newPinchedIndexPath
            
            let sectionInfo: SectionInfo = self.sectionInfoArray[(newPinchedIndexPath! as NSIndexPath).section] as! SectionInfo
            self.initialPinchHeight = sectionInfo.objectInRowHeightsAtIndex((newPinchedIndexPath! as NSIndexPath).row) as! CGFloat
            NSLog("pinch Gesture began")
            // 也可以设置为 initialPinchHeight = uniformRowHeight
            
            self.updateForPinchScale(pinchRecognizer.scale, indexPath: newPinchedIndexPath!)
        }else {
            if pinchRecognizer.state == UIGestureRecognizerState.changed {
                self.updateForPinchScale(pinchRecognizer.scale, indexPath: self.pinchedIndexPath)
            }else if pinchRecognizer.state == UIGestureRecognizerState.cancelled || pinchRecognizer.state == UIGestureRecognizerState.ended {
                self.pinchedIndexPath = nil
            }
        }
    }
    
    func updateForPinchScale(_ scale: CGFloat, indexPath:IndexPath?) {
        
        let section:NSInteger = (indexPath! as NSIndexPath).section
        let row:NSInteger = (indexPath! as NSIndexPath).row
        let found:NSInteger = NSNotFound
        if  (section != found) && (row != found) && indexPath != nil {
            
            var newHeight:CGFloat!
            if self.initialPinchHeight > CGFloat(DefaultRowHeight) {
                newHeight = round(self.initialPinchHeight)
            }else {
                newHeight = round(CGFloat(DefaultRowHeight))
            }
            
            let sectionInfo: SectionInfo = self.sectionInfoArray[(indexPath! as NSIndexPath).section] as! SectionInfo
            sectionInfo.replaceObjectInRowHeightsAtIndex((indexPath! as NSIndexPath).row, withObject: (newHeight as AnyObject))
            // 也可以设置为 uniformRowHeight = newHeight
            
            // 在单元格高度改变时关闭动画， 不然的话就会有迟滞的现象
            
            let animationsEnabled: Bool = UIView.areAnimationsEnabled
            UIView.setAnimationsEnabled(false)
            self.tableView.beginUpdates()
            self.tableView.endUpdates()
            UIView.setAnimationsEnabled(animationsEnabled)
        }
    }

    //查詢CoreData 倉庫名稱/分群碼說明
    func SearchCoreData(_ query:String, tableName:String) -> String
    {
        var value:String = ""
        //使用CoreData取得資料
        if let managedObjectContext = (UIApplication.shared.delegate as? AppDelegate)?.managedObjectContext
        {
            let fetchRequest:NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: tableName)
            let predicate = NSPredicate(format: query)
            fetchRequest.predicate = predicate
            do{
                if tableName == "ListImd"
                {
                    //查詢倉庫
                    let classArray = try managedObjectContext.fetch(fetchRequest) as! [ListImd]
                    if classArray.count > 0
                    {
                        value = classArray[0].imd02
                    }
                }
                else if tableName == "ListImz"
                {
                    //查詢分群碼
                    let classArray = try managedObjectContext.fetch(fetchRequest) as! [ListImz]
                    if classArray.count > 0
                    {
                        value = classArray[0].imz02
                    }
                }
                
            } catch{
                print(error)
            }
        }
        return value
    }
    
    //將庫存資料分群 stockResultArr -> stocksCollection
    func classifyStocks()
    {
        //init classify array
        var arr = [String]()
        stockClassify.append(arr)
        stockClassify.append(arr)
        stockClassify.append(arr)
        
        for i in 0 ..< stockResultArr.count  //for stock in stockResultArr
        {
            if i == 18
            {
                arr.append("a")
            }
            let stock:ListInStockAll = stockResultArr[i]
            let keyvalue:String = stock.src + stock.img01  //法人＋料號：同法人並同料號者，須加總庫存數量
            
            //判別法人
            var classifyIndex:Int = 0
            switch stock.src {
            case "ZYTW":
                classifyIndex = 0
            case "ZYLH":
                classifyIndex = 1
            case "ZYHEN":
                classifyIndex = 2
            default:
                classifyIndex = 0
            }
            
            if stockClassify[classifyIndex].contains(keyvalue)
            {
                let index = stockClassify[classifyIndex].index(where: {$0 == keyvalue})! as Int
                
                //(stocksCollection![index] as! GroupedStock).stockList.addObject(stock)
                //(stocksCollection![index] as! GroupedStock).stockTotalCount = (stocksCollection![index] as! GroupedStock).stockTotalCount + Int(stock.img10)!
                updateStockCollection(stock.src, index:index, stock:stock)
            }
            else
            {
                // item not found
                let groupstocks: GroupedStock! = GroupedStock()
                groupstocks.stockSrc = stock.src
                groupstocks.stockImg01 = stock.img01
                groupstocks.stockTotalCount = Double(stock.img10)!
                
                let stocks = NSMutableArray()
                stocks.add(stock)
                
                groupstocks.stockList = stocks
                //stocksCollection.addObject(groupstocks)
                addStockCollection(stock.src, groupstocks:groupstocks)
                
                stockClassify[classifyIndex].append(keyvalue)
            }
        }
    }
    
    func addStockCollection(_ stockSrc:String, groupstocks:GroupedStock)
    {
        switch stockSrc {
        case "ZYTW":
            stocksTWCollection.add(groupstocks)
        case "ZYLH":
            stocksLHCollection.add(groupstocks)
        case "ZYHEN":
            stocksHENCollection.add(groupstocks)
        default:
            stocksTWCollection.add(groupstocks)
        }
    }
    
    func updateStockCollection(_ stockSrc:String, index:Int, stock:ListInStockAll)
    {
        switch stockSrc {
        case "ZYTW":
            (stocksTWCollection![index] as! GroupedStock).stockList.add(stock)
            //法人和料號一致時，加總庫存數量
            (stocksTWCollection![index] as! GroupedStock).stockTotalCount = (stocksTWCollection![index] as! GroupedStock).stockTotalCount + Double(stock.img10)!
        case "ZYLH":
            (stocksLHCollection![index] as! GroupedStock).stockList.add(stock)
            //法人和料號一致時，加總庫存數量
            (stocksLHCollection![index] as! GroupedStock).stockTotalCount = (stocksLHCollection![index] as! GroupedStock).stockTotalCount + Double(stock.img10)!
        case "ZYHEN":
            (stocksHENCollection![index] as! GroupedStock).stockList.add(stock)
            //法人和料號一致時，加總庫存數量
            (stocksHENCollection![index] as! GroupedStock).stockTotalCount = (stocksHENCollection![index] as! GroupedStock).stockTotalCount + Double(stock.img10)!
        default:
            (stocksTWCollection![index] as! GroupedStock).stockList.add(stock)
            //法人和料號一致時，加總庫存數量
            (stocksTWCollection![index] as! GroupedStock).stockTotalCount = (stocksTWCollection![index] as! GroupedStock).stockTotalCount + Double(stock.img10)!
        }
    }
    
    func createSectionInfo()
    {
        //对于每个场次来说，需要为每个单元格设立一个一致的、包含默认高度的SectionInfo对象。
        let infoArray = NSMutableArray()
        
//        for play in self.stocksCollection {
//            var dic = (play as! GroupedOrder).OrderArray
//            let sectionInfo = SectionInfo()
//            sectionInfo.grouporders = play as! GroupedOrder
//            sectionInfo.open = false
//            
//            let defaultRowHeight = DefaultRowHeight
//            let countOfQuotations:Int = sectionInfo.rowCount
//            for i in (0 ..< countOfQuotations)
//            {
//                sectionInfo.insertObject(defaultRowHeight as AnyObject, inRowHeightsAtIndex: i)
//            }
//            
//            infoArray.add(sectionInfo)
//        }
        
        for i in (1..<4)
        {
            let sectionInfo = SectionInfo()
            sectionInfo.open = false
            
            switch i {
            case 1:
                sectionInfo.rowCount = stocksTWCollection.count
            case 2:
                sectionInfo.rowCount = stocksLHCollection.count
            case 3:
                sectionInfo.rowCount = stocksHENCollection.count
            default:
                sectionInfo.rowCount = stocksTWCollection.count
            }
            
            let defaultRowHeight = DefaultRowHeight
            let countOfQuotations:Int = sectionInfo.rowCount
            for i in (0 ..< countOfQuotations)
            {
                sectionInfo.insertObject(defaultRowHeight as AnyObject, inRowHeightsAtIndex: i)
            }
            infoArray.add(sectionInfo)
        }
        self.sectionInfoArray  = infoArray
    }

}
