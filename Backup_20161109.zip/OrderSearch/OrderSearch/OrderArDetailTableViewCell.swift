//
//  OrderArDetailTableViewCell.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/10/3.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit

class OrderArDetailTableViewCell: UITableViewCell {
    @IBOutlet var index:UILabel!
    @IBOutlet var partnumber:UILabel!
    @IBOutlet var desc:UILabel!
    @IBOutlet var salesunit:UILabel!
    @IBOutlet var qty:UILabel!
    @IBOutlet var unitprice:UILabel!
    @IBOutlet var twdAmount:UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
