//
//  ViewController.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/5/17.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet weak var AccountTextField: UITextField!
    @IBOutlet weak var PasswordTextField: UITextField!
    @IBOutlet var loginBtn: UIButton!
    @IBOutlet var VersionLabel: UILabel!
    @IBOutlet var LoginActivityIndicator: UIActivityIndicatorView!
    
    var keyHeight = CGFloat() //键盘的高度
    var loginToken: String = ""
    var loginName: String = ""
    var loginDepartment: String = ""
    var loginAuthorization: String = ""
    var loginAuthorizationArr: [String] = []
    
    //var alertObject = ShowAlert()
    var errorObject: Dictionary<String, AnyObject> = [:]
    
    weak var activityIndicatorView: UIActivityIndicatorView!
    var activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .whiteLarge)
    var internetReachability:Reachability!; //網路狀態監控
    
    var deviceType: String = ""
    //全局设置
    let UserNameKey = "name"
    let PwdKey = "pwd"
    let RmbPwdKey = "rmb_pwd"
    let IsFirstLaunch = "ifl"
    
    struct Platform {
        static let isSimulator: Bool = {
            var isSim = false
            #if arch(i386) || arch(x86_64)
                isSim = true
            #endif
            return isSim
        }()
    }
    
    override func viewDidLoad() {
        
        //顯示等候視窗
        view.addSubview(activityIndicator)
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        activityIndicator.color = UIColor.white
        activityIndicator.hidesWhenStopped = true
        
        //activityIndicator.startAnimating()
        activityIndicator.isHidden = true
        
        let horizontalConstraint = NSLayoutConstraint(item: activityIndicator, attribute: NSLayoutAttribute.centerX, relatedBy: NSLayoutRelation.equal, toItem: view, attribute: NSLayoutAttribute.centerX, multiplier: 1, constant: 0)
        view.addConstraint(horizontalConstraint)
        
        let verticalConstraint = NSLayoutConstraint(item: activityIndicator, attribute: NSLayoutAttribute.centerY, relatedBy: NSLayoutRelation.equal, toItem: view, attribute: NSLayoutAttribute.centerY, multiplier: 1, constant: 0)
        view.addConstraint(verticalConstraint)
        
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        loginBtn.backgroundColor = UIColor(red: 127.0/255.0, green: 127.0/255.0, blue: 127.0/255.0, alpha: 1.0)
        
        //設定鍵盤類型(顯示英文字母的虛擬鍵盤)
        //AccountTextField.keyboardType = .ASCIICapable
        //PasswordTextField.keyboardType = .ASCIICapable
        //AccountTextField.returnKeyType = .Done
        //PasswordTextField.returnKeyType = .Done
        AccountTextField.delegate = self
        PasswordTextField.delegate = self
        
        //self.AccountTextField.text = "shu-ling.lin"
        //self.PasswordTextField.text = "Renee2366"
        //读取上次配置
        self.AccountTextField.text =
            UserDefaults.standard.value(forKey: "UserNameKey") as? String
        self.PasswordTextField.text = UserDefaults.standard.value(forKey: "PwdKey") as? String
        
        //顯示版本
        self.VersionLabel.text = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String
        
        if(self.traitCollection.userInterfaceIdiom == UIUserInterfaceIdiom.pad)
        {
            deviceType = "iPad"
        }
        else if(self.traitCollection.userInterfaceIdiom == UIUserInterfaceIdiom.phone)
        {
            deviceType = "iPhone"
        }
        else
        {
            deviceType = ""
        }
        print("deviceType:\(deviceType)")
        //在通知中心註冊事件,當網路狀態有變動的時候會觸發
        NotificationCenter.default.addObserver(forName: NSNotification.Name.reachabilityChanged, object: nil, queue: OperationQueue.main) { (NSNotification) -> Void in
            let networksStatus: NetworkStatus = self.internetReachability.currentReachabilityStatus()
            var status: String!
            if networksStatus == NotReachable {
                status = "未偵測到網路連線！"
                UIAlertView(title: "Error", message: status, delegate: nil, cancelButtonTitle: "OK").show()
            } /*else if networksStatus == ReachableViaWiFi {
                status = "Connection using WiFi"
            } else if networksStatus == ReachableViaWWAN {
                status = "Connection using WWAN"
            } else {
                status = "Connection"
            }*/
        }
        
        self.internetReachability = Reachability.forInternetConnection();
        //開始監控狀況
        self.internetReachability.startNotifier()
        //*********************************************************************
        //AccountTextField.delegate = self
        //let centerDefault = NSNotificationCenter.defaultCenter()
        //centerDefault.addObserver(self, selector: #selector(ViewController.keyboardWillShow), name: UIKeyboardWillShowNotification, object: nil)
        
        //清除推播數字
        UIApplication.shared.applicationIconBadgeNumber = 0
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        navigationController?.hidesBarsOnSwipe = true
        navigationController?.setNavigationBarHidden(true, animated: true)
        
        //LoginActivityIndicator.stopAnimating()
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        activityIndicator.stopAnimating()
        LoginActivityIndicator.stopAnimating()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        //讀取server版本
        let versionLink = "http://103.227.33.247/F1SV/json/merp.json"
        let (versionSucceed, appVersion) = getJsonUseByVersion(versionLink)
        //讀失敗顯示訊息
        if versionSucceed == true
        {
            if self.VersionLabel.text != appVersion
            {
                //self.ShowAlert("Alert", ContentString:"APP已有更新版本(\(appVersion))，請重新下載！\r\n", ActionString:"OK")
                //http://www.onto.tech/ios/mobileerp.html
                
                let alertController = UIAlertController(title: "溫馨提醒", message:
                    "APP已有更新版本(\(appVersion))，請重新下載！", preferredStyle: UIAlertControllerStyle.alert)
                
                alertController.addAction(UIAlertAction(title: "立即更新", style: .default) { value in
                    //print("tapped default button")
                    UIApplication.shared.openURL(URL(string: "http://www.onto.tech/ios/mobileerp.html")!)
                    })
                alertController.addAction(UIAlertAction(title: "取消", style: .cancel, handler: nil))
                
                self.present(alertController, animated: true, completion: nil)
            }
        }
        
        //取得錯誤代碼
        let service = "http://103.227.33.247/F1SV/json/listErrorMsg.json"
        let (succeed, errorMsg) = getJsonUseByErrorMsg(service)
        //讀失敗顯示訊息
        if succeed == false
        {
            self.ShowAlert("Alert", ContentString:"錯誤代碼讀取失敗！\r\n\(errorMsg)", ActionString:"OK")
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if segue.identifier == "LoginSegue"
        {
            //舊式寫法目前不適用，但此方式可用於轉換頁面時出現
            //let alert = UIAlertView(title: "Message", message: "登入成功！", delegate: self, cancelButtonTitle: "OK")
            //alert.show()
            
            DispatchQueue.main.async(execute: { () -> Void in
                let navController = segue.destination as! UINavigationController
                let destinationController = navController.topViewController as! MenuViewController
                //將資料傳遞到下一個頁面
                destinationController.loginAccount = self.AccountTextField.text!
                destinationController.serviceToken = self.loginToken
                destinationController.loginName = self.loginName
                destinationController.loginDepartment = self.loginDepartment
                destinationController.errorObject = self.errorObject
                destinationController.loginAuthorizationArr = self.loginAuthorizationArr
                destinationController.internetReachability = self.internetReachability
            })
        }
    }
    
    @IBAction func LoginBtnTouchDown(_ sender:AnyObject)
    {
        LoginActivityIndicator.startAnimating()
        activityIndicator.startAnimating()
        //activityIndicator.hidden = false
    }
    
    @IBAction func LoginBtnTouchDownRepeat(_ sender:AnyObject)
    {
        self.ShowAlert("Alert", ContentString:"系統登入中，請稍候！", ActionString:"OK")
    }
    
    @IBAction func LoginBtnClick(_ sender:AnyObject)
    {
        //檢查帳號密碼不為空值
        if self.AccountTextField.text == ""
        {
            self.ShowAlert("Alert", ContentString:"帳號空白，請重新輸入！", ActionString:"OK")
        }
        else if self.PasswordTextField.text == ""
        {
            self.ShowAlert("Alert", ContentString:"密碼空白，請重新輸入！", ActionString:"OK")
        }
        else
        {
            let delegate = UIApplication.shared.delegate as! AppDelegate
            //密碼進行ＢＡＳＥ６４加密
            let pwd : String = PasswordTextField.text!
            let pwdStr = pwd.data(using: String.Encoding.utf8)
            let encodedPwd = pwdStr?.base64EncodedString(options: NSData.Base64EncodingOptions.lineLength64Characters)
            //print(encodedPwd)
            
            //驗證AD帳號密碼
            //let succeed = true
            var tokenId : String = ""
            /*#if TARGET_IPHONE_SIMULATOR
                tokenId = "IPHONE_SIMULATOR"
            #else
                //真機執行
                tokenId = delegate.deviceTokenId
            #endif*/
            if Platform.isSimulator {
                tokenId = "IPHONE_SIMULATOR"
            }
            else {
                tokenId = delegate.deviceTokenId
            }
            //let succeed = true
            let (succeed, succeedMsg) = postJsonUsingSynchronousRequest(self.AccountTextField.text!, pwd: encodedPwd as String!, token: tokenId)
            if (succeed)
            {
                //设置存储信息
                UserDefaults.standard.set(self.AccountTextField.text, forKey: "UserNameKey")
                UserDefaults.standard.set(self.PasswordTextField.text, forKey: "PwdKey")
                //设置同步
                UserDefaults.standard.synchronize()
                
                self.performSegue(withIdentifier: "LoginSegue", sender: self)
            }
            else
            {
                self.ShowAlert("Alert", ContentString:succeedMsg, ActionString:"OK")
            }
        }
        activityIndicator.stopAnimating()
        LoginActivityIndicator.stopAnimating()
    }
    
    @IBAction func alertControllerAction(_ sender: AnyObject)
    {
        // insert Simple UIAlertController code here..
        let alertController = UIAlertController(title: "Default AlertController", message: "A standard alert", preferredStyle: .alert)
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action:UIAlertAction) in
            //print("you have pressed the Cancel button");
        }
        alertController.addAction(cancelAction)
        
        let OKAction = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction) in
            //print("you have pressed OK button");
        }
        alertController.addAction(OKAction)
        
        self.present(alertController, animated: true, completion:nil)
    }
    
    func setDefaultAccount()
    {
        let StrUsernameKey:String = "username"
        let StrPasswordKey:String = "password"
        let saveSuccessful:Bool=KeychainWrapper.setString(AccountTextField.text!, forKey:StrUsernameKey)
        print("saveSuccessful=\(saveSuccessful)") //saveSuccessful=true
        let retrievedString: String? = KeychainWrapper.stringForKey(StrUsernameKey)
        print("retrievedString=\(retrievedString)") //retrievedString=Optional("xxx")
        let removeSuccessful: Bool = KeychainWrapper.removeObjectForKey(StrUsernameKey)
        print("removeSuccessful=\(removeSuccessful)") //removeSuccessful=true
        let retrievedStringAfterDelete: String? = KeychainWrapper.stringForKey(StrUsernameKey)
        print("retrievedStringAfterDelete=\(retrievedStringAfterDelete)") //retrievedStringAfterDelete=nil
    }
    
    //NSURLConnection.sendSynchronousRequest() 在 iOS 9 已經不推薦使用
    func postJsonUsingSynchronousRequest(_ account:String, pwd:String, token:String) -> (Bool, String)
    {
        var succeed:Bool = false
        var succeedMsg:String = ""
        //清空login token
        loginToken = ""
        loginName = ""
        
        let request = NSMutableURLRequest(url: URL(string: "http://103.227.33.247/F1SV/json/login.json")!)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        print("Login device token : \(token)")
        
        let params = ["cn" : account, "pwd" : pwd, "src" : "MERP", "remark" : "devicetype=\(deviceType),devicetoken=\(token)"] as Dictionary<String, String>
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: params, options: [])
            
        } catch {
            print(error)
            request.httpBody = nil
        }
        
        var response:URLResponse?
        //var error:NSError?
        do {
            let resData = try NSURLConnection.sendSynchronousRequest(request as URLRequest, returning: &response)
            
            // Parse the data
            let myData = NSString(data:resData, encoding: String.Encoding.utf8.rawValue) as! String
            
            //print("Response: \(response)")
            //print("myData: \(myData)")
            succeed = true
            let json: NSDictionary?
            do {
                json = try JSONSerialization.jsonObject(with: resData, options: .mutableLeaves) as? NSDictionary
            } catch let dataError {
                // Did the JSONObjectWithData constructor return an error? If so, log the error to the console
                //print(dataError)
                let jsonStr = NSString(data: resData, encoding: String.Encoding.utf8.rawValue)
                //print("Error could not parse JSON: '\(jsonStr)'")
                // return or throw?
                //self.ShowAlert("Alert", ContentString:"伺服器回傳結果異常，請通知系統管理員！", ActionString:"OK")
                succeed = false
                succeedMsg = "Error could not parse JSON: '\(jsonStr)'"
                return (succeed, succeedMsg)
            }

            if let parseJSON = json {
                // Okay, the parsedJSON is here, let's get the value for 'success' out of it
                //let success = parseJSON["statusMsg"] as? String
                let successCode = parseJSON["statusCd"] as? String
                
                if successCode == "0000"{
                    succeed = true
                    
                    //帳密正確才取登入資訊
                    loginToken = parseJSON["aToken"] as! String
                    loginName = parseJSON["name"] as! String
                    loginDepartment = parseJSON["costCd"] as! String
                    loginAuthorization = ""
                    if let items = parseJSON["funSSet"] as? [String] {
                        /*for item in items {
                         print("funsControlCd : \(item)")
                         }*/
                        loginAuthorizationArr = items
                    }
                    /*if let items = parseJSON["funMList"] as? [[String: AnyObject]] {
                     for item in items {
                     let functionItem = item["funmControlCd"] as? String
                     //讀取訂單模組的權限
                     if functionItem == "ERP_ORDER"
                     {
                     if let funs = item["auFunctionSubPo"] as? [[String: AnyObject]] {
                     for fun in funs {
                     if let funsControl = fun["funsControlCd"] as? String {
                     if loginAuthorization != "ORDER_ALL_DATA"
                     {
                     loginAuthorization = funsControl
                     }
                     print("funsControlCd is \(funsControl)")
                     }
                     }
                     }
                     break
                     }
                     }
                     }*/
                }else{
                    succeed = false
                    succeedMsg = parseJSON["statusMsg"] as! String
                }
                //它叫Closures（閉包）不叫function（函式）
                //self.ShowAlert("Message", ContentString:success!, ActionString:"OK")
            }
            else {
                // Woa, okay the json object was nil, something went worng. Maybe the server isn't running?
                let jsonStr = NSString(data: resData, encoding: String.Encoding.utf8.rawValue)
                //print("Error could not parse JSON: \(jsonStr)")
                succeedMsg = "Error could not parse JSON: \(jsonStr)"
                succeed = false
                //self.ShowAlert("Alert", ContentString:"伺服器異常，請通知系統管理員！", ActionString:"OK")
            }
            
        } catch {
            // handle error
            succeedMsg = "Catch error: \(error)"
            succeed = false
        }
        
        return (succeed, succeedMsg)
    }
    
    //讀取POST json
    func postJson() -> Bool
    {
        //let request = NSMutableURLRequest(url: URL(string: "http://103.227.33.247/F1SV/json/login.json")!)
        var request = URLRequest(url: URL(string: "http://103.227.33.247/F1SV/json/login.json")!)
        let session = URLSession.shared
        
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        //request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        let params = ["cn" : self.AccountTextField.text!, "pwd" : self.PasswordTextField.text!] as Dictionary<String, String>
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: params, options: [])
        } catch {
            print(error)
            request.httpBody = nil
        }
        
        var succeed:Bool=false
        let task = session.dataTask(with: request)
        {
            data, response, error -> Void in
            //let task = session.dataTask(with: request, completionHandler: {data, response, error -> Void in
            // handle error
            guard error == nil
                else
            {
                return
            }
            print("Response: \(response)")
            let strData = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print("Body: \(strData)")  //{"statusCd":"0001","statusMsg":"帳號密碼錯誤","aToken":null}
            let json: NSDictionary?
            do {
                json = try JSONSerialization.jsonObject(with: data!, options: .mutableLeaves) as? NSDictionary
            } catch let dataError {
                // Did the JSONObjectWithData constructor return an error? If so, log the error to the console
                print(dataError)
                let jsonStr = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                print("Error could not parse JSON: '\(jsonStr)'")
                // return or throw?
                //self.ShowAlert("Alert", ContentString:"伺服器回傳結果異常，請通知系統管理員！", ActionString:"OK")
                return
            }
            
            // The JSONObjectWithData constructor didn't return an error. But, we should still
            // check and make sure that json has a value using optional binding.
            if let parseJSON = json {
                // Okay, the parsedJSON is here, let's get the value for 'success' out of it
                let success = parseJSON["statusMsg"] as? String
                let successCode = parseJSON["statusCd"] as? String
                print("Succes: \(success)")
                if successCode == "0000"{
                    succeed = true
                }else{
                    succeed = false
                }
                //它叫Closures（閉包）不叫function（函式）
                //self.ShowAlert("Message", ContentString:success!, ActionString:"OK")
            }
            else {
                // Woa, okay the json object was nil, something went worng. Maybe the server isn't running?
                let jsonStr = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                print("Error could not parse JSON: \(jsonStr)")
                succeed = false
                //self.ShowAlert("Alert", ContentString:"伺服器異常，請通知系統管理員！", ActionString:"OK")
            }
            
        }
        
        task.resume()
        return succeed
    }

    //Json POST
    //http://jamesonquave.com/blog/making-a-post-request-in-swift/
    //Json POST using swift 2.1 NSJSONSerialization.dataWithJSONObject
    //http://gokhantaymaz.com/2015/11/02/swift-2-1-ios9-nsjsonserialization-datawithjsonobject/
    
    func getJsonUseByErrorMsg(_ serviceLink:String) -> (Bool, String)
    {
        var succeed:Bool = false
        var errorMag:String = ""
        let request = NSMutableURLRequest(url: URL(string: serviceLink)!)
        request.httpMethod = "GET"
        //GET要塞入的Header
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("aaa", forHTTPHeaderField: "atoken")
        
        var response: URLResponse?
        do {
            let resData = try NSURLConnection.sendSynchronousRequest(request as URLRequest, returning: &response)
            do {
                //json = try NSJSONSerialization.JSONObjectWithData(resData, options: .MutableLeaves) as! Array

                //解析body
                errorObject = try JSONSerialization.jsonObject(with: resData, options: JSONSerialization.ReadingOptions.mutableContainers) as! Dictionary<String, AnyObject>
                succeed = true
                
            } catch let dataError {
                // Did the JSONObjectWithData constructor return an error? If so, log the error to the console
                print(dataError)
                let jsonStr = NSString(data: resData, encoding: String.Encoding.utf8.rawValue)
                print("Error could not parse JSON. \r\n '\(jsonStr)'")
                errorMag = "Error could not parse JSON. \r\n '\(jsonStr)'"
                succeed = false
            }
            
        } catch {
            print("Send request error.\r\n '\(error)'")
            errorMag = "Send request error.\r\n '\(error)'"
            succeed = false
        }
        return (succeed, errorMag)
    }
    
    func getJsonUseByVersion(_ serviceLink:String) -> (Bool, String)
    {
        var succeed:Bool = false
        var appVersion:String = ""
        let request = NSMutableURLRequest(url: URL(string: serviceLink)!)
        request.httpMethod = "GET"
        //GET要塞入的Header
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        var response: URLResponse?
        do {
            let resData = try NSURLConnection.sendSynchronousRequest(request as URLRequest, returning: &response)
            let json: NSDictionary?
            do {
                //解析body
                json = try JSONSerialization.jsonObject(with: resData, options: .mutableLeaves) as? NSDictionary
                if let parseJSON = json {
                    appVersion = (parseJSON["version"] as? String)!
                }
                succeed = true
            } catch let dataError {
                print(dataError)
                let jsonStr = NSString(data: resData, encoding: String.Encoding.utf8.rawValue)
                print("Error could not parse JSON. \r\n '\(jsonStr)'")
                succeed = false
            }
        } catch {
            print("Send request error.\r\n '\(error)'")
            succeed = false
        }
        return (succeed, appVersion)
    }
    
    /*static func ReadErrorMsg(errorCode:String) -> String
    {
        if errorObject.count == 0
        {
            return ""
        }
        else
        {
            return errorObject[errorCode] as! String
        }
    }*/
    
    //把String轉Dictionary
    func convertStringToDictionary(_ text: String) -> [String:AnyObject]? {
        print(text)
        if let data = text.data(using: String.Encoding.utf8, allowLossyConversion: true) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: .mutableLeaves) as? [String:AnyObject]
            } catch let error as NSError {
                print(error)
            }
        }
        return nil
    }
    
    func ShowAlert(_ titleString:String, ContentString:String, ActionString:String)
    {
        let alertController = UIAlertController(title: titleString, message:
            ContentString, preferredStyle: UIAlertControllerStyle.alert)
        alertController.addAction(UIAlertAction(title: ActionString, style: UIAlertActionStyle.default,handler: nil))
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    //***************************************************************************************************
    //鍵盤出現view上移
    @IBAction func textFieldDidBeginEditing(_ textField: UITextField) {
        animateViewMoving(true, moveValue: 100)
    }
    
    //鍵盤離開view下移
    @IBAction func textFieldDidEndEditing(_ textField: UITextField) {
        animateViewMoving(false, moveValue: 100)
    }
    
    func animateViewMoving(_ up:Bool, moveValue :CGFloat){
        let movementDuration:TimeInterval = 0.3
        let movement:CGFloat = (up ? -moveValue : moveValue)
        UIView.beginAnimations("animateView", context: nil)
        UIView.setAnimationBeginsFromCurrentState(true)
        UIView.setAnimationDuration(movementDuration)
        self.view.frame = self.view.frame.offsetBy(dx: 0, dy: movement)
        UIView.commitAnimations()
    }
    
    //鍵盤按下Retrun鍵會呼叫的事件
    func textFieldShouldReturn(_ textField:UITextField) -> Bool
    {
        if(textField == AccountTextField)
        {
            //跳至密碼欄位
            PasswordTextField.becomeFirstResponder()
            return false
        }
        else
        {
            //收起键盘
            textField.resignFirstResponder()
        }
        return true
    }
    
    //設定頁面是否可以旋轉
    override var shouldAutorotate : Bool {
        return false
    }
    
    override var supportedInterfaceOrientations : UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
}

