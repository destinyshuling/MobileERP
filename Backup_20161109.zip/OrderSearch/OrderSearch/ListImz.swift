//
//  ListImz.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/8/16.
//  Copyright © 2016年 onto. All rights reserved.
//

import Foundation
import CoreData

//分群碼資料
class ListImz:NSManagedObject
{
    //分群碼代號
    @NSManaged var imz01:String
    //分群碼說明
    @NSManaged var imz02:String
}