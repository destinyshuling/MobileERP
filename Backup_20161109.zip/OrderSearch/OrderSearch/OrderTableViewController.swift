//
//  OrderTableViewController.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/5/24.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit
import CoreData
import MessageUI
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}


class OrderTableViewController: UITableViewController, NSFetchedResultsControllerDelegate, UISearchResultsUpdating, MFMailComposeViewControllerDelegate, SectionHeaderViewDelegate
{
    @IBOutlet var baritemBtn: UIBarButtonItem!
    
    //查詢頁面傳遞過來的資料內容
    var dataDepart:String = ""
    var dataQuarter:String = ""
    var dataSort:String = ""
    var serviceToken:String = ""
    var dataSortCode:String = ""
    //var errorObject = [ErrorMsg]()
    var errorObject: Dictionary<String, AnyObject> = [:]
    var internetReachability:Reachability!; //網路狀態監控
    
    var jsonResult = JsonParser()
    var alertObject = ShowAlert()
    
    var orders = [Order]()
    //儲存搜尋完的訂單資料
    var searchOrders = [Order]()
    
    //分群訂單array
    var ordersClassify = [String]()
    //var ordersTotalAmount = [Int]()
    var ordersArray = [[Order]]()
    //2016/08/19 整頁訂單總金額
    var ordersAmount:Int = 0
    //2016/10/05 整頁訂單立帳總金額
    var ordersArAmount:Int = 0
    
    //Custom Class Array -> test failed by 6/22
    //var orderCollection = [GroupedOrder]()
    
    weak var activityIndicatorView: UIActivityIndicatorView!
    var activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .whiteLarge)
    
    //搜尋欄
    var searchController:UISearchController!
    //var fetchResultController:NSFetchedResultsController!
    
    var tableViewHeader:UIView!
    var headerAmount:UILabel!
    var headerFlag:Bool = true  //true顯示"訂單總額"，false顯示"立帳總額"
    
    //表格縮合
    let SectionHeaderViewIdentifier = "SectionHeaderViewIdentifier"
    var plays:NSArray!
    var sectionInfoArray:NSMutableArray!
    var pinchedIndexPath:IndexPath!
    var opensectionindex:Int!
    var initialPinchHeight:CGFloat!
    
    //var ordersCollection:NSMutableArray! = NSMutableArray()
    var ordersCollection = [GroupedOrder]()
    var sectionHeaderView:SectionHeaderView!
    
    //当缩放手势同时改变了所有单元格高度时使用uniformRowHeight
    var uniformRowHeight: Int!
    let DefaultRowHeight = 80
    let HeaderHeight = 45
    
    //取得螢幕寬度
    var screenWidth: Int = 0
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //顯示等候視窗
        view.addSubview(activityIndicator)
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        activityIndicator.color = UIColor.red
        activityIndicator.hidesWhenStopped = true
        let horizontalConstraint = NSLayoutConstraint(item: activityIndicator, attribute: NSLayoutAttribute.centerX, relatedBy: NSLayoutRelation.equal, toItem: view, attribute: NSLayoutAttribute.centerX, multiplier: 1, constant: 0)
        view.addConstraint(horizontalConstraint)
        
        let verticalConstraint = NSLayoutConstraint(item: activityIndicator, attribute: NSLayoutAttribute.centerY, relatedBy: NSLayoutRelation.equal, toItem: view, attribute: NSLayoutAttribute.centerY, multiplier: 1, constant: 0)
        view.addConstraint(verticalConstraint)
        
        activityIndicator.startAnimating()
        activityIndicator.isHidden = false
        
        //顯示搜尋欄
        searchController = UISearchController(searchResultsController: nil)
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "訂單客戶..."
        
        //self.tableView.tableHeaderView = searchController.searchBar
        
        /*let tableViewHeader = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 80))
        tableViewHeader.backgroundColor = UIColor.lightTextColor()
        tableViewHeader.addSubview(searchController.searchBar)
        
        let headerAmount = UILabel(frame: CGRectMake(8, 40, tableView.frame.width, 40))
        headerAmount.font = headerAmount.font.fontWithSize(18)
        headerAmount.text = "總金額：NTD$ 3,472,972,859"
        headerAmount.textColor = UIColor.blueColor()
        headerAmount.textAlignment = .Center;
        tableViewHeader.addSubview(headerAmount)
        
        self.tableView.tableHeaderView = tableViewHeader*/
        
        //Footer
        /*let tableViewFooter = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 50))
        tableViewFooter.backgroundColor = UIColor.lightGrayColor()
        let version = UILabel(frame: CGRectMake(8, 15, tableView.frame.width, 30))
        version.font = version.font.fontWithSize(14)
        version.text = "Version 1.x"
        version.textColor = UIColor.blueColor()
        version.textAlignment = .Center;
        tableViewFooter.addSubview(version)
        tableView.tableFooterView  = tableViewFooter*/
        
        //設定view標題
        title = "訂單總覽"
        
        // 为表视图添加缩放手势识别
        let pinchRecognizer = UIPinchGestureRecognizer(target: self, action:#selector(OrderTableViewController.handlePinch(_:)))
        self.tableView.addGestureRecognizer(pinchRecognizer)
        
        // 分节信息数组在viewWillUnload方法中将被销毁，因此在这里设置Header的默认高度是可行的。如果您想要保留分节信息等内容，可以在指定初始化器当中设置初始值。
        self.uniformRowHeight = DefaultRowHeight
        self.opensectionindex = NSNotFound
        
        let sectionHeaderNib: UINib = UINib(nibName: "SectionHeaderView", bundle: nil)
        self.tableView.register(sectionHeaderNib, forHeaderFooterViewReuseIdentifier: SectionHeaderViewIdentifier)
        
        //取得螢幕大小
        let screenSize: CGRect = UIScreen.main.bounds
        screenWidth = Int(screenSize.width)
        print("screenWidth = \(screenWidth)")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        //先檢查網路連線
        let networksStatus: NetworkStatus = self.internetReachability.currentReachabilityStatus()
        if networksStatus == NotReachable {
            let alertController = alertObject.ShowAlert("Error", ContentString:"未偵測到網路連線，無法查詢資料！", ActionString:"OK")
            self.present(alertController, animated: true, completion: nil)
        }
        else
        {
            if ordersClassify.count == 0
            {
                var result = false
                var loopCount = 1
                let service = MakeOrderQuery()
                
                repeat {
                    let (succeed, errorMsg) = postJsonUseByOrderQuery(service, atoken: serviceToken)
                    result = succeed
                    if (!succeed)
                    {
                        let alertController = alertObject.ShowAlert("Alert \(loopCount)", ContentString:errorMsg, ActionString:"OK")
                        self.present(alertController, animated: true, completion: nil)
                    }
                    else
                    {
                        //2016/10/05 若選擇客戶分群，則以section的訂單總金額重新排序一次
                        if dataSort == "訂單客戶"
                        {
                            sortOrderCollection()
                        }
                        //建立section info
                        createSectionInfo()
                        
                        self.tableView.reloadData()
                        searchController.searchBar.placeholder = "訂單客戶..."
                        
                        //＄\(String.stringSeparsted(amount)) NTD"
                        tableViewHeader = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 80))
                        tableViewHeader.backgroundColor = UIColor(red: 242.0/255.0, green: 220.0/255.0, blue: 219.0/255.0, alpha: 1.0)
                        tableViewHeader.addSubview(searchController.searchBar)
                        
                        headerAmount = UILabel(frame: CGRect(x: 0, y: 43, width: tableView.frame.width, height: 40))
                        headerAmount.font = headerAmount.font.withSize(18)
                        headerAmount.text = "訂單總額：NTD $ \(String.stringSeparsted(number: Double(ordersAmount)))"
                        headerAmount.textColor = UIColor(red: 196.0/255.0, green: 1.0/255.0, blue: 5.0/255.0, alpha: 1.0)
                        headerAmount.textAlignment = .center;
                        tableViewHeader.addSubview(headerAmount)
                        
                        self.tableView.tableHeaderView = tableViewHeader
                    }
                    
                    loopCount = loopCount + 1
                }while(!result && loopCount <= 3)
                
                activityIndicator.stopAnimating()
            }
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        if searchController.isActive
        {
            return 1
        }
        else
        {
            return ordersClassify.count
        }
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        //return orders.count
        if searchController.isActive
        {
            return searchOrders.count
        }
        else
        {
            //return ordersArray[section].count
            //return (ordersCollection![section] as! GroupedOrder).OrderArray.count
            
            let sectioninfo: SectionInfo = self.sectionInfoArray[section] as! SectionInfo
            //let numInSection = sectioninfo.grouporders.OrderArray.count
            let numInSection:Int = sectioninfo.rowCount
            let sectionOpen = sectioninfo.open
            return (sectionOpen != nil && sectionOpen == true) ? numInSection : 0
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "OrderCell", for: indexPath) as! OrderTableViewCell
        // Configure the cell... Section \(indexPath.section)
        if searchController.isActive
        {
            cell.orderId.text = searchOrders[(indexPath as NSIndexPath).row].OrderId
            cell.orderDate.text = searchOrders[(indexPath as NSIndexPath).row].OrderDate
            cell.orderCustomer.text = searchOrders[(indexPath as NSIndexPath).row].OrderCustomer
            cell.orderCustomerId.text = searchOrders[(indexPath as NSIndexPath).row].OrderCustomerId
            //cell.orderAmount.text = String.stringSeparsted(number: searchOrders[(indexPath as NSIndexPath).row].OrderAmount)
            //cell.orderCurrency.text = searchOrders[(indexPath as NSIndexPath).row].OrderCurrency
            cell.orderTwdAmount.text = String.stringSeparsted(number: Double(searchOrders[(indexPath as NSIndexPath).row].OrderTwdAmount))
            cell.orderTwdArAmount.text = String.stringSeparsted(number: Double(searchOrders[(indexPath as NSIndexPath).row].OrderTwdAmount))
            if (searchOrders[(indexPath as NSIndexPath).row].OrderStatus == "0" )
            {
                let image : UIImage = UIImage(named: "status_done")!
                cell.orderStatus.image = image
            }
            else
            {
                let image : UIImage = UIImage(named: "status_going")!
                cell.orderStatus.image = image
            }
        }
        else
        {
            /*cell.orderId.text = ordersArray[indexPath.section][indexPath.row].OrderId
            cell.orderDate.text = ordersArray[indexPath.section][indexPath.row].OrderDate
            cell.orderCustomer.text = ordersArray[indexPath.section][indexPath.row].OrderCustomer
            cell.orderCustomerId.text = ordersArray[indexPath.section][indexPath.row].OrderCustomerId
            cell.orderAmount.text = String.stringSeparsted(ordersArray[indexPath.section][indexPath.row].OrderAmount)
            cell.orderCurrency.text = ordersArray[indexPath.section][indexPath.row].OrderCurrency
            if (ordersArray[indexPath.section][indexPath.row].OrderStatus == "0")
            {
                let image : UIImage = UIImage(named: "status_done")!
                cell.orderStatus.image = image
            }
            else
            {
                let image : UIImage = UIImage(named: "status_going")!
                cell.orderStatus.image = image
            }*/
            
            //
            let arr:GroupedOrder = ordersCollection[(indexPath as NSIndexPath).section] //as! GroupedOrder
            let torder:Order = arr.OrderArray[(indexPath as NSIndexPath).row] as! Order
            cell.orderId.text = torder.OrderId
            cell.orderDate.text = torder.OrderDate
            cell.orderCustomer.text = torder.OrderCustomer
            cell.orderCustomerId.text = torder.OrderCustomerId
            //cell.orderAmount.text = String.stringSeparsted(number: torder.OrderAmount)
            //cell.orderCurrency.text = torder.OrderCurrency
            
            //2016/10/26
            if (screenWidth <= 320)
            {
                let twd = torder.OrderTwdAmount / 1000
                let twdAr = torder.OrderTwdArAmount / 1000
                
                cell.orderTwdAmount.text = String.stringSeparsted(number: Double(twd)) + "K"
                cell.orderTwdArAmount.text = String.stringSeparsted(number: Double(twdAr)) + "K"
            }
            else
            {
                cell.orderTwdAmount.text = String.stringSeparsted(number: Double(torder.OrderTwdAmount))
                cell.orderTwdArAmount.text = String.stringSeparsted(number: Double(torder.OrderTwdArAmount))
            }
            
            
            if (torder.OrderStatus == "0")
            {
                let image : UIImage = UIImage(named: "status_done")!
                cell.orderStatus.image = image
            }
            else
            {
                let image : UIImage = UIImage(named: "status_going")!
                cell.orderStatus.image = image
            }
            //逾期AR
            if torder.OrderOverDue == "true"
            {
                cell.orderTwdArAmount.textColor = UIColor.red
            }
            else
            {
                cell.orderTwdArAmount.textColor = UIColor.black
            }
        }
        return cell
    }
 
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        //Choose your custom row height
        return CGFloat(DefaultRowHeight)
    }
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        var headerTitle:String = ""
        //let amountNt = Double(round(ordersTotalAmount[section]))  //四捨五入
        //let amountNt = Double(ordersTotalAmount[section])  //四捨五入
        //OrderAmount
        
        if searchController.isActive
        {
            headerTitle = "搜尋結果 (\(searchOrders.count))"
        }
        else
        {
            /*switch dataSort {
            case "訂單客戶":
                headerTitle = "\(ordersArray[section][0].OrderCustomer)"  //-\(ordersClassify[section])
            case "訂單日期":
                headerTitle = "\(ordersClassify[section])"
            case "訂單狀態":
                if ordersClassify[section] == "0"
                {
                    headerTitle = "已結"
                }else
                {
                    headerTitle = "未結"
                }
            default:
                headerTitle = ""
            }
            //headerTitle = headerTitle + " (\(ordersArray[section].count))"
            headerTitle = headerTitle + " (\((ordersCollection![section] as! GroupedOrder).OrderArray.count))"*/
            
            headerTitle = "\(ordersCollection[section].GroupedName) (\(ordersCollection[section].OrderArray.count))"
        }
        
        //section header
        /*let headerView = UIView()
        let title = UILabel(frame: CGRectMake(8, 0, (tableView.frame.width)*0.4 - 8, 45))
        title.font = title.font.fontWithSize(18)
        title.text = headerTitle
        title.textColor = UIColor.lightGrayColor()
        title.textAlignment = .Left;  // 靠左顯示分群名稱
        headerView.addSubview(title)
        
        if searchController.active
        {
            headerAmount.text = ""            
        }
        else
        {
            //section header
            let amount = UILabel(frame: CGRectMake((tableView.frame.width)*0.4, 0, (tableView.frame.width)*0.6 - 8, 45))
            amount.font = title.font.fontWithSize(18)
            amount.text = "NTD＄\(String.stringSeparsted(amountNt))"
            amount.textColor = UIColor(red: 185.0/255.0, green: 122.0/255.0, blue: 87.0/255.0, alpha: 1.0)
            amount.textAlignment = .Right;  // 靠右顯示分群金額
            headerView.addSubview(amount)
            
            headerAmount.text = "訂單總額：NTD $ \(String.stringSeparsted(Double(ordersAmount)))"
        }*/
        
        // 返回指定的 section header 的view，如果没有，这个函数可以不返回view
        let sectionHeaderView: SectionHeaderView = self.tableView.dequeueReusableHeaderFooterView(withIdentifier: SectionHeaderViewIdentifier) as! SectionHeaderView
        
        let sectionInfo: SectionInfo = self.sectionInfoArray[section] as! SectionInfo
        sectionInfo.headerView = sectionHeaderView
        
        /*let amount = UILabel(frame: CGRectMake((tableView.frame.width)*0.4, 0, (tableView.frame.width)*0.6 - 8, 50))
        amount.text = "NTD＄\(String.stringSeparsted(amountNt))"
        amount.textColor = UIColor(red: 185.0/255.0, green: 122.0/255.0, blue: 87.0/255.0, alpha: 1.0)
        amount.textAlignment = .Right;  // 靠右顯示分群金額
        sectionHeaderView.addSubview(amount)*/
        
        //sectionHeaderView.contentView.backgroundColor = UIColor.lightGrayColor()
        sectionHeaderView.titleLabel.text = headerTitle
        if searchController.isActive
        {
            sectionHeaderView.amount.text = ""
        }
        else
        {
            
            let arr:GroupedOrder = ordersCollection[section]
            var amountNt:Double = 0.0
            if headerFlag
            {
                amountNt = Double(arr.OrderAmount)  //訂單總額
            }
            else
            {
                amountNt = Double(arr.OrderArAmount)    //立帳總額
            }
            sectionHeaderView.amount.text = "NTD＄\(String.stringSeparsted(number: amountNt))"
            sectionHeaderView.amount.textColor = UIColor(red: 185.0/255.0, green: 122.0/255.0, blue: 87.0/255.0, alpha: 1.0)
        }
        sectionHeaderView.section = section
        sectionHeaderView.delegate = self
        
        return sectionHeaderView
    }

    /*override func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String?
    {
        var headerTitle:String = ""
        if searchController.active
        {
            return "搜尋結果 (\(searchOrders.count))"
        }
        else
        {
            switch dataSort {
            case "訂單客戶":
                headerTitle = "\(ordersArray[section][0].OrderCustomer)"  //-\(ordersClassify[section])
            case "訂單日期":
                headerTitle = "\(ordersClassify[section])"
            case "訂單狀態":
                if ordersClassify[section] == "0"
                {
                    headerTitle = "已結"
                }else
                {
                    headerTitle = "未結"
                }
            default:
                headerTitle = ""
            }
            
            //四捨五入
            let amount = Double(round(ordersTotalAmount[section]))
            
            return headerTitle + " (\(ordersArray[section].count))  NTD＄\(String.stringSeparsted(amount)) "
        }
    }
    
    override func tableView(tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int)
    {
        var headerTitle:String = ""
        if searchController.active
        {
            headerTitle = "搜尋結果 (\(searchOrders.count))"
        }
        else
        {
            switch dataSort {
            case "訂單客戶":
                headerTitle = "\(ordersArray[section][0].OrderCustomer)-\(ordersClassify[section])"
            case "訂單日期":
                headerTitle = "\(ordersClassify[section])"
            case "訂單狀態":
                if ordersClassify[section] == "0"
                {
                    headerTitle = "已結"
                }else
                {
                    headerTitle = "未結"
                }
            default:
                headerTitle = ""
            }
        }
        
        let title = UILabel()
        title.font = UIFont(name: headerTitle, size: 30)
        title.textColor = UIColor.lightGrayColor()
        title.textAlignment = .Left
        
        let header = view as! UITableViewHeaderFooterView
        header.textLabel?.font = title.font
        header.textLabel?.textColor = title.textColor
    }*/
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 45.0
    }
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if segue.identifier == "OrderDetailSegue"
        {
            if let indexPath = tableView.indexPathForSelectedRow{
                let destinationController = segue.destination as! OrderDetailViewController
                //將客戶資料傳遞到下一個頁面
                if searchController.isActive
                {
                    destinationController.order = searchOrders[(indexPath as NSIndexPath).row]
                }
                else
                {
                    let arr:GroupedOrder = ordersCollection[(indexPath as NSIndexPath).section]
                    let torder:Order = arr.OrderArray[(indexPath as NSIndexPath).row] as! Order
                    destinationController.order = torder
                }
                destinationController.serviceToken = serviceToken
                destinationController.errorObject = errorObject
                destinationController.internetReachability = internetReachability
            }
        }
    }
    
    //設定頁面是否可以旋轉
    override var shouldAutorotate : Bool {
        return true
    }
    
    override var supportedInterfaceOrientations : UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.allButUpsideDown
    }
    
    //更改訂單總覽Header title
    @IBAction func changeTableHeaderTitle(_ sender: UIButton)
    {
        var btnTitle:String = ""
        if headerFlag
        {
            headerAmount.text = "立帳總額：NTD $ \(String.stringSeparsted(number: Double(ordersArAmount)))"
            btnTitle = "訂單"
        }
        else
        {
            headerAmount.text = "訂單總額：NTD $ \(String.stringSeparsted(number: Double(ordersAmount)))"
            btnTitle = "立帳"
        }
        self.tableView.reloadData()
        headerFlag = !headerFlag
        baritemBtn.title = btnTitle
    }
    
    //***************************************************************************************************************************
    //組web service link
    func MakeOrderQuery() -> String
    {
        var dataDepartCode:String!
        var dataQuarterCode:String!
        var serviceLink:String!
        
        switch dataDepart {
        case "材化一部":
            dataDepartCode = "111"
        case "材化二部":
            dataDepartCode = "112"
        case "材化三部":
            dataDepartCode = "113"
        case "材化四部":
            dataDepartCode = "114"
        case "材化五部":
            dataDepartCode = "115"
        case "材化六部":
            dataDepartCode = "116"
        default:
            dataDepartCode = ""
        }
        
        //去除字串內的空格，2016 Q2 -> 2016Q2
        dataQuarterCode = dataQuarter.replacingOccurrences(of: " ", with: "")
        
        //組合web service link
        serviceLink = "http://103.227.33.247/F1SV/json/listOrder.json?customerCode=&yearQuarter=" + dataQuarterCode + "&oea15Cd3=" + dataDepartCode + "&pageNo=0"
        
        return serviceLink
    }
    
    //查詢訂單單頭ＪＳＯＮ
    func postJsonUseByOrderQuery(_ serviceLink:String, atoken:String) -> (Bool, String)
    {
        var succeed:Bool = false
        var errorMag:String = ""
        let request = NSMutableURLRequest(url: URL(string: serviceLink)!)
        request.httpMethod = "GET"
        //GET要塞入的Header
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue(atoken, forHTTPHeaderField: "atoken")
        
        ordersAmount = 0
        ordersArAmount = 0
        var response: URLResponse?
        do {
            let resData = try NSURLConnection.sendSynchronousRequest(request as URLRequest, returning: &response)
            
            //若是以狀態排序，未結訂單要排序在上方
            if dataSort == "出貨狀態" || dataSort == "立帳狀態"
            {
                let torderArray = [Order]()
                if dataSort == "立帳狀態"
                {
                    ordersClassify.append("2")
                    //ordersTotalAmount.append(0)
                    ordersArray.append(torderArray)
                }
                ordersClassify.append("1")
                ordersClassify.append("0")
                //2016/08/19
                //ordersTotalAmount.append(0)
                //ordersTotalAmount.append(0)
                
                ordersArray.append(torderArray)
                ordersArray.append(torderArray)
                
                let orders = NSMutableArray()
                let orders2 = NSMutableArray()
                let grouporders: GroupedOrder! = GroupedOrder()
                //grouporders.GroupedName = "未出貨"      //分群名稱
                grouporders.OrderAmount = 0
                grouporders.OrderArAmount = 0
                grouporders.OrderArray = orders
                ordersCollection.append(grouporders)
                
                let grouporders2: GroupedOrder! = GroupedOrder()
                //grouporders2.GroupedName = "出貨完成"      //分群名稱
                grouporders2.OrderAmount = 0
                grouporders2.OrderArAmount = 0
                grouporders2.OrderArray = orders2
                ordersCollection.append(grouporders2)
                
                switch dataSort {
                case "出貨狀態":
                    grouporders.GroupedName = "未出貨"
                    grouporders2.GroupedName = "出貨完成"
                case "立帳狀態":
                    grouporders.GroupedName = "逾期立帳"
                    grouporders2.GroupedName = "未立帳"
                    let orders3 = NSMutableArray()
                    let grouporders3: GroupedOrder! = GroupedOrder()
                    grouporders3.GroupedName = "已立帳"      //分群名稱
                    grouporders3.OrderAmount = 0
                    grouporders3.OrderArAmount = 0
                    grouporders3.OrderArray = orders3
                    ordersCollection.append(grouporders3)
                default:
                    break
                }
            }
            
            //處理回傳的Body -> Json 格式
            //let myData = NSString(data:resData, encoding: NSUTF8StringEncoding) as! String
            var json: Array<AnyObject>  //不知道為什麼一定要放在這一行，json才不會是nil.....
            do {
                json = try JSONSerialization.jsonObject(with: resData, options: .mutableLeaves) as! Array
                //解析body
                for jsonpattern in json{
                    //訂單總金額
                    let strVar : String = jsonpattern["oea61"] as! String
                    let amount = NSString(string: strVar)

                    //訂單總金額（台幣）
                    let amount2 : Int = jsonpattern["oea61twd"] as! Int
                    //let amount2 = NSString(string: strVar2)
                    //立帳總金額（台幣）
                    let amount3 : Int = jsonpattern["omb14ntdsum"] as! Int
                    
                    let tOrder:Order = Order(orderDate: jsonpattern["oea02"] as! String, orderId: jsonpattern["oea01"] as! String, orderCustomerId: jsonpattern["oea03"] as! String, orderCustomer: jsonpattern["oea032"] as! String, orderCurrency: jsonpattern["oea23"] as! String, orderAmount: amount.doubleValue, orderDepart: jsonpattern["oea15"] as! String, orderStatus: jsonpattern["oeb23bSum"] as! String, orderTwdAmount: amount2, orderTwdArAmount: amount3, orderOverDue:jsonpattern["overduear"] as! String)
                    orders.append(tOrder)
                    
                    ordersAmount = ordersAmount + amount2
                    ordersArAmount = ordersArAmount + amount3
                    //將訂單資料分群
                    //classifyOrders(tOrder)
                    
                    //使用NSMutableArray儲存分群資料
                    classifyMutableArrayOrders(tOrder)
                }
                succeed = true
                
            } catch let dataError {
                // Did the JSONObjectWithData constructor return an error? If so, log the error to the console
                //print(dataError)
                let jsonStr = NSString(data: resData, encoding: String.Encoding.utf8.rawValue)
                //print("Error could not parse JSON. \r\n '\(jsonStr)'")
                errorMag = "Error could not parse JSON. \r\n '\(jsonStr)'"
                succeed = false
            }
            
            //這個測試失敗！！！！！
            //處理回傳的Header -> 包含資料總筆數
            if let response = response as? HTTPURLResponse {
                if response.statusCode == 200 {
                    let resultCode = response.allHeaderFields["statusCd"] as! String
                    if resultCode == "5000"  //"執行成功"
                    {
                        let resultCount = response.allHeaderFields["totalCount"] as! String
                        let intCount = Int(resultCount)

                        //print("resultCount = '\(intCount)'")
                        if intCount == 0
                        {
                            let alertController = alertObject.ShowAlert("Alert", ContentString:"查詢無訂單資料！", ActionString:"OK")
                            self.present(alertController, animated: true, completion: nil)
                        }
                        succeed = true
                    }
                    else
                    {
                        if resultCode == "5001" //timeout
                        {
                            errorMag = "超過３０分鐘未操作，已自動登出，請重新登入！"
                            succeed = false
                        }
                        else
                        {
                            let codeMsg = ReadErrorMsg(resultCode)
                            errorMag = "Server回傳資料有誤！[\(resultCode)]\r\n\(codeMsg)"
                            succeed = false
                            //let alertController = alertObject.ShowAlert("Alert", ContentString:"Server回傳資料有誤！[\(resultCode)]\r\n\(errorMsg)", ActionString:"OK")
                            //self.presentViewController(alertController, animated: true, completion: nil)
                        }
                    }
                }
            }
        } catch {
            //print("Send request error.\r\n '\(error)'")
            errorMag = "Send request error.\r\n '\(error)'"
            succeed = false
        }
        return (succeed, errorMag)
    }
    
    func classifyOrders(_ tOrder:Order)
    {
        var keyvalue:String = ""
        switch dataSort {
        case "訂單客戶":
            keyvalue = tOrder.OrderCustomerId
        case "訂單日期":
            keyvalue = tOrder.OrderDate
        case "出貨狀態":
            if tOrder.OrderStatus == "0"
            {
                keyvalue = "0"   //出貨完成
            }
            else
            {
                keyvalue = "1"   //未出貨
            }
        case "立帳狀態":
            if tOrder.OrderTwdArAmount != 0
            {
                if tOrder.OrderOverDue == "true"
                {
                    keyvalue = "0"   //已逾期
                }
                else
                {
                    keyvalue = "1"   //已立帳
                }
            }
            else
            {
                keyvalue = "2"   //未立帳
            }
        default:
            keyvalue = ""
        }

        /*let index = orderColSet.indexOf({$0.GroupedName == keyvalue})! as Int
        if index >= 0
        {
            // it exists, do something
            orderColSet[index].OrderArray.append(tOrder)
        }
        else
        {
            // item not found
            var torderArray = [Order]()
            torderArray.append(tOrder)
            
            let torderCollection:GroupedOrder = GroupedOrder(groupedName:keyvalue, orderArray:torderArray)
            orderColSet.append(torderCollection)
            //orderColSet[0] = torderCollection
        }*/
        
        if ordersClassify.contains(keyvalue)
        {
            let index = ordersClassify.index(where: {$0 == keyvalue})! as Int
            ordersArray[index].append(tOrder)
            //2016/08/19 新增訂單總金額顯示
            //ordersTotalAmount[index] = ordersTotalAmount[index] + tOrder.OrderTwdAmount
        }
        else
        {
            // item not found
            var torderArray = [Order]()
            torderArray.append(tOrder)
            ordersArray.append(torderArray)
            //ordersArray[ordersClassify.count].append(tOrder)
            
            ordersClassify.append(keyvalue)
            //ordersTotalAmount.append(tOrder.OrderTwdAmount)
        }
    }
    
    func ReadErrorMsg(_ errorCode:String) -> String
    {
        if errorObject.count == 0
        {
            return ""
        }
        else
        {
            return errorObject[errorCode] as! String
        }
    }
    
    //Search Bar 過濾資料
    func filterContentForSearchText(_ searchText: String)
    {
        searchOrders = orders.filter({ (order:Order) -> Bool in
            let nameMatch = order.OrderCustomer.range(of: searchText, options: NSString.CompareOptions.caseInsensitive)
            return nameMatch != nil
        })
    }
    
    func updateSearchResults(for searchController: UISearchController){
        if let searchText = searchController.searchBar.text {
            filterContentForSearchText(searchText)
            tableView.reloadData()
        }
    }
    
    // SectionHeaderViewDelegate
    func sectionHeaderView(_ sectionHeaderView: SectionHeaderView, sectionOpened: Int)
    {
        let sectionInfo: SectionInfo = self.sectionInfoArray[sectionOpened] as! SectionInfo
        sectionInfo.open = true
        
        //创建一个包含单元格索引路径的数组来实现插入单元格的操作：这些路径对应当前节的每个单元格
        //let countOfRowsToInsert = sectionInfo.grouporders.OrderArray.count
        let countOfRowsToInsert:Int = sectionInfo.rowCount
        let indexPathsToInsert = NSMutableArray()
        
        for i in (0 ..< countOfRowsToInsert) {
            indexPathsToInsert.add(IndexPath(row: i, section: sectionOpened))
        }
        
        // 创建一个包含单元格索引路径的数组来实现删除单元格的操作：这些路径对应之前打开的节的单元格
        
        let indexPathsToDelete = NSMutableArray()
        let previousOpenSectionIndex = self.opensectionindex
        if previousOpenSectionIndex != NSNotFound {
            
            let previousOpenSection: SectionInfo = self.sectionInfoArray[previousOpenSectionIndex!] as! SectionInfo
            previousOpenSection.open = false
            previousOpenSection.headerView.toggleOpenWithUserAction(false)
            //var countOfRowsToDelete = previousOpenSection.grouporders.OrderArray.count
            let countOfRowsToDelete:Int = previousOpenSection.rowCount
            for i in (0 ..< countOfRowsToDelete) {
                indexPathsToDelete.add(IndexPath(row: i, section: previousOpenSectionIndex!))
            }
        }
        
        // 设计动画，以便让表格的打开和关闭拥有一个流畅（很屌）的效果
        var insertAnimation: UITableViewRowAnimation
        var deleteAnimation: UITableViewRowAnimation
        if previousOpenSectionIndex == NSNotFound || sectionOpened < previousOpenSectionIndex {
            insertAnimation = UITableViewRowAnimation.top
            deleteAnimation = UITableViewRowAnimation.bottom
        }else{
            insertAnimation = UITableViewRowAnimation.bottom
            deleteAnimation = UITableViewRowAnimation.top
        }
        
        // 应用单元格的更新
        self.tableView.beginUpdates()
        self.tableView.deleteRows(at: (indexPathsToDelete as? [IndexPath])!, with: deleteAnimation)
        self.tableView.insertRows(at: (indexPathsToInsert as? [IndexPath])!, with: insertAnimation)
        
        self.opensectionindex = sectionOpened
        
        self.tableView.endUpdates()
    }
    
    func sectionHeaderView(_ sectionHeaderView: SectionHeaderView, sectionClosed: Int)
    {
        // 在表格关闭的时候，创建一个包含单元格索引路径的数组，接下来从表格中删除这些行
        let sectionInfo: SectionInfo = self.sectionInfoArray[sectionClosed] as! SectionInfo
        
        sectionInfo.open = false
        let countOfRowsToDelete = self.tableView.numberOfRows(inSection: sectionClosed)
        
        if countOfRowsToDelete > 0 {
            let indexPathsToDelete = NSMutableArray()
            for i in (0 ..< countOfRowsToDelete) {
                indexPathsToDelete.add(IndexPath(row: i, section: sectionClosed))
            }
            self.tableView.deleteRows(at: (indexPathsToDelete as? [IndexPath])!, with: UITableViewRowAnimation.top)
        }
        self.opensectionindex = NSNotFound
    }
    
    // ____________________________________________________________________
    // 缩放操作处理
    
    func handlePinch(_ pinchRecognizer: UIPinchGestureRecognizer) {
        
        // 有手势识别有很多状态来对应不同的动作：
        // * 对于 Began 状态来说，是用缩放点的位置来找寻单元格的索引路径，并将索引路径与缩放操作进行绑定，同时在 pinchedIndexPath 中保留一个引用。接下来方法获取单元格的高度，然后存储其在缩放开始前的高度。最后，为缩放的单元格更新比例。
        // * 对于 Changed 状态来说，是为缩放的单元格更新比例（由 pinchedIndexPath 支持）
        // * 对于 Ended 或者 Canceled状态来说，是将 pinchedIndexPath 属性设置为 nil
        
        NSLog("pinch Gesture")
        if pinchRecognizer.state == UIGestureRecognizerState.began {
            
            let pinchLocation = pinchRecognizer.location(in: self.tableView)
            let newPinchedIndexPath = self.tableView.indexPathForRow(at: pinchLocation)
            self.pinchedIndexPath = newPinchedIndexPath
            
            let sectionInfo: SectionInfo = self.sectionInfoArray[(newPinchedIndexPath! as NSIndexPath).section] as! SectionInfo
            self.initialPinchHeight = sectionInfo.objectInRowHeightsAtIndex((newPinchedIndexPath! as NSIndexPath).row) as! CGFloat
            NSLog("pinch Gesture began")
            // 也可以设置为 initialPinchHeight = uniformRowHeight
            
            self.updateForPinchScale(pinchRecognizer.scale, indexPath: newPinchedIndexPath!)
        }else {
            if pinchRecognizer.state == UIGestureRecognizerState.changed {
                self.updateForPinchScale(pinchRecognizer.scale, indexPath: self.pinchedIndexPath)
            }else if pinchRecognizer.state == UIGestureRecognizerState.cancelled || pinchRecognizer.state == UIGestureRecognizerState.ended {
                self.pinchedIndexPath = nil
            }
        }
    }
    
    func updateForPinchScale(_ scale: CGFloat, indexPath:IndexPath?) {
        
        let section:NSInteger = (indexPath! as NSIndexPath).section
        let row:NSInteger = (indexPath! as NSIndexPath).row
        let found:NSInteger = NSNotFound
        if  (section != found) && (row != found) && indexPath != nil {
            
            var newHeight:CGFloat!
            if self.initialPinchHeight > CGFloat(DefaultRowHeight) {
                newHeight = round(self.initialPinchHeight)
            }else {
                newHeight = round(CGFloat(DefaultRowHeight))
            }
            
            let sectionInfo: SectionInfo = self.sectionInfoArray[(indexPath! as NSIndexPath).section] as! SectionInfo
            sectionInfo.replaceObjectInRowHeightsAtIndex((indexPath! as NSIndexPath).row, withObject: (newHeight as AnyObject))
            // 也可以设置为 uniformRowHeight = newHeight
            
            // 在单元格高度改变时关闭动画， 不然的话就会有迟滞的现象
            
            let animationsEnabled: Bool = UIView.areAnimationsEnabled
            UIView.setAnimationsEnabled(false)
            self.tableView.beginUpdates()
            self.tableView.endUpdates()
            UIView.setAnimationsEnabled(animationsEnabled)
        }
    }
    
    // ________________________________________________________________________
    // 处理长按手势
    
    /*func handleLongPress(longPressRecognizer: UILongPressGestureRecognizer) {
        
        // 对于长按手势来说，唯一的状态是Began
        // 当长按手势被识别后，将会找寻按压点的单元格的索引路径
        // 如果按压位置存在一个单元格，那么就会创建一个菜单并展示它
        
        if longPressRecognizer.state == UIGestureRecognizerState.Began {
            
            let pressedIndexPath = self.tableView.indexPathForRowAtPoint(longPressRecognizer.locationInView(self.tableView))
            
            if pressedIndexPath != nil && pressedIndexPath?.row != NSNotFound && pressedIndexPath?.section != NSNotFound {
                
                self.becomeFirstResponder()
                let title = NSBundle.mainBundle().localizedStringForKey("邮件", value: "", table: nil)
                let menuItem: EmailMenuItem = EmailMenuItem(title: title, action: "emailMenuButtonPressed:")
                menuItem.indexPath = pressedIndexPath
                
                let menuController = UIMenuController.sharedMenuController()
                menuController.menuItems = [menuItem]
                
                var cellRect = self.tableView.rectForRowAtIndexPath(pressedIndexPath!)
                // 略微减少对象的长宽高（不要让其在单元格上方显示得太高）
                cellRect.origin.y = cellRect.origin.y + 40.0
                menuController.setTargetRect(cellRect, inView: self.tableView)
                menuController.setMenuVisible(true, animated: true)
            }
        }
    }*/
    
    /*func emailMenuButtonPressed(menuController: UIMenuController) {
        
        let menuItem: EmailMenuItem = UIMenuController.sharedMenuController().menuItems![0] as! EmailMenuItem
        if menuItem.indexPath != nil {
            self.resignFirstResponder()
            //self.sendEmailForEntryAtIndexPath(menuItem.indexPath)
        }
    }*/
    
    /*func sendEmailForEntryAtIndexPath(indexPath: NSIndexPath) {
        
        let play: Play = self.plays[indexPath.section] as! Play
        let quotation: Quotation = play.quotations[indexPath.row] as! Quotation
        
        // 在实际使用中，可以调用邮件的API来实现真正的发送邮件
        print("用以下语录发送邮件: \(quotation.quotation)")
    }*/
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        
        self.dismiss(animated: true, completion: nil)
        if result.rawValue == MFMailComposeResult.failed.rawValue {
            // 在实际使用中，显示一个合适的警告框来提示用户
            print("邮件发送失败,错误信息: \(error)")
        }
    }

    func classifyMutableArrayOrders(_ tOrder:Order)
    {
        var keyvalue:String = ""
        var groupna:String = ""
        switch dataSort {
        case "訂單客戶":
            keyvalue = tOrder.OrderCustomerId
            groupna = tOrder.OrderCustomer
        case "訂單日期":
            keyvalue = tOrder.OrderDate
            groupna = tOrder.OrderDate
        case "出貨狀態":
            if tOrder.OrderStatus == "0"
            {
                keyvalue = "0"
                //groupna = "已出貨完畢"
            }
            else
            {
                keyvalue = "1"
                //groupna = "未出貨完畢"
            }
        case "立帳狀態":
            if tOrder.OrderTwdArAmount != 0
            {
                if tOrder.OrderOverDue == "true"
                {
                    keyvalue = "2"   //已逾期
                }
                else
                {
                    keyvalue = "0"   //已立帳
                }
            }
            else
            {
                keyvalue = "1"   //未立帳
            }
        default:
            keyvalue = ""
        }
        
        if ordersClassify.contains(keyvalue)
        {
            let index = ordersClassify.index(where: {$0 == keyvalue})! as Int
            ordersArray[index].append(tOrder)
            
            //((playe![index] as! GroupedOrder).OrderArray as! NSMutableArray).addObject(tOrder)
            //let go : GroupedOrder = playe![index] as! GroupedOrder
            //go.OrderArray.addObject(tOrder)
            
            ordersCollection[index].OrderArray.add(tOrder)
            ordersCollection[index].OrderAmount = ordersCollection[index].OrderAmount + tOrder.OrderTwdAmount
            ordersCollection[index].OrderArAmount = ordersCollection[index].OrderArAmount + tOrder.OrderTwdArAmount
            
            //2016/08/19 新增訂單總金額顯示
            //ordersTotalAmount[index] = ordersTotalAmount[index] + tOrder.OrderTwdAmount
        }
        else
        {
            let grouporders: GroupedOrder! = GroupedOrder()
            grouporders.GroupedName = groupna      //分群名稱
            grouporders.OrderAmount = tOrder.OrderTwdAmount
            grouporders.OrderArAmount = tOrder.OrderTwdArAmount
            
            let orders = NSMutableArray()
            orders.add(tOrder)
            
            grouporders.OrderArray = orders
            ordersCollection.append(grouporders)
            
            // item not found
            var torderArray = [Order]()
            torderArray.append(tOrder)
            ordersArray.append(torderArray)
            
            ordersClassify.append(keyvalue)
            
            //2016/08/19 新增訂單總金額顯示
            //ordersTotalAmount.append(tOrder.OrderTwdAmount)
        }
    }
    
    func sortOrderCollection()
    {
        ordersCollection = ordersCollection.sorted(by: { $0.OrderAmount > $1.OrderAmount })
        //ordersCollection = ordersCollection.sortedArray(using: [NSSortDescriptor(key: "OrderAmount", ascending: false)])
        //ordersCollection = ordersCollection.sort() { $0.OrderAmount > $1.OrderAmount }
    }

    func createSectionInfo()
    {
        //对于每个场次来说，需要为每个单元格设立一个一致的、包含默认高度的SectionInfo对象。
        let infoArray = NSMutableArray()
        
        for play in self.ordersCollection {
            let dic = play.OrderArray
            let sectionInfo = SectionInfo()
            //2016/09/22
            //sectionInfo.grouporders = play as! GroupedOrder
            sectionInfo.rowCount = dic.count
            sectionInfo.open = false
            
            let defaultRowHeight = DefaultRowHeight
            
            //2016/09/22
            //let countOfQuotations = sectionInfo.grouporders.OrderArray.count
            let countOfQuotations:Int = sectionInfo.rowCount
            
            for i in (0 ..< countOfQuotations)
            {
                sectionInfo.insertObject(defaultRowHeight as AnyObject, inRowHeightsAtIndex: i)
            }
            
            infoArray.add(sectionInfo)
        }
        
        self.sectionInfoArray  = infoArray

    }
}

//Activity Indicator
//http://stackoverflow.com/questions/28785715/how-to-display-an-activity-indicator-with-text-on-ios-8-with-swift
