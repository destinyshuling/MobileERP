//
//  Order.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/6/2.
//  Copyright © 2016年 onto. All rights reserved.
//

import Foundation

class Order {
    //訂單日期
    var OrderDate = ""
    //訂單編號
    var OrderId = ""
    //訂單客戶代碼
    var OrderCustomerId = ""
    //訂單客戶
    var OrderCustomer = ""
    //訂單幣別
    var OrderCurrency = ""
    //訂單總金額
    var OrderAmount = 0.0
    //訂單銷售部門
    var OrderDepart = ""
    //訂單狀態
    var OrderStatus = ""
    //2016/08/19 訂單總金額（台幣）
    var OrderTwdAmount : Int = 0
    //2016/10/01 立帳總金額（台幣）
    var OrderTwdArAmount : Int = 0
    //2016/10/01 該AR是否逾期
    var OrderOverDue = ""
    
    init(orderDate:String, orderId:String, orderCustomerId:String, orderCustomer:String, orderCurrency:String, orderAmount:Double, orderDepart:String, orderStatus:String, orderTwdAmount:Int, orderTwdArAmount:Int, orderOverDue:String) {
        
        self.OrderDate = orderDate
        self.OrderId = orderId
        self.OrderCustomerId = orderCustomerId
        self.OrderCustomer = orderCustomer
        self.OrderCurrency = orderCurrency
        self.OrderAmount = orderAmount
        self.OrderDepart = orderDepart
        self.OrderStatus = orderStatus
        self.OrderTwdAmount = orderTwdAmount
        self.OrderTwdArAmount = orderTwdArAmount
        self.OrderOverDue = orderOverDue
    }
}
