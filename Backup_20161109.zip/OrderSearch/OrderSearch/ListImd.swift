//
//  ListImd.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/8/16.
//  Copyright © 2016年 onto. All rights reserved.
//

import Foundation
import CoreData

//法人對應倉庫資料
class ListImd:NSManagedObject
{
    //法人
    @NSManaged var src:String
    //倉庫代號
    @NSManaged var imd01:String
    //倉庫名
    @NSManaged var imd02:String
}