//
//  StockDetailTableViewCell.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/8/18.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit

class StockDetailTableViewCell: UITableViewCell {

    //品名
    //@IBOutlet var ima02:UILabel!
    //分群碼
    //@IBOutlet var ima06:UILabel!
    //料號
    //@IBOutlet var img01:UILabel!
    //倉庫
    @IBOutlet var img02:UILabel!
    //倉庫名稱
    @IBOutlet var img02name:UILabel!
    //庫存單位
    @IBOutlet var img09:UILabel!
    //數量
    @IBOutlet var img10:UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
