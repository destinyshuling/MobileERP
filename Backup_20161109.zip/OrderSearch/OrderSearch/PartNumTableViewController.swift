//
//  PartNumTableViewController.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/9/8.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit
import CoreData

protocol PartNumControllerDelegate
{
    func returnValue(value:String)
}

class PartNumTableViewController: UITableViewController, NSFetchedResultsControllerDelegate, UISearchResultsUpdating, UISearchBarDelegate {

    var searchController:UISearchController!
    
    var imgArray = [String]()  //料號
    var delegate:PartNumControllerDelegate!
    var onDataAvailable : ((_ data: String) -> ())?
    var selectedPartNum:String = ""
    
    var tableViewHeader:UIView!
    var headerAmount:UILabel!
    
    //儲存搜尋完的訂單資料
    var searchPartNum = [String]()
    
    func sendData(data: String) {
        // Whenever you want to send data back to viewController1, check
        // if the closure is implemented and then call it if it is
        self.onDataAvailable?(data)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //顯示搜尋欄
        searchController = UISearchController(searchResultsController: nil)
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "料號"
        searchController.searchBar.delegate = self
        
        tableViewHeader = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 80))
        tableViewHeader.backgroundColor = UIColor(red: 242.0/255.0, green: 220.0/255.0, blue: 219.0/255.0, alpha: 1.0)
        tableViewHeader.addSubview(searchController.searchBar)
        
        headerAmount = UILabel(frame: CGRect(x: 0, y: 43, width: tableView.frame.width, height: 40))
        headerAmount.font = headerAmount.font.withSize(18)
        headerAmount.text = "已選料號："
        headerAmount.textColor = UIColor(red: 196.0/255.0, green: 1.0/255.0, blue: 5.0/255.0, alpha: 1.0)
        headerAmount.textAlignment = .center;
        tableViewHeader.addSubview(headerAmount)
        
        self.tableView.tableHeaderView = tableViewHeader
        //self.tableView.tableHeaderView = searchController.searchBar
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        /*if searchController.isActive
        {
            return 1
        }
        else
        {
            return 2
        }*/
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if searchController.isActive
        {
            return searchPartNum.count
        }
        else
        {
            if section == 0
            {
                return imgArray.count
            }
            else
            {
                return 1
            }
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if searchController.isActive
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "PartNumCell", for: indexPath) as! PartNumTableViewCell
            cell.partNum.text = searchPartNum[indexPath.row]
            return cell
        }
        else
        {
            if (indexPath as NSIndexPath).section == 0
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "PartNumCell", for: indexPath) as! PartNumTableViewCell
                
                // Configure the cell...
                //cell.partNum.text = "FCTX0011-01"
                cell.partNum.text = imgArray[indexPath.row]
                return cell
            }
            else
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "PartNumBtn", for: indexPath)
                return cell
            }
        }
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        //Choose your custom row height
        return 50.0
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if searchController.isActive
        {
            selectedPartNum = searchPartNum[indexPath.row]
        }
        else
        {
            selectedPartNum = imgArray[indexPath.row]
        }
        headerAmount.text = "已選料號：\(selectedPartNum)"
    }
    
    //Search Bar 過濾資料
    func filterContentForSearchText(_ searchText: String) -> [String]
    {
        searchPartNum = imgArray.filter({ (partnum:String) -> Bool in
            let nameMatch = partnum.range(of: searchText, options: NSString.CompareOptions.caseInsensitive)
            return nameMatch != nil
        })
        return searchPartNum
    }
    
    func updateSearchResults(for searchController: UISearchController){
        if let searchText = searchController.searchBar.text {
            searchPartNum = filterContentForSearchText(searchText)
            tableView.reloadData()
        }
    }

    @IBAction func dismissBtn(sender: UIButton) {
        //delegate.returnValue(value: "FCTX")
        
        //回傳已選取的料號
        sendData(data:selectedPartNum)
        dismiss(animated: true, completion: nil)
    }
}
