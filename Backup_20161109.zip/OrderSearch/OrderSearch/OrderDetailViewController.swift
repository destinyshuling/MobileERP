//
//  OrderDetailViewController.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/6/2.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit

class OrderDetailViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UIPopoverPresentationControllerDelegate {

    @IBOutlet var orderId:UILabel!
    @IBOutlet var orderDate:UILabel!
    @IBOutlet var orderAmount:UILabel!
    @IBOutlet var orderDetailView:UITableView!
    @IBOutlet var segmentedControl: UISegmentedControl!
    
    var jsonResult = JsonParser()
    var alertObject = ShowAlert()
    weak var activityIndicatorView: UIActivityIndicatorView!
    var activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .whiteLarge)
    
    var order:Order!
    var orderDetails = [OrderDetail]()
    var orderArDetails = [OrderArDetail]()
    
    var serviceToken:String = ""
    //var errorObject = [ErrorMsg]()
    var errorObject: Dictionary<String, AnyObject> = [:]
    //let d2 : [String:String] = [:]
    var internetReachability:Reachability!; //網路狀態監控
    
    var segIndex:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //顯示等候視窗
        view.addSubview(activityIndicator)
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        activityIndicator.color = UIColor.red
        activityIndicator.hidesWhenStopped = true
        let horizontalConstraint = NSLayoutConstraint(item: activityIndicator, attribute: NSLayoutAttribute.centerX, relatedBy: NSLayoutRelation.equal, toItem: view, attribute: NSLayoutAttribute.centerX, multiplier: 1, constant: 0)
        view.addConstraint(horizontalConstraint)
        
        let verticalConstraint = NSLayoutConstraint(item: activityIndicator, attribute: NSLayoutAttribute.centerY, relatedBy: NSLayoutRelation.equal, toItem: view, attribute: NSLayoutAttribute.centerY, multiplier: 1, constant: 0)
        view.addConstraint(verticalConstraint)
        
        activityIndicator.startAnimating()
        activityIndicator.isHidden = false
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        title = "訂單明細"
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        //先檢查網路連線
        let networksStatus: NetworkStatus = self.internetReachability.currentReachabilityStatus()
        if networksStatus == NotReachable {
            let alertController = alertObject.ShowAlert("Error", ContentString:"未偵測到網路連線，無法查詢資料！", ActionString:"OK")
            self.present(alertController, animated: true, completion: nil)
        }
        else
        {
            var service = "http://103.227.33.247/F1SV/json/listOrderDetail.json?orderNumber=" + order.OrderId
            let (succeed, errorMsg) = postJsonUseByOrderQuery(service, atoken: serviceToken, flag: 1)
            if (!succeed)
            {
                let alertController = alertObject.ShowAlert("Json Error", ContentString:errorMsg, ActionString:"OK")
                self.present(alertController, animated: true, completion: nil)
            }
            else
            {
                service = "http://103.227.33.247/F1SV/json/listOrderArDetail.json?orderNumber=" + order.OrderId
                let (succeed, errorMsg) = postJsonUseByOrderQuery(service, atoken: serviceToken, flag: 2)
                if (!succeed)
                {
                    let alertController = alertObject.ShowAlert("Json Error", ContentString:errorMsg, ActionString:"OK")
                    self.present(alertController, animated: true, completion: nil)
                }
            }
            self.orderDetailView.reloadData()
        }
        activityIndicator.stopAnimating()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if section == 0
        {
            return 7
        }
        else
        {
            var count:Int = 0
            switch segIndex {
            case 0:
                count = orderDetails.count
            case 1:
                count = orderArDetails.count
            default:
                break
            }
            return count
        }
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String?
    {
        if section == 0
        {
            return order.OrderId
        }
        else
        {
            return "單身"
        }
    }
    
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int)
    {
        var headerTitle:String = ""
        if section == 0
        {
            headerTitle = order.OrderId
        }
        else
        {
            headerTitle = "單身"
        }
        
        let title = UILabel()
        title.font = UIFont(name: headerTitle, size: 30)
        title.textColor = UIColor.black
        
        let header = view as! UITableViewHeaderFooterView
        header.textLabel?.font=title.font
        header.textLabel?.textColor=title.textColor
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50.0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if (indexPath as NSIndexPath).section == 0
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "OrderDetailHeaderCell", for: indexPath) as! OrderDetailHeaderTableViewCell
            switch (indexPath as NSIndexPath).row {
            case 0:
                cell.title.text = "訂單日期"
                cell.content.text = order.OrderDate
            case 1:
                cell.title.text = "客戶代號"
                cell.content.text = order.OrderCustomerId
            case 2:
                cell.title.text = "客戶簡稱"
                cell.content.text = order.OrderCustomer
            case 3:
                cell.title.text = "訂單幣別"
                cell.content.text = "\(order.OrderCurrency)"
            case 4:
                cell.title.text = "訂單金額"
                cell.content.text = order.OrderCurrency + " $ " + String.stringSeparsted(number: order.OrderAmount)
            case 5:
                cell.title.text = "台幣總額"
                cell.content.text = "NTD $ " + String.stringSeparsted(number: Double(order.OrderTwdAmount))
            case 6:
                cell.title.text = "立帳金額"
                cell.content.text = "NTD $ " + String.stringSeparsted(number: Double(order.OrderTwdArAmount))
            default:
                cell.title.text = ""
                cell.content.text = ""
            }
            return cell
        }
        else
        {
            // Configure the cell...
            if segIndex == 0
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "OrderDetailCell", for: indexPath) as! OrderDetailTableViewCell
                let unitprice = Double(orderDetails[(indexPath as NSIndexPath).row].unitprice)
                cell.item.text = orderDetails[(indexPath as NSIndexPath).row].item
                cell.partnumber.text = orderDetails[(indexPath as NSIndexPath).row].partnumber
                cell.desc.text = orderDetails[(indexPath as NSIndexPath).row].description
                cell.salesunit.text = orderDetails[(indexPath as NSIndexPath).row].salesunit
                cell.qty.text = orderDetails[(indexPath as NSIndexPath).row].qty
                cell.unitprice.text = String.stringSeparsted(number: unitprice!)
                cell.paidqty.text = orderDetails[(indexPath as NSIndexPath).row].paidqty
                cell.unpaidqty.text = orderDetails[(indexPath as NSIndexPath).row].unpaidqty
                return cell
            }
            else// if segIndex == 1
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "OrderArDetailCell", for: indexPath) as! OrderArDetailTableViewCell
                let unitprice = Double(orderArDetails[(indexPath as NSIndexPath).row].unitprice)
                let aramount = Double(orderArDetails[(indexPath as NSIndexPath).row].twdamount)
                cell.index.text = String((indexPath as NSIndexPath).row + 1)
                cell.partnumber.text = orderArDetails[(indexPath as NSIndexPath).row].partnumber
                cell.desc.text = orderArDetails[(indexPath as NSIndexPath).row].description
                cell.salesunit.text = orderArDetails[(indexPath as NSIndexPath).row].salesunit
                cell.qty.text = orderArDetails[(indexPath as NSIndexPath).row].qty
                cell.unitprice.text = String.stringSeparsted(number: unitprice)
                cell.twdAmount.text = "NTD $ " + String.stringSeparsted(number: aramount)
                //逾期以紅字顯示
                if orderArDetails[(indexPath as NSIndexPath).row].overdue == "true"
                {
                    cell.twdAmount.textColor = UIColor.red
                }
                else
                {
                    cell.twdAmount.textColor = UIColor.darkGray
                }
                return cell
            }
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if (indexPath as NSIndexPath).section == 1 && segIndex == 0
        {
            let cell:UITableViewCell? = tableView.cellForRow(at: indexPath)
            let selectedCellSourceView = tableView.cellForRow(at: indexPath)
            let selectedCellSourceRect = cell!.bounds
            
            let popover = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "popover") as! OrderDetailPopoverViewController
            
            popover.modalPresentationStyle = UIModalPresentationStyle.popover
            popover.popoverPresentationController?.backgroundColor = UIColor(red:250.0/255.0, green:220.0/255.0, blue: 220.0/255.0, alpha: 0.7)
            popover.popoverPresentationController?.delegate = self
            popover.popoverPresentationController?.sourceView = selectedCellSourceView
            popover.popoverPresentationController?.sourceRect = selectedCellSourceRect
            popover.preferredContentSize = CGSize(width: 280, height: 200)
            
            //傳遞data
            let unitprice = Double(orderDetails[(indexPath as NSIndexPath).row].unitprice)
            let item = orderDetails[(indexPath as NSIndexPath).row].item
            
            popover.strItem = item
            popover.strPartnumber = orderDetails[(indexPath as NSIndexPath).row].partnumber
            popover.strDesc = orderDetails[(indexPath as NSIndexPath).row].description
            popover.strQty = orderDetails[(indexPath as NSIndexPath).row].qty
            popover.strUnitprice = String.stringSeparsted(number: unitprice!)
            popover.strSalesunit = orderDetails[(indexPath as NSIndexPath).row].salesunit
            popover.strPaidqty = orderDetails[(indexPath as NSIndexPath).row].paidqty
            popover.strUnpaidqty = orderDetails[(indexPath as NSIndexPath).row].unpaidqty
            
            self.present(popover, animated: true, completion: nil)
            
            /*let VC = storyboard?.instantiateViewControllerWithIdentifier("popover") as! OrderDetailPopoverViewController
             VC.preferredContentSize = CGSizeMake(200, 200)
             let navController = UINavigationController(rootViewController: VC)
             navController.modalPresentationStyle = UIModalPresentationStyle.Popover
             let popover = navController.popoverPresentationController
             popover?.delegate = self
             
             popover?.sourceView = self.view
             popover?.sourceRect = CGRectMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds),0,0)
             popover?.permittedArrowDirections = UIPopoverArrowDirection()
             
             self.presentViewController(navController, animated: true, completion: nil)*/
        }
    }
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
     if editingStyle == .Delete {
     // Delete the row from the data source
     tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
     } else if editingStyle == .Insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        if (indexPath as NSIndexPath).section == 0
        {
            return 40
        }
        else
        {
            return 80
        }
    }
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        /*if segue.identifier == "showPopover"
        {
            /*if let indexPath = tableView.indexPathForSelectedRow{
                let destinationController = segue.destinationViewController as! OrderDetailViewController
                //將客戶資料傳遞到下一個頁面
                if searchController.active
                {
                    destinationController.order = searchOrders[indexPath.row]
                }
                else
                {
                    destinationController.order = ordersArray[indexPath.section][indexPath.row]
                }
                destinationController.serviceToken = serviceToken
                destinationController.errorObject = errorObject
                destinationController.internetReachability = internetReachability
            }*/
            let vc = segue.destinationViewController
            vc.preferredContentSize = CGSizeMake(200, 200)
            let controller = vc.popoverPresentationController
            if controller != nil
            {
                controller?.delegate = self
            }
        }*/
    }
    
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        return .none
    }
    
    //設定頁面是否可以旋轉
    override var shouldAutorotate : Bool {
        return true
    }
    
    override var supportedInterfaceOrientations : UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.allButUpsideDown
    }
    
    @IBAction func indexChanged(sender:UISegmentedControl)
    {
        /*switch segmentedControl.selectedSegmentIndex
        {
        case 0:
            //textLabel.text = "First selected";
        case 1:
            //textLabel.text = "Second Segment selected";
        default:
            break;
        }*/
        segIndex = segmentedControl.selectedSegmentIndex
        if segIndex == 1 && orderArDetails.count == 0
        {
            let alertController = alertObject.ShowAlert("溫馨提醒", ContentString:"此單尚未立帳！", ActionString:"OK")
            self.present(alertController, animated: true, completion: nil)
        }
        orderDetailView.reloadData()
    }
    
    //查詢訂單單頭ＪＳＯＮ
    func postJsonUseByOrderQuery(_ serviceLink:String, atoken:String, flag:Int) -> (Bool, String)
    {
        var succeed:Bool = false
        var errorMag:String = ""
        let request = NSMutableURLRequest(url: URL(string: serviceLink)!)
        request.httpMethod = "GET"
        //GET要塞入的Header
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue(atoken, forHTTPHeaderField: "atoken")
        
        var response: URLResponse?
        do {
            let resData = try NSURLConnection.sendSynchronousRequest(request as URLRequest, returning: &response)
            
            //處理回傳的Body -> Json 格式
            //let myData = NSString(data:resData, encoding: NSUTF8StringEncoding) as! String
            
            if resData.count > 0
            {
                var json: Array<AnyObject>  //不知道為什麼一定要放在這一行，json才不會是nil.....
                do {
                    json = try JSONSerialization.jsonObject(with: resData, options: .mutableLeaves) as! Array
                    //解析body
                    switch flag {
                    case 1:
                        for jsonpattern in json{
                            let tOrderdetail:OrderDetail = OrderDetail(item: jsonpattern["oeb03"] as! String, partnumber: jsonpattern["oeb04"] as! String, description: jsonpattern["oeb06"] as! String, salesunit: jsonpattern["oeb05"] as! String, qty: jsonpattern["oeb12"] as! String, unitprice: jsonpattern["oeb13"] as! String, paidqty: jsonpattern["oeb24"] as! String, unpaidqty: jsonpattern["oeb23b"] as! String)
                            orderDetails.append(tOrderdetail)
                        }
                    case 2:
                        for jsonpattern in json{
                            let tOrderArdetail:OrderArDetail = OrderArDetail(partnumber: jsonpattern["omb04"] as! String, description: jsonpattern["omb06"] as! String, salesunit: jsonpattern["omb05"] as! String, qty: jsonpattern["omb12"] as! String, unitprice: jsonpattern["omb13"] as! Double, twdamount: jsonpattern["omb14ntd"] as! Int, overdue: jsonpattern["overduear"] as! String)
                            orderArDetails.append(tOrderArdetail)
                        }
                    default:
                        break
                    }
                    succeed = true
                    
                } catch let dataError {
                    // Did the JSONObjectWithData constructor return an error? If so, log the error to the console
                    print(dataError)
                    let jsonStr = NSString(data: resData, encoding: String.Encoding.utf8.rawValue)
                    print("Error could not parse JSON. \r\n '\(jsonStr)'")
                    errorMag = "Error could not parse JSON. \r\n '\(jsonStr)'"
                    succeed = false
                }
            }
            else
            {
                succeed = true
            }
            
            //處理回傳的Header -> 包含資料總筆數
            if let response = response as? HTTPURLResponse {
                if response.statusCode == 200 {
                    let resultCode = response.allHeaderFields["statusCd"] as! String
                    if resultCode != "5000"  //"執行成功"
                    {
                        var errorMsg = ""
                        if resultCode == "5001" //timeout
                        {
                            errorMag = "超過３０分鐘未操作，已自動登出，請重新登入！"
                            let alertController = alertObject.ShowAlert("溫馨提醒", ContentString:errorMag, ActionString:"OK")
                            self.present(alertController, animated: true, completion: nil)
                        }
                        else
                        {
                            errorMsg = ReadErrorMsg(resultCode)
                            let alertController = alertObject.ShowAlert("Alert", ContentString:"Server回傳資料有誤！[\(resultCode)]\r\n\(errorMsg)", ActionString:"OK")
                            self.present(alertController, animated: true, completion: nil)
                        }
                    }
                }
            }
        } catch {
            print("Send request error.\r\n '\(error)'")
            errorMag = "Send request error.\r\n '\(error)'"
            succeed = false
        }
        
        return (succeed, errorMag)
    }
    
    func ReadErrorMsg(_ errorCode:String) -> String
    {
        return errorObject[errorCode] as! String
    }
}
