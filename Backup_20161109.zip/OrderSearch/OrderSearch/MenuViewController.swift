//
//  MenuViewController.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/8/9.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit

class MenuViewController: UIViewController {
    @IBOutlet var mantisBtn:UIButton!
    
    //前一頁傳遞過來的資料
    var loginAccount:String = ""
    var loginName:String = ""
    var loginDepartment:String = ""
    var loginAuthorization: String = ""
    var loginAuthorizationArr: [String] = []
    var serviceToken:String = ""
    //var errorObject = [ErrorMsg]()
    var errorObject: Dictionary<String, AnyObject> = [:]
    var internetReachability:Reachability!; //網路狀態監控
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //隱藏測試用mantis button
        self.mantisBtn.isHidden = true
        
        // Do any additional setup after loading the view.
        title = "行動ERP"
        let btnName = UIButton()
        btnName.setImage(UIImage(named: "logout-2"), for: UIControlState())
        btnName.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        btnName.addTarget(self, action: #selector(SearchOptionViewController.LogoutBtnClick(_:)), for: .touchUpInside)
        
        //.... Set Right/Left Bar Button item
        let rightBarButton = UIBarButtonItem()
        rightBarButton.customView = btnName
        self.navigationItem.rightBarButtonItem = rightBarButton
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        //直接連結到訂單查詢
        //self.performSegueWithIdentifier("SearchOrderSeque", sender: self)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        navigationController?.hidesBarsOnSwipe = false
        navigationController?.setNavigationBarHidden(false, animated: true)
        
        //取得螢幕大小
//        let screenSize: CGRect = UIScreen.main.bounds
//        let screenWidth = screenSize.width
//        let screenHeight = screenSize.height
//        print("Screen size: Height: \(screenHeight), Width: \(screenWidth)")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //設定頁面是否可以旋轉
    override var shouldAutorotate : Bool {
        return false
    }
    
    override var supportedInterfaceOrientations : UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    
    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if segue.identifier == "SearchOrderSeque"
        {
            let destinationController = segue.destination as! SearchOptionViewController
            //將資料傳遞到下一個頁面
            destinationController.loginAccount = self.loginAccount
            destinationController.serviceToken = self.serviceToken
            destinationController.loginName = self.loginName
            destinationController.loginDepartment = self.loginDepartment
            destinationController.errorObject = self.errorObject
            destinationController.loginAuthorizationArr = self.loginAuthorizationArr
            destinationController.internetReachability = self.internetReachability
        }
        else if segue.identifier == "SearchStockSeque"
        {
            let destinationController = segue.destination as! StockOptionTableViewController
            //將資料傳遞到下一個頁面
            destinationController.loginAccount = self.loginAccount
            destinationController.serviceToken = self.serviceToken
            destinationController.loginName = self.loginName
            destinationController.loginDepartment = self.loginDepartment
            destinationController.errorObject = self.errorObject
            destinationController.loginAuthorizationArr = self.loginAuthorizationArr
            destinationController.internetReachability = self.internetReachability
        }
    }

    @IBAction func OrderBtnClick(_ sender:AnyObject)
    {
        self.performSegue(withIdentifier: "SearchOrderSeque", sender: self)
    }
    
    @IBAction func StockBtnClick(_ sender:AnyObject)
    {
        self.performSegue(withIdentifier: "SearchStockSeque", sender: self)
        /*if self.loginAccount == "shu-ling.lin"
        {
            self.performSegue(withIdentifier: "SearchStockSeque", sender: self)
        }
        else
        {
            let alertController = UIAlertController(title: "溫馨提醒", message:
                "敬請期待'庫存查詢'！", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default,handler: nil))
            
            self.present(alertController, animated: true, completion: nil)
        }*/
    }
    
    @IBAction func LogoutBtnClick(_ sender: UIBarButtonItem)
    {
        let alertController = UIAlertController(title: "溫馨提醒", message:
            "是否確定要登出行動ERP ？", preferredStyle: UIAlertControllerStyle.alert)
        
        alertController.addAction(UIAlertAction(title: "登出", style: .default) { value in
            //print("tapped default button")
            self.performSegue(withIdentifier: "LogoutSegue", sender: self)
        })
        alertController.addAction(UIAlertAction(title: "取消", style: .cancel, handler: nil))
        self.present(alertController, animated: true, completion: nil)
        
    }
}
