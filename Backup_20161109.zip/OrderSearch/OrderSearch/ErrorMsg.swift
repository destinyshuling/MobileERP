//
//  ErrorMsg.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/7/4.
//  Copyright © 2016年 onto. All rights reserved.
//

import Foundation

class ErrorMsg {
    //錯誤代碼
    var ErrorCode = ""
    //錯誤訊息
    var ErrorNote = ""
    
    init(errorCode:String, errorNote:String)
    {
        self.ErrorCode = errorCode
        self.ErrorNote = errorNote
    }
}