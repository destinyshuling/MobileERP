//
//  OrderDetail.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/6/2.
//  Copyright © 2016年 onto. All rights reserved.
//

import Foundation

class OrderDetail {
    //項目
    var item = ""
    //料號
    var partnumber = ""
    //料件描述
    var description = ""
    //銷售單位
    var salesunit = ""
    //數量
    var qty = ""
    //單價
    var unitprice = ""
    //已交數量
    var paidqty = ""
    //未交數量
    var unpaidqty = ""
    
    init(item:String, partnumber:String, description:String, salesunit:String, qty:String, unitprice:String, paidqty:String, unpaidqty:String)
    {
        self.item = item
        self.partnumber = partnumber
        self.description = description
        self.salesunit = salesunit
        self.qty = qty
        self.unitprice = unitprice
        self.paidqty = paidqty
        self.unpaidqty = unpaidqty
    }
}