//
//  StockDetailViewController.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/8/18.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit
import CoreData

class StockDetailViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet var stockDetailView:UITableView!
    
    var groupStock:GroupedStock!
    var serviceToken:String!
    var errorObject: Dictionary<String, AnyObject> = [:]
    var internetReachability:Reachability!; //網路狀態監控
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "庫存明細"

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if section == 0
        {
            return 5
        }
        else
        {
            return groupStock.stockList.count
        }
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String?
    {
        if section == 0
        {
            return groupStock.stockImg01
        }
        else
        {
            return "倉庫明細"
        }
    }
    
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int)
    {
        var headerTitle:String = ""
        if section == 0
        {
            headerTitle = groupStock.stockImg01
        }
        else
        {
            headerTitle = "倉庫明細"
        }
        
        let title = UILabel()
        title.font = UIFont(name: headerTitle, size: 30)
        title.textColor = UIColor.black
        
        let header = view as! UITableViewHeaderFooterView
        header.textLabel?.font=title.font
        header.textLabel?.textColor=title.textColor
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50.0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if (indexPath as NSIndexPath).section == 0
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "OrderDetailHeaderCell", for: indexPath) as! OrderDetailHeaderTableViewCell
            let stock = groupStock.stockList[0] as! ListInStockAll
            
            switch (indexPath as NSIndexPath).row {
            case 0:
                cell.title.text = "法人"
                if groupStock.stockSrc == "ZYTW"
                {
                    cell.content.text = "正一台灣"
                }
                else if groupStock.stockSrc == "ZYLH"
                {
                    cell.content.text = "正一龍華"
                }
                else if groupStock.stockSrc == "ZYHEN"
                {
                    cell.content.text = "正一河南"
                }
                
            case 1:
                cell.title.text = "料號"
                cell.content.text = groupStock.stockImg01
            case 2:
                cell.title.text = "品名"
                cell.content.text = stock.ima02
            case 3:
                cell.title.text = "來源碼"
                if stock.ima08 == "P"
                {
                    cell.content.text = stock.ima08 + " 採購料件"
                }
                else if stock.ima08 == "T"
                {
                    cell.content.text = stock.ima08 + " 最後規格料件"
                }
                else if stock.ima08 == "M"
                {
                    cell.content.text = stock.ima08 + " 自製料件"
                }
                else
                {
                    cell.content.text = stock.ima08
                }
            case 4:
                cell.title.text = "分群碼"
                cell.content.text = stock.ima06 + " " + getImzName(stock.ima06)
            default:
                cell.title.text = ""
                cell.content.text = ""
            }
            return cell
        }
        else
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "StockDetailCell", for: indexPath) as! StockDetailTableViewCell
            
            // Configure the cell...
            let stock = groupStock.stockList[(indexPath as NSIndexPath).row] as! ListInStockAll
            cell.img02.text = stock.img02
            
            //倉庫名稱
            cell.img02name.text = getImdName(stock.img02, src: stock.src)
            
            cell.img09.text = stock.img09
            cell.img10.text = stock.img10
            
            return cell
        }
    }
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
     if editingStyle == .Delete {
     // Delete the row from the data source
     tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
     } else if editingStyle == .Insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        if (indexPath as NSIndexPath).section == 0
        {
            return 40
        }
        else
        {
            return 60
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    //取得倉庫名稱
    func getImdName(_ query: String, src: String) -> String
    {
        //使用CoreData取得資料
        var imdName:String = ""
        if let managedObjectContext = (UIApplication.shared.delegate as? AppDelegate)?.managedObjectContext
        {
            //let fetchRequest = NSFetchRequest(entityName: "ListImd")
            let fetchRequest:NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: "ListImd")
            let predicate = NSPredicate(format: "src='\(src)' and imd01='\(query)'")  //"src=\(query)"
            fetchRequest.predicate = predicate
            do{
                let imdClassArray = try managedObjectContext.fetch(fetchRequest) as! [ListImd]
                if imdClassArray.count > 0
                {
                    imdName = imdClassArray[0].imd02
                }
                
            } catch{
                print(error)
            }
        }
        return imdName
    }
    
    //取得分群碼名稱
    func getImzName(_ query: String) -> String
    {
        //使用CoreData取得資料
        var imzName:String = ""
        if let managedObjectContext = (UIApplication.shared.delegate as? AppDelegate)?.managedObjectContext
        {
            let fetchRequest:NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: "ListImz")
            let predicate = NSPredicate(format: "imz01='\(query)'")  //"src=\(query)"
            fetchRequest.predicate = predicate
            do{
                let imzClassArray = try managedObjectContext.fetch(fetchRequest) as! [ListImz]
                if imzClassArray.count > 0
                {
                    imzName = imzClassArray[0].imz02
                }
                
            } catch{
                print(error)
            }
        }
        return imzName
    }
}
