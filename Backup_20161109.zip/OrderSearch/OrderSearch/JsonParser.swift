//
//  JsonParser.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/6/2.
//  Copyright © 2016年 onto. All rights reserved.
//

import Foundation

class JsonParser
{
    //NSURLConnection.sendSynchronousRequest() 在 iOS 9 已經不推薦使用
    func postJsonUseByLogin(_ account:String, pwd:String) -> Bool
    {
        var succeed:Bool=false
        let request = NSMutableURLRequest(url: URL(string: "http://10.58.160.25:8080/F1SV/json/login.json")!)
        request.httpMethod = "POST"
        //POST要塞入的Header
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        //POST要塞入的body
        let params = ["cn" : account, "pwd" : pwd] as Dictionary<String, String>
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: params, options: [])
            
        } catch {
            print(error)
            request.httpBody = nil
        }
        
        var response:URLResponse?
        //var error:NSError?
        do {
            let resData = try NSURLConnection.sendSynchronousRequest(request as URLRequest, returning: &response)
            
            // Parse the data
            let myData = NSString(data:resData, encoding: String.Encoding.utf8.rawValue) as! String
            
            print("Response: \(response)")
            print("myData: \(myData)")
            succeed = true
            let json: NSDictionary?
            do {
                json = try JSONSerialization.jsonObject(with: resData, options: .mutableLeaves) as? NSDictionary
            } catch let dataError {
                // Did the JSONObjectWithData constructor return an error? If so, log the error to the console
                print(dataError)
                let jsonStr = NSString(data: resData, encoding: String.Encoding.utf8.rawValue)
                print("Error could not parse JSON: '\(jsonStr)'")
                // return or throw?
                //self.ShowAlert("Alert", ContentString:"伺服器回傳結果異常，請通知系統管理員！", ActionString:"OK")
                succeed = false
                return succeed
            }
            
            if let parseJSON = json {
                // Okay, the parsedJSON is here, let's get the value for 'success' out of it
                let success = parseJSON["statusMsg"] as? String
                let successCode = parseJSON["statusCd"] as? String
                print("Succes: \(success)")
                if successCode == "0000"{
                    succeed = true
                }else{
                    succeed = false
                }
                //它叫Closures（閉包）不叫function（函式）
                //self.ShowAlert("Message", ContentString:success!, ActionString:"OK")
            }
            else {
                // Woa, okay the json object was nil, something went worng. Maybe the server isn't running?
                let jsonStr = NSString(data: resData, encoding: String.Encoding.utf8.rawValue)
                print("Error could not parse JSON: \(jsonStr)")
                succeed = false
                //self.ShowAlert("Alert", ContentString:"伺服器異常，請通知系統管理員！", ActionString:"OK")
            }
            
        } catch {
            // handle error
            print(error)
            succeed = false
        }
        
        return succeed
    }
    
    func postJsonUseByOrderQuery(_ serviceLink:String, atoken:String) -> (Bool, NSDictionary)
    {
        var succeed:Bool=false
        let request = NSMutableURLRequest(url: URL(string: serviceLink)!)
        request.httpMethod = "GET"
        //GET要塞入的Header
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue(atoken, forHTTPHeaderField: "atoken")
        
        var response: URLResponse?
        let json: NSDictionary? = nil
        do {
            let resData = try NSURLConnection.sendSynchronousRequest(request as URLRequest, returning: &response)
            
            //處理回傳的Body -> Json 格式
            let myData = NSString(data:resData, encoding: String.Encoding.utf8.rawValue) as! String
            let json2: NSDictionary?  //不知道為什麼一定要放在這一行，json才不會是nil.....
            do {
                json2 = try JSONSerialization.jsonObject(with: resData, options: .mutableLeaves) as? NSDictionary
                succeed = true
                return (succeed, json2!)
            } catch let dataError {
                // Did the JSONObjectWithData constructor return an error? If so, log the error to the console
                print(dataError)
                let jsonStr = NSString(data: resData, encoding: String.Encoding.utf8.rawValue)
                print("Error could not parse JSON: '\(jsonStr)'")
                
                succeed = false
            }
            
            //這個測試失敗！！！！！
            //處理回傳的Header -> 包含資料總筆數
//            if let response = response as? NSHTTPURLResponse {
//                if response.statusCode == 200 {
//                    print("Success")
//                }
//                let resultCount = response.allHeaderFields["totalCount"] as! Int
//            }
            
            /*//解析body
            if let parseJSON = json {
                // Okay, the parsedJSON is here, let's get the value for 'success' out of it
                let success = parseJSON["statusMsg"] as? String
                let successCode = parseJSON["statusCd"] as? String
                
                if successCode == "0000" {
                    succeed = true
                }else {
                    succeed = false
                }
                //它叫Closures（閉包）不叫function（函式）
                //self.ShowAlert("Message", ContentString:success!, ActionString:"OK")
            }
            else {
                //json object was nil, something went worng. Maybe the server isn't running?
                let jsonStr = NSString(data: resData, encoding: NSUTF8StringEncoding)
                print("Error could not parse JSON: \(jsonStr)")
                succeed = false
            }*/
            
        } catch {
            print(error)
            succeed = false
        }
        
        return (succeed, json!)
    }
    
    //自訂函式
    //reference : https://blog.smemo.info/59.html
    /*func readjson(webservice:String) -> [[String: AnyObject]]
    {
        //let service = "http://www.onto.tech/swiftapp/webservices/ordernumber.php?ordernumber=" + order.OrderId
        //var apiData2:NSData!=NSData(contentsOfURL: NSURL(string: service)!, options: NSDataReadingOptions.DataReadingMapped, error: nil)
        
        let baseURL = NSURL(string: webservice)
        let apiData2 = NSData(contentsOfURL: baseURL!) //, options: .DataReadingUncached
        
        //let apiData2 = NSData(contentsOfURL: baseURL!, options: nil, error: nil)
        //let result2 = NSString(data: apiData2!, encoding: NSUTF8StringEncoding)
        //var error2:NSError?
        //let jsonObj2:AnyObject?=NSJSONSerialization.JSONObjectWithData(apiData2!, options: NSJSONReadingOptions()); //, error: &error2
        
        
        let object = NSJSONSerialization.JSONObjectWithData(apiData2!, options: .AllowFragments)
        //dictionary is an array of object
        let dictionary = object as? [[String: AnyObject]]
//      if let jsonItem = dictionary as? NSArray{
//          for data in jsonItem
//          {
//              //let tOrderdetail:OrderDetail = OrderDetail(item: data.objectForKey("oeb03") as! String, partnumber: data.objectForKey("oeb04") as! String, description: data.objectForKey("oeb06") as! String, salesunit: data.objectForKey("oeb05") as! String, warehouse: data.objectForKey("oeb902") as! String, qty: data.objectForKey("oeb12") as! String, unitprice: data.objectForKey("oeb13") as! String, amount: data.objectForKey("oeb14") as! String)
//                    
//              //orderDetails.append(tOrderdetail)
//          }
//      }
        return dictionary!
    }
    
//    func jsonFromURL(jsonURL: String) -> Dictionary<String, AnyObject> {
//        var jsonNSURL: NSURL = NSURL(string: jsonURL)
//        let jsonSource: NSData = NSData(contentsOfURL: jsonNSURL)
//        var json = NSJSONSerialization.JSONObjectWithData(jsonSource, options:NSJSONReadingOptions.MutableContainers, error: nil) as Dictionary<String, AnyObject>
//        return json
//    }*/
}

//reference:
//func
//http://ithelp.ithome.com.tw/articles/10158415
//http://www.aidanf.net/learn-swift/functions

