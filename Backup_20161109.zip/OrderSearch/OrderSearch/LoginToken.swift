//
//  LoginToken.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/8/18.
//  Copyright © 2016年 onto. All rights reserved.
//

import Foundation
import CoreData

//登入token
class LoginToken:NSManagedObject
{
    @NSManaged var token:String
}