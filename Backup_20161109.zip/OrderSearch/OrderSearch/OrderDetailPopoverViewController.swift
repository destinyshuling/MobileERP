//
//  OrderDetailPopoverViewController.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/8/25.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit

class OrderDetailPopoverViewController: UIViewController {

    @IBOutlet var item:UILabel!
    @IBOutlet var partnumber:UILabel!
    @IBOutlet var desc:UILabel!
    @IBOutlet var salesunit:UILabel!
    @IBOutlet var qty:UILabel!
    @IBOutlet var unitprice:UILabel!
    @IBOutlet var paidqty:UILabel!
    @IBOutlet var unpaidqty:UILabel!
    
    var strItem:String!
    var strPartnumber:String!
    var strDesc:String!
    var strSalesunit:String!
    var strQty:String!
    var strUnitprice:String!
    var strPaidqty:String!
    var strUnpaidqty:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        item.text = strItem
        partnumber.text = strPartnumber
        desc.text = strDesc
        salesunit.text = strSalesunit
        qty.text = strQty
        unitprice.text = strUnitprice
        paidqty.text = strPaidqty
        unpaidqty.text = strUnpaidqty
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
