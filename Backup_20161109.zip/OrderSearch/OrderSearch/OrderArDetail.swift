//
//  OrderArDetail.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/10/3.
//  Copyright © 2016年 onto. All rights reserved.
//

import Foundation

class OrderArDetail {
    //料號
    var partnumber = ""
    //料件描述
    var description = ""
    //銷售單位
    var salesunit = ""
    //數量
    var qty = ""
    //單價
    var unitprice = 0.0
    //立帳金額（台幣）
    var twdamount = 0
    //立帳逾期否
    var overdue = ""
    
    init(partnumber:String, description:String, salesunit:String, qty:String, unitprice:Double, twdamount:Int, overdue:String)
    {
        self.partnumber = partnumber
        self.description = description
        self.salesunit = salesunit
        self.qty = qty
        self.unitprice = unitprice
        self.twdamount = twdamount
        self.overdue = overdue
    }
}
