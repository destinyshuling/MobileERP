//
//  MantisViewController.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/11/1.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit

class MantisViewController: UIViewController, UIWebViewDelegate {

    @IBOutlet weak var mantisWebView: UIWebView!
    @IBOutlet var activityIndicator: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        //let url = NSURL (string: "https://bt.foxconn.com:5610/BugTracker/")
        let url = NSURL (string: "https://www.baidu.com")
        let requestObj = URLRequest(url: url! as URL)
        mantisWebView.delegate = self
        activityIndicator.hidesWhenStopped = true
        
        mantisWebView.loadRequest(requestObj as URLRequest)
        mantisWebView.scalesPageToFit = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func webViewDidStartLoad(_ webView : UIWebView) {
        //UIApplication.sharedApplication().networkActivityIndicatorVisible = true
        activityIndicator.startAnimating()
        
        
    }
    
    func webViewDidFinishLoad(_ webView : UIWebView) {
        //UIApplication.sharedApplication().networkActivityIndicatorVisible = false
        activityIndicator.stopAnimating()
    }
    
    //#pragma mark - UIWebViewDelegate
    func webView(_ webView: UIWebView, shouldStartLoadWith request: URLRequest, navigationType: UIWebViewNavigationType) -> Bool
    {
//        NSLog("Did start loading: %@ auth:%d",request.URL().absoluteString(),_authenticated)
//        if (!_authenticated)
//        {
//            _authenticated = NO
//            _urlConnection = NSURLConnection.alloc().initWithRequest(_request,delegate:self)
//            _urlConnection.start()
//            return false
//        }
        return true
    }
    
//    func connection(connection: NSURLConnection, didReceiveAuthenticationChallenge challenge: URLAuthenticationChallenge?)
//    {
//        //パスワードを間違えると無限ループするため
//        guard challenge?.proposedCredential == false else {
//            connection.cancel()
//            return
//        }
//        let credential = URLCredential(user: "user", password: "password", persistence: URLCredential.Persistence.forSession)
//        challenge?.sender?.use(credential, for: challenge!)
//    }
//    
//    func URLSession(session: URLSession, didReceiveChallenge challenge: URLAuthenticationChallenge, completionHandler: (URLSession.AuthChallengeDisposition, URLCredential?) -> Void)
//    {
//        completionHandler(URLSession.AuthChallengeDisposition.UseCredential, URLCredential(forTrust: challenge.protectionSpace.serverTrust))
//    }
}


