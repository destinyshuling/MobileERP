//
//  GroupedOrder.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/6/21.
//  Copyright © 2016年 onto. All rights reserved.
//

import Foundation

class GroupedOrder: NSObject {
    var GroupedName: String = ""
    //訂單總額 NTD
    var OrderAmount: Int = 0
    //訂單立帳總額 NTD
    var OrderArAmount: Int = 0
    var OrderArray: NSMutableArray = NSMutableArray()
}

/*class GroupedOrder {
    //群組名稱
    var GroupedName = ""
    //訂單陣列
    var OrderArray = [Order]()
    
    init(groupedName:String, orderArray:[Order])
    {
        self.GroupedName = groupedName
        self.OrderArray = orderArray
    }
}*/
