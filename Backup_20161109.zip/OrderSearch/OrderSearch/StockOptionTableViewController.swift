//
//  StockOptionTableViewController.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/8/12.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit
import CoreData
import CoreActionSheetPicker

class StockOptionTableViewController: UITableViewController {
    
    //picker
    @IBOutlet var srcPicker: UIButton! //法人
    @IBOutlet var imdPicker: UIButton! //倉庫
    @IBOutlet var imzPicker: UIButton! //分群碼
    @IBOutlet var imgPicker: UIButton! //料號
    @IBOutlet var searchBtn: UIButton!
    
    //前一頁傳遞過來的資料
    var loginAccount:String!
    var loginName:String!
    var loginDepartment:String!
    var loginAuthorizationArr:[String] = []
    var serviceToken:String!
    var errorObject:Dictionary<String, AnyObject> = [:]
    var internetReachability:Reachability!; //網路狀態監控
    //儲存庫存查詢結果
    var stockResultArr:[ListInStockAll] = []
    
    //提示訊息
    var alertObject = ShowAlert()
    
    //picker array
    var srcArray = [String]()  //法人
    var imdArray = [String]()  //倉庫
    var imzArray = [String]()  //分群碼
    var imgArray = [String]()  //料號

    //儲存目前picker上的值
    var srcCurrValue:String = ""
    var imdCurrValue:String = ""
    var imzCurrValue:String = ""
    var imgCurrValue:String = ""
    
    //progress bar
    var timer:Timer!
    var displayLink: CADisplayLink?
    var startTime: CFAbsoluteTime?
    let duration = 15.0
    
    var grayView: UIView!
    var blurEffectView: UIVisualEffectView!
    var progressView: UIProgressView!
    
    var circleProgress: KDCircularProgress!
    //等候視窗
    var activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .whiteLarge)
    
    private let progressLayer: CAShapeLayer = CAShapeLayer()
    //CAShapeLayer example
    //http://zappdesigntemplates.com/cashapelayer-to-create-a-custom-progressbar/
    
    func doSomethingWithData(data: String) {
        // Do something with data
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        //顯示進度列
        addProgressView()
        //progressView.progress += 0.1
        
        //顯示等候視窗
        view.addSubview(activityIndicator)
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        activityIndicator.color = UIColor.red
        activityIndicator.hidesWhenStopped = true
        let horizontalConstraint = NSLayoutConstraint(item: activityIndicator, attribute: NSLayoutAttribute.centerX, relatedBy: NSLayoutRelation.equal, toItem: view, attribute: NSLayoutAttribute.centerX, multiplier: 1, constant: 0)
        view.addConstraint(horizontalConstraint)
        
        let verticalConstraint = NSLayoutConstraint(item: activityIndicator, attribute: NSLayoutAttribute.centerY, relatedBy: NSLayoutRelation.equal, toItem: view, attribute: NSLayoutAttribute.centerY, multiplier: 1, constant: 0)
        view.addConstraint(verticalConstraint)
        
        activityIndicator.startAnimating()
        activityIndicator.isHidden = false
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        /*DispatchQueue.main.async {
            self.circleProgress.animate(fromAngle: 0, toAngle: 360, duration: 5) { completed in
                if completed {
                    print("animation stopped, completed")
                } else {
                    print("animation stopped, was interrupted")
                }
            }
        }*/
        
        //判斷登入者token，如果token一致，則不再重新載入資料
        var reloadFlag:Bool = true
        if let managedObjectContext = (UIApplication.shared.delegate as? AppDelegate)?.managedObjectContext
        {
            let fetchRequest:NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: "LoginToken")
            do{
                let loginArray = try managedObjectContext.fetch(fetchRequest) as! [LoginToken]
                if loginArray.count > 0
                {
                    if loginArray[0].token == serviceToken
                    {
                        reloadFlag = false
                    }
                }
            } catch{
                print(error)
            }
        }
        
        if reloadFlag == true
        {
            //先刪除目前login token儲存的所有資料
            DeleteCoreData("LoginToken")
            //儲存login token
            if let managedObjectContext = (UIApplication.shared.delegate as? AppDelegate)?.managedObjectContext
            {
                var ltoken:LoginToken!
                ltoken = NSEntityDescription.insertNewObject(forEntityName: "LoginToken", into: managedObjectContext) as! LoginToken
                ltoken.token = serviceToken
                
                do{
                    try managedObjectContext.save()
                } catch{
                    print(error)
                }
            }
            
            //取得倉庫代碼
            let serviceImd = "http://www.onto.tech/F1SV/json/listImd.json"      //取得倉庫代碼
            let serviceImz = "http://www.onto.tech/F1SV/json/listImz.json"      //取得分群碼
            let serviceStock = "http://www.onto.tech/F1SV/json/listInStockAll.json"     //取得所有有庫存之料號
            //先刪除目前Core Data儲存的所有資料
            DeleteCoreData("ListImd")
            DeleteCoreData("ListImz")
            DeleteCoreData("ListInStockAll")
            //取得庫存相關資料：倉庫，分群碼，料號
            readRequest(serviceImd, tableName: "ListImd")
            readRequest(serviceImz, tableName: "ListImz")
            readRequest(serviceStock, tableName: "ListInStockAll")
        }
        else
        {
            loadData("ListImd")
            loadData("ListImz")
            loadData("ListInStockAll")
        }
        
        //停止等候視窗
        activityIndicator.stopAnimating()
        blurEffectView.removeFromSuperview()
        //grayView.removeFromSuperview()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //清空 picker array
    @IBAction func resetClicked(_ sender: UIButton)
    {
        imdArray.removeAll()
        imzArray.removeAll()
        imgArray.removeAll()
        loadData("ListImd")
        loadData("ListImz")
        loadData("ListInStockAll")
        
        self.srcCurrValue = ""
        self.imdCurrValue = ""
        self.imzCurrValue = ""
        self.imgCurrValue = ""
        self.srcPicker.setTitle("請選擇", for: UIControlState())
        self.imdPicker.setTitle("請選擇", for: UIControlState())
        self.imzPicker.setTitle("請選擇", for: UIControlState())
        self.imgPicker.setTitle("請選擇", for: UIControlState())
    }

    //法人 picker
    @IBAction func srcPickerClicked(_ sender: UIButton)
    {
        /*let done: ActionStringDoneBlock = {(picker: ActionSheetStringPicker!, selectedIndex: NSInteger!, selectedValue : AnyObject!) in
            self.srcPicker.setTitle(selectedValue as? String, for: UIControlState())
            
            //清空倉庫欄位
            self.imdPicker.setTitle("請選擇", for: UIControlState())
            self.imdCurrValue = ""
            
            //清空料號欄位
            self.imgPicker.setTitle("請選擇", for: UIControlState())
            self.imgCurrValue = ""
            
            //儲存目前法人的值
            var query:String = ""
            if selectedValue as? String == "正一台灣" {
                self.srcCurrValue = "ZYTW"
            }
            else if selectedValue as? String == "正一龍華" {
                self.srcCurrValue = "ZYLH"
            }
            else if selectedValue as? String == "正一河南" {
                self.srcCurrValue = "ZYHEN"
            }
            query = "src = '\(self.srcCurrValue)'"
            
            //法人連動倉庫picker
            self.ReloadimdArray(query)
            
            //法人連動料號picker
            if self.imzCurrValue != ""
            {
                query = query + " and ima06 = '\(self.imzCurrValue)'"
            }
            self.ReloadimgArray(query)
        }
        let cancel: ActionStringCancelBlock = {(picker: ActionSheetStringPicker!) in
        } as! ActionStringCancelBlock
        let stringPicker = ActionSheetStringPicker(title: "法人",
                                                   rows: ["正一台灣", "正一龍華", "正一河南"],
                                                   initialSelection: 0,
                                                   doneBlock:done,
                                                   cancel:cancel,
                                                   origin: sender.superview!.superview)
        stringPicker?.show()*/
        
        ActionSheetStringPicker.show(withTitle: "法人", rows: ["正一台灣", "正一龍華", "正一河南"], initialSelection: 0, doneBlock: {
            picker, value, index in
            
            self.srcPicker.setTitle(index as? String, for: UIControlState())
            
            //清空倉庫欄位
            self.imdPicker.setTitle("請選擇", for: UIControlState())
            self.imdCurrValue = ""
            
            //清空料號欄位
            self.imgPicker.setTitle("請選擇", for: UIControlState())
            self.imgCurrValue = ""
            
            //儲存目前法人的值
            var query:String = ""
            if index as? String == "正一台灣" {
                self.srcCurrValue = "ZYTW"
            }
            else if index as? String == "正一龍華" {
                self.srcCurrValue = "ZYLH"
            }
            else if index as? String == "正一河南" {
                self.srcCurrValue = "ZYHEN"
            }
            query = "src = '\(self.srcCurrValue)'"
            
            //法人連動倉庫picker
            self.ReloadimdArray(query)
            
            //法人連動料號picker
            if self.imzCurrValue != ""
            {
                query = query + " and ima06 = '\(self.imzCurrValue)'"
            }
            self.ReloadimgArray(query)
            
            return
            }, cancel: { ActionStringCancelBlock in return }, origin: sender)
    }
    
    //倉庫 picker
    @IBAction func imdPickerClicked(_ sender: UIButton)
    {
        /*let done: ActionStringDoneBlock = {(picker: ActionSheetStringPicker!, selectedIndex: NSInteger!, selectedValue : AnyObject!) in
            self.imdPicker.setTitle(selectedValue as? String, for: UIControlState())
            
            //儲存目前倉庫的值
            var splitArray:[String] = selectedValue.components(separatedBy: CharacterSet (charactersIn: "[]"))
            self.imdCurrValue = splitArray[1]
            
            //清空料號欄位
            self.imgPicker.setTitle("請選擇", for: UIControlState())
            self.imgCurrValue = ""
            
            //倉庫連動料號picker
            var query:String = "img02 = '\(self.imdCurrValue)' "    //倉庫
            if self.srcCurrValue != ""
            {
                query = query + "and src = '\(self.srcCurrValue)' "     //法人
            }
            if self.imzCurrValue != ""
            {
                query = query + "and ima06 = '\(self.imzCurrValue)' "   //分群碼
            }
            self.ReloadimgArray(query)
        }
        let cancel: ActionStringCancelBlock = {(picker: ActionSheetStringPicker!) in
        } as! ActionStringCancelBlock
        let stringPicker = ActionSheetStringPicker(title: "倉庫",
                                                   rows: imdArray,
                                                   initialSelection: 0,
                                                   doneBlock:done,
                                                   cancel:cancel,
                                                   origin: sender.superview!.superview)
        stringPicker?.show()*/
        
        ActionSheetStringPicker.show(withTitle: "倉庫", rows: imdArray, initialSelection: 0, doneBlock: {
            picker, value, index in
            
            self.imdPicker.setTitle(index as? String, for: UIControlState())
            
            //儲存目前倉庫的值
            var splitArray:[String] = (index as! String).components(separatedBy: CharacterSet (charactersIn: "[]"))
            self.imdCurrValue = splitArray[1]
            
            //清空料號欄位
            self.imgPicker.setTitle("請選擇", for: UIControlState())
            self.imgCurrValue = ""
            
            //倉庫連動料號picker
            var query:String = "img02 = '\(self.imdCurrValue)' "    //倉庫
            if self.srcCurrValue != ""
            {
                query = query + "and src = '\(self.srcCurrValue)' "     //法人
            }
            if self.imzCurrValue != ""
            {
                query = query + "and ima06 = '\(self.imzCurrValue)' "   //分群碼
            }
            self.ReloadimgArray(query)
            
            return
            }, cancel: { ActionStringCancelBlock in return }, origin: sender)
    }
    
    //分群碼 picker
    @IBAction func imzPickerClicked(_ sender: UIButton)
    {
        /*let done: ActionStringDoneBlock = {(picker: ActionSheetStringPicker!, selectedIndex: NSInteger!, selectedValue : AnyObject!) in
            self.imzPicker.setTitle(selectedValue as? String, for: UIControlState())
            
            //儲存目前分群碼的值
            var splitArray:[String] = selectedValue.components(separatedBy: CharacterSet (charactersIn: "[]"))
            self.imzCurrValue = splitArray[1]
            
            //清空料號欄位
            self.imgPicker.setTitle("請選擇", for: UIControlState())
            self.imgCurrValue = ""
            
            //分群碼連動料號picker
            var query:String = "ima06 = '\(self.imzCurrValue)'"     //分群碼
            if self.srcCurrValue != ""
            {
                query = query + "and src = '\(self.srcCurrValue)' "     //法人
            }
            if self.imdCurrValue != ""
            {
                query = query + "and img02 = '\(self.imdCurrValue)' "   //倉庫
            }
            self.ReloadimgArray(query)
        }
        let cancel: ActionStringCancelBlock = {(picker: ActionSheetStringPicker!) in
        } as! ActionStringCancelBlock
        let stringPicker = ActionSheetStringPicker(title: "分群碼",
                                                   rows: imzArray,
                                                   initialSelection: 0,
                                                   doneBlock:done,
                                                   cancel:cancel,
                                                   origin: sender.superview!.superview)
        stringPicker?.show()*/
        
        ActionSheetStringPicker.show(withTitle: "分群碼", rows: imzArray, initialSelection: 0, doneBlock: {
            picker, value, index in

            self.imzPicker.setTitle(index as? String, for: UIControlState())
            
            //儲存目前分群碼的值
            var splitArray:[String] = (index as! String).components(separatedBy: CharacterSet (charactersIn: "[]"))
            self.imzCurrValue = splitArray[1]
            
            //清空料號欄位
            self.imgPicker.setTitle("請選擇", for: UIControlState())
            self.imgCurrValue = ""
            
            //分群碼連動料號picker
            var query:String = "ima06 = '\(self.imzCurrValue)'"     //分群碼
            if self.srcCurrValue != ""
            {
                query = query + "and src = '\(self.srcCurrValue)' "     //法人
            }
            if self.imdCurrValue != ""
            {
                query = query + "and img02 = '\(self.imdCurrValue)' "   //倉庫
            }
            self.ReloadimgArray(query)
            
            return
            }, cancel: { ActionStringCancelBlock in return }, origin: sender)
    }
    
    //料號 picker
    @IBAction func imgPickerClicked(_ sender: UIButton)
    {
        /*let done: ActionStringDoneBlock = {(picker: ActionSheetStringPicker!, selectedIndex: NSInteger!, selectedValue : AnyObject!) in
            self.imgPicker.setTitle(selectedValue as? String, for: UIControlState())
            
            //儲存目前料號的值
            self.imgCurrValue = (selectedValue as? String)!
        }
        let cancel: ActionStringCancelBlock = {(picker: ActionSheetStringPicker!) in
        } as! ActionStringCancelBlock
        let stringPicker = ActionSheetStringPicker(title: "法人",
                                                   rows: imgArray,
                                                   initialSelection: 0,
                                                   doneBlock:done,
                                                   cancel:cancel,
                                                   origin: sender.superview!.superview)
        stringPicker?.show()*/
        
        ActionSheetStringPicker.show(withTitle: "料號", rows: imgArray, initialSelection: 0, doneBlock: {
            picker, value, index in
            
            //print("value = \(value)")
            //print("index = \(index)")
            //print("picker = \(picker)")
            self.imgPicker.setTitle(index as? String, for: UIControlState())
            
            //儲存目前料號的值
            self.imgCurrValue = (index as? String)!
            return
            }, cancel: { ActionStringCancelBlock in return }, origin: sender)
    }
    
    @IBAction func partNumClicked(_ sender: UIButton)
    {
        
        //self.modalTransitionStyle = UIModalTransitionStyle.CoverVertical
        // Cover Vertical is necessary for CurrentContext
        //self.modalPresentationStyle = .CurrentContext
        // Display on top of    current UIView
        //self.presentViewController(PartNumTableViewController(), animated: true, completion: nil)
        if imgArray.count == 0
        {
            let alertController = alertObject.ShowAlert("Alert", ContentString:"無對應料號，請重新選擇查詢條件！", ActionString:"OK")
            self.present(alertController, animated: true, completion: nil)
        }
        else
        {
            performSegue(withIdentifier: "ModallySegue", sender: self)
        }
    }
    
    @IBAction func searchBtnClicked(_ sender: UIButton)
    {
        //篩選條件至少須有一項
        if self.imdCurrValue == "" && self.srcCurrValue == "" && self.imzCurrValue == "" && self.imgCurrValue == ""
        {
            let alertController = alertObject.ShowAlert("Alert", ContentString:"查詢條件至少輸入一項！", ActionString:"OK")
            self.present(alertController, animated: true, completion: nil)
            return
        }
        
        var query:String = ""
        if self.imdCurrValue != ""
        {
            query = query + "img02 = '\(self.imdCurrValue)' "   //倉庫
        }
        if self.srcCurrValue != ""
        {
            if query != ""
            {
                query = query + "and "
            }
            query = query + "src = '\(self.srcCurrValue)' "     //法人
        }
        if self.imzCurrValue != ""
        {
            if query != ""
            {
                query = query + "and "
            }
            query = query + "ima06 = '\(self.imzCurrValue)' "   //分群碼
        }
        if self.imgCurrValue != ""
        {
            if query != ""
            {
                query = query + "and "
            }
            query = query + "img01 = '\(self.imgCurrValue)'"    //料號
        }
        
        //直接查詢CoreData內的庫存資料
        if let managedObjectContext = (UIApplication.shared.delegate as? AppDelegate)?.managedObjectContext
        {
            let fetchRequest:NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: "ListInStockAll")
            let predicate = NSPredicate(format: query)  //"src=\(query)"
            //let predicate = NSPredicate(format: "src = %@ AND img02 = %@", "ZYHEN", "FHYPB")
            //let predicate = NSPredicate(format: "img02 = %@", "FHYPB")
            
            fetchRequest.predicate = predicate
            
            //以料號排序
            let sortDescriptor = NSSortDescriptor(key: "img01", ascending: true)
            let sortDescriptors = [sortDescriptor]
            fetchRequest.sortDescriptors = sortDescriptors
            
            do{
                stockResultArr = try managedObjectContext.fetch(fetchRequest) as! [ListInStockAll]
                if stockResultArr.count == 0
                {
                    let alertController = alertObject.ShowAlert("Alert", ContentString:"無庫存資料，請重新選擇查詢條件！", ActionString:"OK")
                    self.present(alertController, animated: true, completion: nil)
                }
                else
                {
                    self.performSegue(withIdentifier: "StockSegue", sender: self)
                }
            } catch{
                print(error)
            }
        }
        //呼叫記錄log
        let service = "http://www.onto.tech/F1SV/json/recordSelectStock.json"
        let (succeed, errorMsg) = getJsonUseByStockRecord(service, atoken: serviceToken)
        if (!succeed)
        {
            let alertController = alertObject.ShowAlert("Alert", ContentString:errorMsg, ActionString:"OK")
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    // MARK: - Table view data source

    /*override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 6
    }*/

    /*
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("reuseIdentifier", forIndexPath: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if segue.identifier == "StockSegue"
        {
            let destinationController = segue.destination as! StockTableViewController
            destinationController.serviceToken = self.serviceToken
            destinationController.errorObject = self.errorObject
            destinationController.internetReachability = self.internetReachability
            destinationController.stockResultArr = self.stockResultArr
        }
        else if segue.identifier == "ModallySegue"
        {
            let navController = segue.destination as! UINavigationController
            if let destinationController = navController.topViewController as? PartNumTableViewController {
            
                //destinationController.preferredContentSize = CGSize(width: 350, height: 400)
            
                //設定彈出viewController之動畫效果
                /*enum UIModalTransitionStyle: Int {
                 case CoverVertical   // 底部滑入，默认
                 case FlipHorizontal  // 水平翻转
                 case CrossDissolve   // 隐出隐现
                 case PartialCurl     // 翻页
                 }*/
                destinationController.modalTransitionStyle = .flipHorizontal
                destinationController.modalPresentationStyle = .currentContext
                
                destinationController.imgArray = self.imgArray
                destinationController.onDataAvailable = {[weak self]
                    (data) in
                    print("back data : \(data)")
                    self?.imgPicker.setTitle(data, for: UIControlState())
                    //儲存目前料號的值
                    self?.imgCurrValue = data
                    
                    /*if let weakSelf = self {
                        weakSelf.doSomethingWithData(data:data)
                        print("back data : \(data)")
                    }*/
                }
            }
        }
    }
    
    func readRequest(_ service:String, tableName:String)
    {
        //呼叫service取得資料，存入Core Data
        let (succeed, errorMsg) = getJsonUseByStockQuery(service, atoken: serviceToken, tableName: tableName)
        if (!succeed)
        {
            let alertController = alertObject.ShowAlert("Alert", ContentString:errorMsg, ActionString:"OK")
            self.present(alertController, animated: true, completion: nil)
        }
        else
        {
            loadData(tableName)
        }
    }
    
    //取得庫存相關資料存入 picker array：倉庫，分群碼，料號
    func loadData(_ tableName:String)
    {
        //呼叫service取得資料，存入Core Data
        //使用CoreData取得資料
        if let managedObjectContext = (UIApplication.shared.delegate as? AppDelegate)?.managedObjectContext
        {
            let fetchRequest:NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: tableName)
            do{
                if tableName == "ListImd"   //倉庫
                {
                    let imdClassArray = try managedObjectContext.fetch(fetchRequest) as! [ListImd]
                    for imd in imdClassArray
                    {
                        imdArray.append("[\(imd.imd01)]\(imd.imd02)")
                    }
                }
                else if tableName == "ListImz"  //分群碼
                {
                    let imzClassArray = try managedObjectContext.fetch(fetchRequest) as! [ListImz]
                    for imz in imzClassArray
                    {
                        imzArray.append("[\(imz.imz01)]\(imz.imz02)")
                    }
                }
                else if tableName == "ListInStockAll"   //料號
                {
                    let stockClassArray = try managedObjectContext.fetch(fetchRequest) as! [ListInStockAll]
                    for stock in stockClassArray
                    {
                        imgArray.append("\(stock.img01)")
                    }
                }
            } catch{
                print(error)
            }
        }
    }
    
    //查詢庫存資料ＪＳＯＮ
    func getJsonUseByStockQuery(_ serviceLink:String, atoken:String, tableName:String) -> (Bool, String)
    {
        var succeed:Bool = false
        var errorMag:String = ""
        let request = NSMutableURLRequest(url: URL(string: serviceLink)!)
        request.httpMethod = "GET"
        //GET要塞入的Header
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue(atoken, forHTTPHeaderField: "atoken")
        
        var response: URLResponse?
        do {
            let resData = try NSURLConnection.sendSynchronousRequest(request as URLRequest, returning: &response)
            
            //處理回傳的Body -> Json 格式
            //let myData = NSString(data:resData, encoding: NSUTF8StringEncoding) as! String
            var json: Array<AnyObject>  //不知道為什麼一定要放在這一行，json才不會是nil.....
            do {
                json = try JSONSerialization.jsonObject(with: resData, options: .mutableLeaves) as! Array
                //解析body
                InsertCoreData(json, tableName: tableName)
                succeed = true
            } catch let dataError {
                // Did the JSONObjectWithData constructor return an error? If so, log the error to the console
                let jsonStr = NSString(data: resData, encoding: String.Encoding.utf8.rawValue)
                errorMag = "Error could not parse JSON. \r\n '\(jsonStr)'"
                succeed = false
            }
            //處理回傳的Header
            if let response = response as? HTTPURLResponse {
                if response.statusCode == 200 {
                    let resultCode = response.allHeaderFields["statusCd"] as! String
                    if resultCode == "5000" { //"執行成功"
                        succeed = true
                    }
                    else
                    {
                        if resultCode == "5001" { //timeout
                            errorMag = "超過３０分鐘未操作，已自動登出，請重新登入！"
                            succeed = false
                        }
                        else
                        {
                            let codeMsg = ReadErrorMsg(resultCode)
                            errorMag = "Server回傳資料有誤！[\(resultCode)]\r\n\(codeMsg)"
                            succeed = false
                        }
                    }
                }
            }
        } catch {
            errorMag = "Send request error.\r\n '\(error)'"
            succeed = false
        }
        return (succeed, errorMag)
    }
    
    //記錄庫存查詢Log
    func getJsonUseByStockRecord(_ serviceLink:String, atoken:String) -> (Bool, String)
    {
        var succeed:Bool = false
        var errorMag:String = ""
        let request = NSMutableURLRequest(url: URL(string: serviceLink)!)
        request.httpMethod = "GET"
        //GET要塞入的Header
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue(atoken, forHTTPHeaderField: "atoken")
        
        var response: URLResponse?
        do {
            let resData = try NSURLConnection.sendSynchronousRequest(request as URLRequest, returning: &response)
            
            //處理回傳的Header
            if let response = response as? HTTPURLResponse {
                if response.statusCode == 200 {
                    let resultCode = response.allHeaderFields["statusCd"] as! String
                    if resultCode == "5000" { //"執行成功"
                        succeed = true
                    }
                    else
                    {
                        if resultCode == "5001" { //timeout
                            errorMag = "超過３０分鐘未操作，已自動登出，請重新登入！"
                            succeed = false
                        }
                        else
                        {
                            let codeMsg = ReadErrorMsg(resultCode)
                            errorMag = "Server回傳資料有誤！[\(resultCode)]\r\n\(codeMsg)"
                            succeed = false
                        }
                    }
                }
            }
        } catch {
            errorMag = "Send request error.\r\n '\(error)'"
            succeed = false
        }
        return (succeed, errorMag)
    }
    
    //讀取json資料存入Core Data
    func InsertCoreData(_ json:Array<AnyObject>, tableName:String)
    {
        var imd:ListImd!
        var imz:ListImz!
        var stock:ListInStockAll!
        for jsonpattern in json
        {
            if let managedObjectContext = (UIApplication.shared.delegate as? AppDelegate)?.managedObjectContext
            {
                if tableName == "ListImd"
                {
                    imd = NSEntityDescription.insertNewObject(forEntityName: tableName, into: managedObjectContext) as! ListImd
                    imd.src = jsonpattern["src"] as! String
                    imd.imd01 = jsonpattern["imd01"] as! String
                    imd.imd02 = jsonpattern["imd02"] as! String
                }
                else if tableName == "ListImz"
                {
                    imz = NSEntityDescription.insertNewObject(forEntityName: tableName, into: managedObjectContext) as! ListImz
                    imz.imz01 = jsonpattern["imz01"] as! String
                    if let imz02 = jsonpattern["imz02"] as? String
                    {
                        imz.imz02 = imz02
                    }
                    else
                    {
                        imz.imz02 = ""
                    }
                }
                else if tableName == "ListInStockAll"
                {
                    stock = NSEntityDescription.insertNewObject(forEntityName: tableName, into: managedObjectContext) as! ListInStockAll
                    stock.src = jsonpattern["src"] as! String
                    stock.img01 = jsonpattern["img01"] as! String
                    stock.img02 = jsonpattern["img02"] as! String
                    stock.img09 = jsonpattern["img09"] as! String
                    stock.img10 = jsonpattern["img10"] as! String
                    stock.img23 = jsonpattern["img23"] as! String
                    stock.ima02 = jsonpattern["ima02"] as! String
                    stock.ima06 = jsonpattern["ima06"] as! String
                    stock.ima08 = jsonpattern["ima08"] as! String
                    stock.ima12 = jsonpattern["ima12"] as! String
                }
                do{
                    try managedObjectContext.save()
                } catch{
                    print(error)
                }
            }
        }
    }

    //刪除Core Data全部資料
    func DeleteCoreData(_ tableName:String) {
        let appDel = UIApplication.shared.delegate as! AppDelegate
        let context = appDel.managedObjectContext
        let coord = appDel.persistentStoreCoordinator
        
        let fetchRequest:NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: tableName)
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        
        do {
            try coord.execute(deleteRequest, with: context)
        } catch let error as NSError {
            debugPrint(error)
        }
    }
    
    //重新載入倉庫 picker array
    func ReloadimdArray(_ query:String)
    {
        //清空array
        imdArray.removeAll()
        //使用CoreData取得資料
        if let managedObjectContext = (UIApplication.shared.delegate as? AppDelegate)?.managedObjectContext
        {
            let fetchRequest:NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: "ListImd")
            let predicate = NSPredicate(format: query)  //"src=\(query)"
            fetchRequest.predicate = predicate
            do{
                let imdClassArray = try managedObjectContext.fetch(fetchRequest) as! [ListImd]
                for imd in imdClassArray
                {
                    imdArray.append("[\(imd.imd01)]\(imd.imd02)")
                }
                
            } catch{
                print(error)
            }
        }
    }
    
    //重新載入料號 picker array
    func ReloadimgArray(_ query:String)
    {
        //清空array
        imgArray.removeAll()
        //使用CoreData取得資料
        if let managedObjectContext = (UIApplication.shared.delegate as? AppDelegate)?.managedObjectContext
        {
            let fetchRequest:NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: "ListInStockAll")
            let predicate = NSPredicate(format: query)  //"src=\(query)"
            //let predicate = NSPredicate(format: "src = %@ AND img02 = %@", "ZYHEN", "FHYPB")
            //let predicate = NSPredicate(format: "img02 = %@", "FHYPB")
            
            fetchRequest.predicate = predicate
            do{
                let imgClassArray = try managedObjectContext.fetch(fetchRequest) as! [ListInStockAll]
                for img in imgClassArray
                {
                    imgArray.append(img.img01)
                }
                
            } catch{
                print(error)
            }
        }
    }
    
    //取得錯誤代碼訊息
    func ReadErrorMsg(_ errorCode:String) -> String
    {
        if errorObject.count == 0
        {
            return ""
        }
        else
        {
            return errorObject[errorCode] as! String
        }
    }
    
    //顯示進度列
    func addProgressView()
    {
        //透明背景
        //grayView.frame = CGRectMake(0 , 0, self.view.frame.width, self.view.frame.height)
        //grayView.backgroundColor = UIColor(red: 127.0/255.0, green: 127.0/255.0, blue: 127.0/255.0, alpha: 0.5)
        
        //模糊背景
        let blurEffect = UIBlurEffect(style: UIBlurEffectStyle.extraLight)
        blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = view.bounds
        
        //進度列文字說明
        var progressLabel = UILabel()
        //var progressLabel: UILabel?
        let frame = CGRect(x:view.center.x - 100, y:view.center.y - 100, width:200, height:45)
        progressLabel.frame = frame
        //progressLabel?.backgroundColor = UIColor.lightGray
        progressLabel.textColor = UIColor.black
        progressLabel.font = UIFont.boldSystemFont(ofSize: 16)
        progressLabel.text = "庫存資料載入中...請稍候..."
        progressLabel.textAlignment = .center
        blurEffectView.addSubview(progressLabel)
        //grayView.addSubview(progressLabel)
        
//        //進度列
//        progressView = UIProgressView(progressViewStyle: UIProgressViewStyle.default)
//        progressView.center = self.view.center
//        
//        let transform:CGAffineTransform = CGAffineTransform(scaleX: 1.0, y: 5.0)
//        progressView.transform = transform
//        //已走过进度的进度条颜色
//        progressView?.progressTintColor = UIColor.blue
//        //未走过进度的进度条颜色
//        progressView?.trackTintColor = UIColor.white
//        
//        circleProgress = KDCircularProgress(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
//        circleProgress.startAngle = -90
//        circleProgress.progressThickness = 0.2
//        circleProgress.trackThickness = 0.6
//        circleProgress.clockwise = true
//        circleProgress.gradientRotateSpeed = 5
//        circleProgress.roundedCorners = false
//        circleProgress.glowMode = .forward
//        circleProgress.glowAmount = 0.9
//        
//        //color set
//        let blue = UIColor(red: 75.0/255.0, green: 172.0/255.0, blue: 198.0/255.0, alpha: 1.0)
//        let bluegreen = UIColor(red: 72.0/255.0, green: 212.0/255.0, blue: 145.0/255.0, alpha: 1.0)
//        let green = UIColor(red: 96.0/255.0, green: 225.0/255.0, blue: 70.0/255.0, alpha: 1.0)
//        let yellow = UIColor(red: 213.0/255.0, green: 236.0/255.0, blue: 70.0/255.0, alpha: 1.0)
//        let orange = UIColor(red: 247.0/255.0, green: 150.0/255.0, blue: 70.0/255.0, alpha: 1.0)
//        
//        circleProgress.setColors(colors: blue, bluegreen, green, yellow, orange)
//        circleProgress.center = CGPoint(x: view.center.x, y: view.center.y + 50)
//        
//        //blurEffectView.addSubview(progressView)
//        blurEffectView.addSubview(circleProgress)
//        //grayView.addSubview(progressView)
//        progressView.progress = 0.1
        
        view.addSubview(blurEffectView)
        //view.addSubview(grayView)
    }
    
    func startDisplayLink() {
        displayLink = CADisplayLink(target: self, selector: Selector("handleDisplayLink:"))
    }
    
    func handleDisplayLink(displayLink: CADisplayLink) {
        progressView.progress += 0.3
        progressView.setProgress(progressView.progress, animated: true)
        
        /*let percentComplete = Float((CFAbsoluteTimeGetCurrent() - startTime!) / duration)
        if percentComplete < 1.0 {
            self.timerBar.setProgress(1.0 - percentComplete, animated: false)
        } else {
            stopDisplayLink()
            self.timerBar.setProgress(0.0, animated: false)
        }*/
    }
    
    func btnOnclick(){
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector:#selector(timerAction), userInfo: nil, repeats: true)
        timer.fire()
    }
    func timerAction(){
        progressView.progress += 0.2
        if  progressView.progress == 1{
            progressView.setProgress(0, animated: true)
        }
    }
    
    func updateProgressBar()
    {
        //dispatch_async(DispatchQueue.global(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)) {
        DispatchQueue.global().async{
            //Determining playerExpBar's new value
            self.progressView.progress += 0.3
            
            //Setting playerExpBar's progress on the main thread Dispatch
            DispatchQueue.main.async {
                //Set value to 0.5 for testing purposes
                self.progressView.setProgress(self.progressView.progress, animated: true)
            }
        }
    }
    //圓圈型進度列 -> KDCircularProgress
    //https://www.andrewcbancroft.com/2015/07/09/circular-progress-indicator-in-swift/
}
