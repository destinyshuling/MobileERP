//
//  SearchOptionTableViewController.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/5/31.
//  Copyright © 2016年 onto. All rights reserved.
//
//  Table View in Container View

import UIKit
import CoreActionSheetPicker

protocol ContainerToMaster {
    func getSwitchValue() -> Bool
}

class SearchOptionTableViewController: UITableViewController {
    var conToMaster: ContainerToMaster?
    
    //部門pickerview
    @IBOutlet var departPicker: UIButton!
    //季度pickerview
    @IBOutlet var quarterPicker: UIButton!
    //排序條件pickerview
    @IBOutlet var sortPicker: UIButton!
    //季度 or 月度 顯示
    @IBOutlet var dateLabel: UILabel!
    
    //前一頁傳遞過來的資料
    var loginDepartment:String = ""
    var loginAuthorization: String = ""
    var loginAuthorizationArr: [String] = []
    //var switchValue: Bool!
    
    //var quarterArray = ["2016 Q2", "2016 Q1", "2015 Q4", "2015 Q3", "2015 Q2", "2015 Q1"]
    //儲存季度array
    var QuarterArray = [String]()
    //儲存部門array
    var DepartmentArray = [String]()  //["群創利潤中心", "雲虎利潤中心", "保膜利潤中心", "新創利潤中心", "華為利潤中心", "CNF利潤中心"]
    //儲存日期array
    var yearArr = [String]()
    var quarterArr = [String]()
    var monthArr = [String]()
    var currDateIndex1:Int = 0  //year
    var currDateIndex2:Int = 0  //quarter or month
    var month:Int = 0
    
    func changeDateName(_ text: String) {
        dateLabel.text = text

        var defaultDate:String = setCurrentQuarter()
        if text == "季度"
        {
            defaultDate = setCurrentQuarter()
        }
        else
        {
            defaultDate = setCurrentMonth()
        }
        self.quarterPicker.setTitle(defaultDate, for: UIControlState())
    }
    
    @IBAction func departPickerClicked(_ sender: UIButton)
    {
        /*let done: ActionStringDoneBlock = {(picker: ActionSheetStringPicker!, selectedIndex: NSInteger!, selectedValue : AnyObject!) in
            //print(selectedValue)
            self.departPicker.setTitle(selectedValue as? String, for: UIControlState())
        }
        let cancel: ActionStringCancelBlock = {(picker: ActionSheetStringPicker!) in
            //print("Block Picker Canceled")
        } as! ActionStringCancelBlock
        let stringPicker = ActionSheetStringPicker(title: "部門",
                                                   rows: DepartmentArray,
                                                   initialSelection: 0,
                                                   doneBlock:done,
                                                   cancel:cancel,
                                                   origin: sender.superview!.superview)
        stringPicker?.show()*/
        
        ActionSheetStringPicker.show(withTitle: "部門", rows: DepartmentArray, initialSelection: 0, doneBlock: {
            picker, value, index in
            
            //print("value = \(value)")
            //print("index = \(index)")
            //print("picker = \(picker)")
            self.departPicker.setTitle(index as? String, for: UIControlState())
            return
            }, cancel: { ActionStringCancelBlock in return }, origin: sender)
    }
    
    @IBAction func quarterPickerClicked(_ sender: UIButton)
    {
        /*let done: ActionStringDoneBlock = {(picker: ActionSheetStringPicker!, selectedIndex: NSInteger!, selectedValue : AnyObject!) in
            //print(selectedValue)
            self.quarterPicker.setTitle(selectedValue as? String, for: UIControlState())
        }
        
        let cancel: ActionStringCancelBlock = {(picker: ActionSheetStringPicker!) in
            //print("Block Picker Canceled")
        } as! ActionStringCancelBlock
        
        let stringPicker = ActionSheetStringPicker(title: "季度",
                                                   rows: QuarterArray,
                                                   initialSelection: 0,
                                                   doneBlock:done,
                                                   cancel:cancel,
                                                   origin: sender.superview!.superview)
        stringPicker?.show()*/
        
        ActionSheetStringPicker.show(withTitle: "季度", rows: QuarterArray, initialSelection: 0, doneBlock: {
            picker, value, index in
            
            //print("value = \(value)")
            //print("index = \(index)")
            //print("picker = \(picker)")
            self.quarterPicker.setTitle(index as? String, for: UIControlState())
            return
            }, cancel: { ActionStringCancelBlock in return }, origin: sender)
    }
    
    //多選picker
    @IBAction func multipleStringPickerClicked(_ sender: UIButton)
    {
        //取得parent view Switch value
        var DateArray = [[String]]()
        let switchValue:Bool = conToMaster!.getSwitchValue()
        
        DateArray.append(yearArr)
        if switchValue == true
        {
            DateArray.append(monthArr)
            currDateIndex2 = month - 1
        }
        else
        {
            DateArray.append(quarterArr)
            var q:Int
            q = month / 3
            if month % 3 > 0
            {
                q = q + 1
            }
            currDateIndex2 = q - 1
        }
        
        ActionSheetMultipleStringPicker.show(withTitle: dateLabel.text, rows:DateArray,
             initialSelection: [0, currDateIndex2], doneBlock: {
                picker, values, indexes in
                
                //print("values = \(values)")
                //print("indexes = \(indexes)")
                //print("picker = \(picker)")
                //字串切割
                var dateStr:String = ""
                let swiftArray:[String] = indexes as! [String]
                for str in swiftArray
                {
                    //print(str)
                    dateStr = dateStr + " " + str
                }
                
                //let separators = NSCharacterSet(charactersInString: "(,) ")
                //var strArr = (indexes as! NSString).componentsSeparatedByCharactersInSet(separators)
                
                self.quarterPicker.setTitle("\(dateStr)", for: UIControlState())
                return
            }, cancel: { ActionMultipleStringCancelBlock in return }, origin: sender)
    }
    
    @IBAction func sortPickerClicked(_ sender: UIButton)
    {
        /*let done: ActionStringDoneBlock = {(picker: ActionSheetStringPicker!, selectedIndex: NSInteger!, selectedValue : AnyObject!) in
            //print(selectedValue)
            self.sortPicker.setTitle(selectedValue as? String, for: UIControlState())
        }
        let cancel: ActionStringCancelBlock = {(picker: ActionSheetStringPicker!) in
            //print("Block Picker Canceled")
        } as! ActionStringCancelBlock
        let stringPicker = ActionSheetStringPicker(title: "排序條件",
                                                   rows: ["訂單客戶", "訂單日期", "訂單狀態"],
                                                   initialSelection: 0,
                                                   doneBlock:done,
                                                   cancel:cancel,
                                                   origin: sender.superview!.superview)
        stringPicker?.show()*/
        
        ActionSheetStringPicker.show(withTitle: "排序條件", rows: ["訂單日期", "訂單客戶", "出貨狀態", "立帳狀態"], initialSelection: 0, doneBlock: {
            picker, value, index in
            
            //print("value = \(value)")
            //print("index = \(index)")
            //print("picker = \(picker)")
            self.sortPicker.setTitle(index as? String, for: UIControlState())
            return
            }, cancel: { ActionStringCancelBlock in return }, origin: sender)
    }
    
    /*//change button title
    func SetButtonTitle(selectedOption:String)
    {
        departPicker.setTitle(selectedOption, forState: UIControlState.Normal)
    }*/

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        //計算預計顯示的季度
        setQuarter()
        
        //控制顯示的部門
        setDepartment()
        
        //set default value
        if DepartmentArray.count > 0
        {
            self.departPicker.setTitle(DepartmentArray[0], for: UIControlState())
        }
        /*if QuarterArray.count > 0
        {
            self.quarterPicker.setTitle(QuarterArray[0], forState: UIControlState.Normal)
        }*/
        //預設在當前月份
        let defaultDate:String = setCurrentMonth()
        self.quarterPicker.setTitle(defaultDate, for: UIControlState())
        
        self.sortPicker.setTitle("訂單日期", for: UIControlState())
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setDepartment()
    {
        //DepartmentArray
        for item in loginAuthorizationArr {
            switch true{
            case item == "111":
                DepartmentArray.append("材化一部")
            case item == "112":
                DepartmentArray.append("材化二部")
            case item == "113":
                DepartmentArray.append("材化三部")
            case item == "114":
                DepartmentArray.append("材化四部")
            case item == "115":
                DepartmentArray.append("材化五部")
            case item == "116":
                DepartmentArray.append("材化六部")
            default:
                break
            }
        }
        /*switch true {
        case loginAuthorization == "ORDER_ALL_DATA":
            DepartmentArray.append("群創利潤中心")
            DepartmentArray.append("雲虎利潤中心")
            DepartmentArray.append("保膜利潤中心")
            DepartmentArray.append("新創利潤中心")
            DepartmentArray.append("華為利潤中心")
            DepartmentArray.append("CNF利潤中心")
        case loginAuthorization == "ORDER_PART_1246":
            DepartmentArray.append("群創利潤中心")
            DepartmentArray.append("雲虎利潤中心")
            DepartmentArray.append("新創利潤中心")
            DepartmentArray.append("CNF利潤中心")
        default:
            switch true {
            case loginDepartment.hasPrefix("111"):
                DepartmentArray.append("群創利潤中心")
            case loginDepartment.hasPrefix("112"):
                DepartmentArray.append("雲虎利潤中心")
            case loginDepartment.hasPrefix("113"):
                DepartmentArray.append("保膜利潤中心")
            case loginDepartment.hasPrefix("114"):
                DepartmentArray.append("新創利潤中心")
            case loginDepartment.hasPrefix("115"):
                DepartmentArray.append("華為利潤中心")
            case loginDepartment.hasPrefix("116"):
                DepartmentArray.append("CNF利潤中心")
            default:
                break
            }
        }*/
    }

    func setQuarter()
    {
        //取得現在的日期:
        let today = Date()  //2016-06-05 06:18:17 +0000
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        let date2 = formatter.string(from: today)
        //print(date2)
        
        //QuarterArray
        var strArr = date2.components(separatedBy: "-")
        let year:Int! = Int(strArr[0])
        month = Int(strArr[1])!
        
        /*for(var i = year ; i >= 2015 ; i=i-1)
        {
            var q:Int
            if i == year
            {
                q = month / 3
                if month % 3 > 0
                {
                    q = q + 1
                }
            }
            else
            {
                q = 4
            }
            
            for(var j = q ; j >= 1 ; j=j-1)
            {
                QuarterArray.append("\(i) Q\(j)")
            }
        }*/
        
        
        //for(var i = year ; i! >= 2015 ; i=i!-1)
        for i in (2015..<year+1).reversed()
        {
            yearArr.append("\(i)")
        }
        //for(var i = 1 ; i <= 4 ; i=i+1)
        for i in (1..<5)
        {
            quarterArr.append("Q\(i)")
        }
        //for(var i = 1 ; i <= 12 ; i=i+1)
        for i in (1..<13)
        {
            if i < 10
            {
                let s:String = String(format: "%02x", i)
                monthArr.append("\(s)")
            }
            else
            {
                monthArr.append("\(i)")
            }
        }
    }
    
    //取得當前月份字串 ex: 2016 09
    func setCurrentMonth() -> String
    {
        var currDate:String = ""
        if month < 10
        {
            let s:String = String(format: "%02x", month)
            currDate = "\(yearArr[0]) \(s)"
        }
        else
        {
            currDate = "\(yearArr[0]) \(month)"
        }
        return currDate
    }
    
    //取得當前季度字串 ex: 2016 Q3
    func setCurrentQuarter() -> String
    {
        var currDate:String = ""
        var q:Int = month / 3
        if month % 3 > 0
        {
            q = q + 1
        }
        currDate = "\(yearArr[0]) Q\(q)"
        return currDate
    }

    //使用container view時，由於所製作的表格非動態顯示，所以我們不能實作以下這些方法
    //參考網址：http://yummylife11.blogspot.tw/2014/01/xcode-ui-view-controllerstatic-cells.html
    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0.0
    }
    
//    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
//        // #warning Incomplete implementation, return the number of sections
//        return 1
//    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 3
    }

    /*
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("reuseIdentifier", forIndexPath: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    /*override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }*/
    
    //設定頁面是否可以旋轉
    override var shouldAutorotate : Bool {
        return false
    }
    
    override var supportedInterfaceOrientations : UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
}
