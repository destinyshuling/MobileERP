//
//  PartNumTableViewCell.swift
//  OrderSearch
//
//  Created by ＦＳＭ００２ on 2016/9/13.
//  Copyright © 2016年 onto. All rights reserved.
//

import UIKit

class PartNumTableViewCell: UITableViewCell {

    @IBOutlet var partNumSelected:UIImageView!
    @IBOutlet var partNum:UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
        if selected {
            partNumSelected?.image = UIImage(named: "selected.png")
        }else {
            partNumSelected?.image = UIImage(named: "unselected.png")
        }
    }

}
